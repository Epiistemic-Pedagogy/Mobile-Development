package com.team.athleteconnect

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
