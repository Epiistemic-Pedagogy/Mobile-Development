# athleteconnect

AthleteConnect is your one stop application that you can use to get access to both Agents
and Athletes registered on the platform 

## Tool Needed
- Android Studio 
- A working Emulator connected (You can use the Android studio Device Manager to set one up)
- Firebase account and access to the firebase backend

## BackEnd Setup
On your Computer run the following command 
- firebase login
- dart pub global activate flutterfire_cli

## Getting Started
After Installing Flutter and setting up all the variables on your device, 
- Open the project folder from your Android Studio  
In the Android Studio Terminal, run the command:  
- flutterfire configure
- flutter clean
- flutter pub get 
- flutter run
