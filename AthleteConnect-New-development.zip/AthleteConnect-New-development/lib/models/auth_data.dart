
import 'package:athleteconnect/models/agent_profile.dart';
import 'package:athleteconnect/models/athlete_profile.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:file_picker/file_picker.dart';

class AuthData {
  AgentProfile? agentProfile;
  AthleteProfile? athleteProfile;
  PlatformFile? file;
  String? userId;
  UserProfile? userProfile;


  AuthData(
      {this.agentProfile,this.athleteProfile,this.file, this.userId, this.userProfile});


}