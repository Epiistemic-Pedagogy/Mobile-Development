
class AthleteProfile {
  String? id;
  String? firstname;
  String? lastname;
  String? email;
  String? bio;
  String? phone;
  List<String>? interest;
  String? education;
  String? mediaUrl;
  String? goals;
  String? dpUrl;
  String? achievements;
  bool? isAgent;



  AthleteProfile(
      {this.id, this.firstname,this.lastname, this.email, this.bio,this.phone,
        this.interest,this.education,this.mediaUrl,this.goals,this.dpUrl,this.achievements, this.isAgent});

  AthleteProfile.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    email = json['email'];
    bio = json['bio'];
    phone = json['phone'];
    interest = (json['interest'] as List<dynamic>?)?.map((item) => item as String).toList();
    education = json['education'];
    goals = json['goals'];
    mediaUrl = json['mediaUrl'];
    dpUrl = json['dpUrl'];
    achievements = json['achievements'];
    isAgent = json['isAgent'];
  }



  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['firstname'] = firstname;
    data['lastname'] = lastname;
    data['email'] = email;
    data['phone'] = phone;
    data['bio'] = bio;
    data['education'] = education;
    data['interest'] = interest;
    data['goals'] = goals;
    data['mediaUrl'] = mediaUrl;
    data['dpUrl'] = dpUrl;
    data['isAgent'] = isAgent;
    data['achievements'] = achievements;
    return data;
  }

}