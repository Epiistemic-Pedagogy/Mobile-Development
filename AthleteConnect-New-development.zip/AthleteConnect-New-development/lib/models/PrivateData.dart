

class PrivacyData {
  bool? phone;
  bool? bio;
  bool? media;
  bool? email;
  bool? achievements;
  bool? openMessages;
  bool? goals;
  bool? education;
  bool? clients;


  PrivacyData(
      {this.phone,this.bio,this.goals,this.media,this.achievements,this.openMessages,this.education, this.clients, this.email});


  PrivacyData.fromJson(Map<String, dynamic> json) {
    phone = json['phone'];
    bio = json['bio'];
    goals = json['goals'];
    media = json['media'];
    email = json['email'];
    achievements = json['achievements'];
    openMessages = json['openMessages'];
    education = json['education'];
    clients = json['clients'];
  }


  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['bio'] = bio;
    data['goals'] = goals;
    data['media'] = media;
    data['phone'] = phone;
    data['email'] = email;
    data['achievements'] = achievements;
    data['education'] = education;
    data['openMessages'] = openMessages;
    data['clients'] = clients;
    return data;
  }


}


