
class EventObject {
  String? title;
  String? ownerId;
  String? date;
  String? endDate;
  String? about;
  String? address;
  String? time;
  String? imageUrl;
  String? eventId;
  bool? isNew;


  EventObject(
      {this.title,this.date,this.ownerId, this.time, this.endDate,
        this.address, this.imageUrl, this.eventId, this.about, this.isNew});

  EventObject.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    ownerId = json['ownerId'];
    date = json['date'];
    endDate = json['endDate'];
    about = json['about'];
    address = json['address'];
    time = json['time'];
    imageUrl = json['imageUrl'];
    eventId = json['eventId'];
    isNew = json['isNew'];
  }


  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['title'] = title;
    data['ownerId'] = ownerId;
    data['date'] = date;
    data['endDate'] = endDate;
    data['about'] = about;
    data['address'] = address;
    data['time'] = time;
    data['imageUrl'] = imageUrl;
    data['eventId'] = eventId;
    data['isNew'] = isNew;
    return data;
  }
}