
class AppIntroductionScreenModel {
  String? imageAsset;
  String? description;

  AppIntroductionScreenModel(
      {this.imageAsset,this.description,});

  AppIntroductionScreenModel.fromJson(Map<String, dynamic> json) {
    imageAsset = json['imageAsset'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['imageAsset'] = imageAsset;
    data['description'] = description;
    return data;
  }
}
