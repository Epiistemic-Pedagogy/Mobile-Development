
import 'package:athleteconnect/models/user_profile.dart';

class ExtraData {
  String? stringValue;
  bool? boolValue;
  String? id;

  ExtraData(
      {this.stringValue,this.boolValue});


  ExtraData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
  }

}

class ExtraVideoData {
  UserProfile? currentUser;
  UserProfile? recipient;

  ExtraVideoData(
      {this.currentUser,this.recipient});


  ExtraVideoData.fromJson(Map<String, dynamic> json) {
    currentUser = json['currentUser'];
    recipient = json['recipient'];
  }

}


class ResourceObject {
  String? title;
  String? image;
  String? link;

  ResourceObject(
      {this.title,this.image,this.link});


  ResourceObject.fromJson(Map<String, dynamic> json) {
    title = json['title'];
    image = json['image'];
    link = json['link'];
  }

}


