
class AgentProfile {
  String? id;
  String? firstname;
  String? lastname;
  String? email;
  String? bio;
  String? phone;
  List<String>? interest;
  List<String>? clients;
  String? mediaUrl;
  String? dpUrl;
  String? notificationToken;
  bool? isAgent;

  AgentProfile(
      {this.id, this.firstname,this.lastname, this.email, this.bio,this.phone,
        this.interest,this.clients,this.mediaUrl,this.dpUrl, this.notificationToken, this.isAgent});

  AgentProfile.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    email = json['email'];
    bio = json['bio'];
    phone = json['phone'];
    interest = (json['interest'] as List<dynamic>?)?.map((item) => item as String).toList();
    clients = (json['clients'] as List<dynamic>?)?.map((item) => item as String).toList();
    mediaUrl = json['mediaUrl'];
    dpUrl = json['dpUrl'];
    notificationToken = json['notificationToken'];
    isAgent = json['isAgent'];
  }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['firstname'] = firstname;
    data['lastname'] = lastname;
    data['email'] = email;
    data['phone'] = phone;
    data['bio'] = bio;
    data['clients'] = clients;
    data['interest'] = interest;
    data['mediaUrl'] = mediaUrl;
    data['dpUrl'] = dpUrl;
    data['notificationToken'] = notificationToken;
    return data;
  }

}