

class RatingObject {
   String? id;
   int? score;
   String? ratedAt;
   String? customerName;
   String? merchantName;
   String? customerProfilePictureUrl;
   String? merchantProfilePictureUrl;
   String? comment;
   String? customerID;
   String? merchantId;

  RatingObject(this.id, this.score, this.ratedAt, this.customerName, this.merchantName,
      this.customerProfilePictureUrl, this.merchantProfilePictureUrl, this.comment, this.customerID, this.merchantId);

   RatingObject.fromJson(Map<String, dynamic> json) {
     id = json['id'] ?? '';
     score = json['score'] ?? 0; // Ensuring proper casting
     ratedAt = json['ratedAt'] ?? '';
     customerName = json['customerName'] ?? '';
     merchantName = json['merchantName'] ?? '';
     customerProfilePictureUrl = json['customerProfilePictureUrl'] ?? '';
     merchantProfilePictureUrl = json['merchantProfilePictureUrl'] ?? '';
     comment = json['comment'] ?? '';
     customerID = json['customerID'] ?? '';
     merchantId = json['merchantId'] ?? '';
   }

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['id'] = id;
    data['score'] = score;
    data['ratedAt'] = ratedAt;
    data['customerName'] = customerName;
    data['merchantName'] = merchantName;
    data['customerProfilePictureUrl'] = customerProfilePictureUrl;
    data['merchantProfilePictureUrl'] = merchantProfilePictureUrl;
    data['comment'] = comment;
    data['customerID'] = customerID;
    data['merchantId'] = merchantId;
    return data;
  }
}