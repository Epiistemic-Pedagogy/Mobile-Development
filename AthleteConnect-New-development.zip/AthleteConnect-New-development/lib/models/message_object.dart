

class MessageObject {
  final String id;
  final String sender;
  final String sentAt;
  final String message;
  final bool isRead;

  MessageObject(this.id, this.sender, this.sentAt, this.message, this.isRead);

  factory MessageObject.fromJson(Map json) {
    final id = json['id'];
    final sentAt = json['sentAt'];
    final sender = json['sender'];
    final message = json['message'];
    final attachments = json['attachments'];
    final isRead = json['isRead'];

    return MessageObject(id, sender, sentAt, message, isRead);
  }

  Map<String, dynamic> toJson() {
    return <String, dynamic>{
      'id': id,
      'sender': sender,
      'sentAt': sentAt,
      'message': message,
      'isRead': isRead,
    };
  }
}