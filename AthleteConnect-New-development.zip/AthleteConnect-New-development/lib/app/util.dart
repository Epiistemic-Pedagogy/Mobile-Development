
import 'package:athleteconnect/constants/colors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';


class Utils {
  Container loadingContainer(
      String title, Color titleColor, bool showPleaseWait) {
    return Container(
      color: Color.fromRGBO(0, 0, 0, 0.6),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            CircularProgressIndicator(),
            Text(
              title,
              style: TextStyle(
                  color: titleColor,
                  fontSize: 30.0,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Avenir'),
            ),
            showPleaseWait
                ? Text(
              'Please wait',
              style: TextStyle(
                  color: titleColor,
                  fontSize: 15.0,
                  fontWeight: FontWeight.w300,
                  fontFamily: 'Avenir'),
            )
                : Container(),
          ],
        ),
      ),
    );
  }

  Container lightLoadingContainer(
      String title, Color titleColor, bool showPleaseWait) {
    return Container(
      color: AppColors.primary.withOpacity(0.1),
      padding: EdgeInsets.all(20.0),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text(
              title,
              style: TextStyle(
                  color: titleColor,
                  fontSize: 30.0,
                  fontWeight: FontWeight.w600,
                  fontFamily: 'Avenir'),
            ),
            showPleaseWait
                ? Text(
              'Please wait',
              style: TextStyle(
                  color: titleColor,
                  fontSize: 15.0,
                  fontWeight: FontWeight.w300,
                  fontFamily: 'Avenir'),
            )
                : Container(),
          ],
        ),
      ),
    );
  }


  Container pleaseWaitText() {
    return  Container(
      child: const Text(
        'Please wait',
        style: TextStyle(
            color: AppColors.white,
            fontSize: 15.0,
            fontWeight: FontWeight.w300,
            fontFamily: 'Avenir'),
      ),
    );
  }

  String changeDateToChatFormat(String longIntTime){
    DateTime dateTime = DateTime.fromMillisecondsSinceEpoch(int.parse(longIntTime));
    final dateFormat = DateFormat.Hm('en_US').format(dateTime);
    return dateFormat.toString();
  }

  String getCurrenttime(String dateString){
    final dateFormat = DateFormat.Hm('en_US').format(DateTime.now());
    return dateFormat.toString();
  }

  String formattedDateWithYear(String dateString) {
    DateTime signalDate = DateTime.parse(dateString);
    //String formattedDate = DateFormat('yyyy-MM-dd').format(signalDate);
    //return formatDate(signalDate, [yyyy, '/', mm, '/', dd, '', hh, ':', nn, ':', ss, '', am]);
    String formattedDate = DateFormat.yMMMMd('en_US').format(signalDate);
    return formattedDate;
  }
//DateTime dateTime = DateTime.fromMillisecondsSinceEpoch(timestamp);
  String changeDateFormat(String dateString){
    final dateFormat = DateFormat('EEE d MMM yyyy').format(DateTime.parse(dateString));
    return dateFormat.toString();
  }

  String formatEventDate(String longIntTime){
    DateTime dateTime = DateTime.fromMillisecondsSinceEpoch(int.parse(longIntTime));
    String formattedDate = DateFormat('EEE d MMM').format(dateTime);
    return formattedDate;
  }

  String formatMillisecondsDate(String longIntTime){
    final dateFormatter = DateFormat('yyyy-MM-dd');
    DateTime dateTime = DateTime.fromMillisecondsSinceEpoch(int.parse(longIntTime));
    final formattedDate = dateFormatter.format(dateTime);
    return formattedDate;
  }
}

