import 'package:athleteconnect/app/router.dart';
import 'package:get_it/get_it.dart';
import 'package:go_router/go_router.dart';

GetIt locator = GetIt.instance;
Future setUpLocator() async {
  locator.registerSingleton<GoRouter>(router());

}
