import 'package:athleteconnect/models/auth_data.dart';
import 'package:athleteconnect/models/events.dart';
import 'package:athleteconnect/models/extra_data.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/views/authpage/auth_view.dart';
import 'package:athleteconnect/ui/views/chat/chat_history.dart';
import 'package:athleteconnect/ui/views/chat/chat_view.dart';
import 'package:athleteconnect/ui/views/dashboard/dashboard_view.dart';
import 'package:athleteconnect/ui/views/event/add_new_event_view.dart';
import 'package:athleteconnect/ui/views/event/all_event_view.dart';
import 'package:athleteconnect/ui/views/event/event_profile_view.dart';
import 'package:athleteconnect/ui/views/imagesetup/profileimage_setup_view.dart';
import 'package:athleteconnect/ui/views/login/login_view.dart';
import 'package:athleteconnect/ui/views/recommended/recommended_view.dart';
import 'package:athleteconnect/ui/views/register/register_view.dart';
import 'package:athleteconnect/ui/views/resource/resource_view.dart';
import 'package:athleteconnect/ui/views/resource/resource_webpage.dart';
import 'package:athleteconnect/ui/views/search/search_view.dart';
import 'package:athleteconnect/ui/views/setting/settings_screen.dart';
import 'package:athleteconnect/ui/views/setupscreen/agent_setup_screen.dart';
import 'package:athleteconnect/ui/views/athletesetup/athlete_setup_screen.dart';
import 'package:athleteconnect/ui/views/userprofile/user_profile_view.dart';
import 'package:athleteconnect/ui/views/videocall/video_call_screen.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../constants/routes.dart';
import '../ui/views/start_up/startup.dart';




GoRouter router() {
  return GoRouter(routes: <GoRoute>[
    GoRoute(
      name: "startup",
      path: AppRoutes.startUp,
      builder: (BuildContext context, GoRouterState state) =>
      const StartUpView(),
    ),

    GoRoute(
      name: AppRoutes.authScreen,
      path: AppRoutes.authScreen,
      builder: (BuildContext context, GoRouterState state) =>
      const AuthView(),
    ),

    GoRoute(
      name: AppRoutes.registerScreen,
      path: AppRoutes.registerScreen,
      builder: (BuildContext context, GoRouterState state) =>
      const RegisterView(),
    ),

    GoRoute(
      name: AppRoutes.loginScreen,
      path: AppRoutes.loginScreen,
      builder: (BuildContext context, GoRouterState state) =>
      const LoginView(),
    ),

    GoRoute(
      name: AppRoutes.agentProfileSetUpScreen,
      path: AppRoutes.agentProfileSetUpScreen,
      builder: (BuildContext context, GoRouterState state) =>
      const AgentSetUpView(),
    ),

    GoRoute(
      name: AppRoutes.athleteProfileSetupScreen,
      path: AppRoutes.athleteProfileSetupScreen,
      builder: (BuildContext context, GoRouterState state) =>
      const AthleteSetUpView(),
    ),

    GoRoute(
      name: AppRoutes.profilePhotoScreen,
      path: AppRoutes.profilePhotoScreen,
      builder: (BuildContext context, GoRouterState state) {
        // Extract the passed data from the 'extra' parameter
        final AuthData authData = state.extra as AuthData;
          if (authData.athleteProfile == null){
            return ProfileImageSetUp(isForAgent: true, file: authData.file!, athleteProfile: null, agentProfile: authData.agentProfile!,);
          }else {
            return ProfileImageSetUp(isForAgent: false, file: authData.file!, athleteProfile: authData.athleteProfile, agentProfile: null,);
          }
      },
    ),

    GoRoute(
      name: AppRoutes.homeScreen,
      path: AppRoutes.homeScreen,
      builder: (BuildContext context, GoRouterState state) {
        final user = state.extra as UserProfile;
        return DashboardView(userProfile: user);
      },
    ),

    GoRoute(
      name: AppRoutes.recommendedViewScreen,
      path: AppRoutes.recommendedViewScreen,
      builder: (BuildContext context, GoRouterState state) {
        final  user = state.extra as UserProfile;
        return  RecommendedScreen(userProfile: user,);
      },
    ),

    GoRoute(
      name: AppRoutes.userProfileScreen,
      path: AppRoutes.userProfileScreen,
      builder: (BuildContext context, GoRouterState state) {
        final userProfile = state.extra as UserProfile;
        return UserProfileScreen(userProfile: userProfile);
      },
    ),

    GoRoute(
      name: AppRoutes.chatScreen,
      path: AppRoutes.chatScreen,
      builder: (BuildContext context, GoRouterState state) {
        final  user = state.extra as UserProfile;
          return UserChatScreen(userProfile: user);
      },
    ),

    GoRoute(
      name: AppRoutes.chatHistoryScreen,
      path: AppRoutes.chatHistoryScreen,
      builder: (BuildContext context, GoRouterState state) {
        final bool isAgent = state.extra as bool? ?? false;
        return ChatHistoryScreen(isUserAgent: isAgent,);
      },
    ),

    GoRoute(
      name: AppRoutes.eventProfileScreen,
      path: AppRoutes.eventProfileScreen,
      builder: (BuildContext context, GoRouterState state) {
        final EventObject event = state.extra as EventObject;
        return EventProfileScreen(eventObject: event, isNew: event.isNew,);
        },
    ),

    GoRoute(
      name: AppRoutes.newEventScreen,
      path: AppRoutes.newEventScreen,
      builder: (BuildContext context, GoRouterState state) =>
        const CreateNewEvent(),
    ),

    GoRoute(
      name: AppRoutes.allEventScreen,
      path: AppRoutes.allEventScreen,
      builder: (BuildContext context, GoRouterState state) {
      final extraData = state.extra as ExtraData?;
      return AllEventView(isUpcoming: extraData!.boolValue, userId: extraData!.stringValue,);
  }),

    GoRoute(
      name: AppRoutes.searchViewScreen,
      path: AppRoutes.searchViewScreen,
      builder: (BuildContext context, GoRouterState state) =>
      const SearchScreen(),
    ),

  GoRoute(
  name: AppRoutes.videoViewScreen,
  path: AppRoutes.videoViewScreen,
  builder: (BuildContext context, GoRouterState state) {
  final videoData = state.extra as ExtraVideoData;
  return VideoCallScreen(currentUser: videoData.currentUser!, recipient: videoData.recipient!,);
  }

  ),

    GoRoute(
      name: AppRoutes.resourceScreen,
      path: AppRoutes.resourceScreen,
      builder: (BuildContext context, GoRouterState state) =>
      const ResourceScreen(),
    ),

    GoRoute(
      name: AppRoutes.appSettingsScreen,
      path: AppRoutes.appSettingsScreen,
        builder: (BuildContext context, GoRouterState state) {
          final userProfile = state.extra as UserProfile;
          return SettingsScreen(userProfile: userProfile);
        }
    ),

    GoRoute(
        name: AppRoutes.appWebScreen,
        path: AppRoutes.appWebScreen,
        builder: (BuildContext context, GoRouterState state) {
          final resource = state.extra as ResourceObject;
          return ResourceWebPage(resourceObject: resource);
        }
    ),




  ]);
}
