
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:one_context/one_context.dart';

import '../constants/colors.dart';
import '../constants/theme.dart';
import 'locator.dart';

class AthleteConnect extends StatelessWidget {
  GlobalKey<NavigatorState>? navigatorKey = GlobalKey<NavigatorState>();
  AthleteConnect({super.key});
  final _router = locator<GoRouter>();
  @override
  Widget build(BuildContext context) {

    return MaterialApp.router(
      title: "AthleteConnect",
      routerConfig: _router,
      theme: AppThemes.main(primaryColor: AppColors.primaryColorOptions[0]),
      debugShowCheckedModeBanner: false,
      builder: OneContext().builder,
    );
  }
}