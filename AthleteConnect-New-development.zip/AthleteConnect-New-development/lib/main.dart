import 'dart:async';
import 'dart:io';

import 'package:athleteconnect/app/app.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

import 'app/locator.dart';

void main() {
  run();
}
void run() async {
  runZonedGuarded(() async {
    debugRepaintRainbowEnabled = false;
    WidgetsFlutterBinding.ensureInitialized();
    await setUpLocator();
    await Firebase.initializeApp(
      options: DefaultFirebaseOptions.currentPlatform,
    );

    HttpOverrides.global = MyHttpOverrides();
    runApp(AthleteConnect());
  }, (error, stack) {});
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}

