
class AppRoutes {
  static const startUp = '/';
  static const splashScreen = '/splash';
  static const loginScreen = '/login-view';
  static const homeScreen = '/home-view';
  static const authScreen = '/auth-view';
  static const registerScreen = '/register-view';
  static const profileImageSetUpScreen = '/profile-image-setup';
  static const agentProfileSetUpScreen = '/agent-profile-setup';
  static const athleteProfileSetupScreen = '/athlete-profile-setup';
  static const profilePhotoScreen = '/profile-photo-screen';
  static const searchViewScreen = '/search-view-screen';
  static const recommendedViewScreen = '/recommended-view-screen';
  static const eventProfileScreen = '/event-profile-screen';
  static const eventListingScreen = '/event-listing-screen';
  static const newEventScreen = '/new-event_screen';
  static const allEventScreen = '/all-event_screen';
  static const chatHistoryScreen = '/chat-history-screen';
  static const chatScreen = '/chat-screen';
  static const userProfileScreen = '/user-profile-screen';
  static const videoViewScreen = '/video-view-screen';
  static const resourceScreen = '/resource-view-screen';
  static const appSettingsScreen = '/app-settings-screen';
  static const appWebScreen = '/app-web-screen';


}