
class Variables {
  static const String login = "Login";
  static const String success = "success";
  static const String ALREADYLOGEDIN = "userExists";
  static const String LoggedInUserId = "LoggedInUserId";
  static const String Users = "Users";
  static const String id = "id";
  static const String Resource = "resources";
  static const String legal = "legal";
  static const String others = "others";
  static const String userType = "UserType";
  static const String authIntro = "We are affiliates and Members of the National Society of Black Engineers. We are also Members Black Honour Society, Kennesaw State University, Georgia USA.  A STEM professional body dedicated to the professional and academic development of black engineers in the U.S.A.";
  static const String confirmEmail = "Please click the link sent to your registered email address to validate your email";
  static const String defaultRating = "is a talented agent and is quite good for his pay. I wouldn't hesitate referring or recommending him to anyone";
  static const String profile = "Profile";
  static const String AGENT = "AGENT";
  static const String ATHLETE = "ATHLETE";
  static const String TYPE = "type";
  static const String events = "events";
  static const String oldLogEvents = "oldEvents";
  static const String RegisteredEvents = "registeredEvents";
  static const String EventAttendees = "registered_attendees";
  static const String defaultMessage = "Hello This is a test message for you who want to be in partnership with us. We are very carefull "
      "of who we bring into our space, so please ensure that due diligence is taken";
  static const String allReviews = "allReviews";
  static const String reviews = "reviews";
  static const String LastMessage = 'lastMsg';
  static const String Messages = "messages";
  static const String UserPrivacyPref = "privacyPref";

}