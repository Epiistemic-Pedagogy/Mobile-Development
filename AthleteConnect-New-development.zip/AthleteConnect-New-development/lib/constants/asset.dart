
class AppAssets {

  // images
  static const loginBg = 'assets/images/login_bg.png';
  static const registerBg = 'assets/images/register_bg.png';
  static const authBg = 'assets/images/auth.png';
  static const verifyEmail = 'assets/images/ver.png';
  static const photoAvatar = 'assets/images/photo_avatar.png';
  static const peopleImg = 'assets/images/people.png';
  static const confrImg = 'assets/images/confr.png';
  static const faceImage = 'assets/images/face.png';
  static const ericface = 'assets/images/eric.png';
  static const markFace = 'assets/images/mark.png';
  static const cupImage = 'assets/images/cup.png';

  // Svgs
  static const logo = 'assets/svg/applogo.svg';
  static const appLogo = 'assets/svg/logo.svg';
  static const whiteLogo = 'assets/svg/logo_white.svg';
  static const successLogo = 'assets/svg/success_logo.svg';
  static const mediaAttach = 'assets/svg/media_attach.svg';



}