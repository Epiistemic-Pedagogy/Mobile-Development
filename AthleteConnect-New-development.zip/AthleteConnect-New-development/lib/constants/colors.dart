
import 'dart:ui';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF1575E5);
  static const buttonColor = Color(0xFFDA6D09);
  static const white = Color(0xFFFFFFFF);
  static const lightButton = Color(0xFFEFF5FD);
  static const normalBlack = Color(0xFF2E2E2E);
  static const fillColor = Color(0xFF282827);
  static const deepBlack = Color(0xFF010100);
  static const textGrey = Color(0xFFC5C5C5);
  static const fieldGrey = Color(0xff666768);
  static const solidGrey = Color(0xff3A3939);
  static const boxBlack = Color(0xFF0C0D0E);
  static const appGreen = Color(0xff289E65);

  static List<Color> primaryColorOptions = const [
    primary,
  ];

  static Color getShade(Color color, {bool darker = false, double value = .1}) {
    assert(value >= 0 && value <= 1);

    final hsl = HSLColor.fromColor(color);
    final hslDark = hsl.withLightness(
        (darker ? (hsl.lightness - value) : (hsl.lightness + value))
            .clamp(0.0, 1.0));

    return hslDark.toColor();
  }

  static MaterialColor getMaterialColorFromColor(Color color) {
    Map<int, Color> colorShades = {
      50: getShade(color, value: 0.5),
      100: getShade(color, value: 0.4),
      200: getShade(color, value: 0.3),
      300: getShade(color, value: 0.2),
      400: getShade(color, value: 0.1),
      500: color, //Primary value
      600: getShade(color, value: 0.1, darker: true),
      700: getShade(color, value: 0.15, darker: true),
      800: getShade(color, value: 0.2, darker: true),
      900: getShade(color, value: 0.25, darker: true),
    };
    return MaterialColor(color.value, colorShades);
  }

}
