
import 'package:athleteconnect/constants/variables.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';

class EndpointRef {

  //await FirebaseAuth.instance.signOut();
  void signOutUser(FirebaseAuth auth) async{
    await auth.signOut();
  }


  Reference dpRef(){
    return  FirebaseStorage.instance.ref().child("dp");
  }

  Reference otherMediaRef(){
    return  FirebaseStorage.instance.ref().child("extra");
  }

  Reference eventMediaRef(){
    return  FirebaseStorage.instance.ref().child("eventdp");
  }

  DatabaseReference userRef(){
    return FirebaseDatabase.instance.ref(Variables.Users);
  }

  DatabaseReference currentRef(){
    return FirebaseDatabase.instance.ref(Variables.Users);
  }

  DatabaseReference currentEvent(){
    return FirebaseDatabase.instance.ref(Variables.events);
  }

  DatabaseReference oldEvent(){
    return FirebaseDatabase.instance.ref(Variables.oldLogEvents);
  }

  DatabaseReference userProfileRef(String userId){
    return FirebaseDatabase.instance.ref(Variables.Users).child(userId).child(Variables.profile);
  }
  DatabaseReference userTypeRef(String userId){
    return FirebaseDatabase.instance.ref(Variables.Users).child(userId).child(Variables.TYPE);
  }
  DatabaseReference userEventRef(String userID){
    return FirebaseDatabase.instance.ref(Variables.Users).child(userID).child(Variables.events);
  }

  DatabaseReference userRegisteredEventRef(String userID, String eventID){
    return FirebaseDatabase.instance.ref(Variables.Users).child(userID).child(Variables.RegisteredEvents).child(eventID);
  }

  DatabaseReference registeredMembers(String eventId){
    return FirebaseDatabase.instance.ref(Variables.EventAttendees).child(eventId);
  }

  DatabaseReference allReviewRef(){
    return FirebaseDatabase.instance.ref(Variables.allReviews);
  }

  DatabaseReference userReviews(String userId){
    return FirebaseDatabase.instance.ref(Variables.Users).child(userId).child(Variables.reviews);
  }

  DatabaseReference userLastMessage(String senderId, String receiverId){
    return FirebaseDatabase.instance.ref(Variables.Users).child(senderId).child(Variables.LastMessage).child(receiverId);
  }

  DatabaseReference userMessages(String senderId, String receiverId){
    return FirebaseDatabase.instance.ref(Variables.Users).child(senderId).child(Variables.Messages).child(receiverId);
  }

  DatabaseReference legalResource(){
    return FirebaseDatabase.instance.ref(Variables.Resource).child(Variables.legal);
  }

  DatabaseReference generalResource(){
    return FirebaseDatabase.instance.ref(Variables.Resource).child(Variables.others);
  }

  DatabaseReference userPrivacySettingRef(String userId){
    return FirebaseDatabase.instance.ref(Variables.Users).child(userId).child(Variables.UserPrivacyPref);
  }







}