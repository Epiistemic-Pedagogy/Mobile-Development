

import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../constants/variables.dart';

class PrefManager {

  Future<String?> read(String key) async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getString(key) != null){
      return jsonDecode(prefs.getString(key)!);
    }else{
      return null;
    }

  }

  Future<Map<String, dynamic>?> readObject(String key) async {
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getString(key) != null){
      Map<String, dynamic> convertedApiResponse = jsonDecode(prefs.getString(key)!);
      return convertedApiResponse;
    }else{
      return null;
    }


  }

  save(String key, value) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(key, json.encode(value));
  }

  remove(String key) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove(key);
  }

  logInUser(String token) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(Variables.login, token);
  }

  clearAll() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.clear();
  }
}