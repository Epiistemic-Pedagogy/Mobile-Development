

import 'package:athleteconnect/constants/asset.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/ui/views/recommended/recommended_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../constants/colors.dart';
import '../widgets/custom_button.dart';

class FilterOptionDialog extends StatelessWidget {
  const FilterOptionDialog(
      {super.key,
        required this.viewModel,
      });
  final RecommendedViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      margin: const EdgeInsets.only(top: 10, left: 10),
      child: Column(
        crossAxisAlignment:  CrossAxisAlignment.stretch,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(''),

              InkWell(
                onTap: () {
                  Navigator.of(context).pop();
                },
                child: const Icon(Icons.close, color: AppColors.buttonColor, weight: 10,),
              )
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          Text(
            "Filter options",
            textAlign: TextAlign.start,
            style: context.textTheme.titleMedium
                ?.copyWith(color: AppColors.textGrey),
          ),
          const SizedBox(
            height: 17,
          ),
          InkWell(
            onTap: (){
              viewModel.filterBySportUsers();
              Navigator.of(context).pop();
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Filter by Sport Interest",
                  textAlign: TextAlign.start,
                  style: context.textTheme.bodyMedium
                      ?.copyWith(color: AppColors.white),
                ),

                const Icon(Icons.arrow_forward_ios, color: AppColors.buttonColor, size: 18,)
              ],
            ),
          ),
          const SizedBox(
            height: 17,
          ),
          InkWell(
            onTap: (){
              viewModel.filterBasedOnAI();
              Navigator.of(context).pop();
            },
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "AI Based Filter",
                  textAlign: TextAlign.start,
                  style: context.textTheme.bodyMedium
                      ?.copyWith(color: AppColors.white),
                ),

                const Icon(Icons.arrow_forward_ios, color: AppColors.buttonColor, size: 18,)
              ],
            ),
          ),
          const SizedBox(
            height: 17,
          ),
          InkWell(
            onTap: (){
              viewModel.clearAllFilters();
              Navigator.of(context).pop();
            },
            child:  Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Clear all filters",
                  textAlign: TextAlign.start,
                  style: context.textTheme.bodyMedium
                      ?.copyWith(color: AppColors.white),
                ),

                const Icon(Icons.arrow_forward_ios, color: AppColors.buttonColor, size: 18,)
              ],
            ),
          ),

          const SizedBox(
            height: 6,
          ),
          const Spacer(),
          // CustomButton(text: "Continue",
          //   onTap: (){
          //     Navigator.of(context).pop();
          //
          //   },
          //   textColor: AppColors.white ,),
        ],
      ),
    );
  }
}