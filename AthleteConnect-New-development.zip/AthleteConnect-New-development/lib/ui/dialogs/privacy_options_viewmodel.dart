

import 'package:athleteconnect/constants/variables.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:googleapis/tagmanager/v1.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../models/PrivateData.dart';
import '../../services/endpoint_ref.dart';
import '../../services/prefmanager.dart';

class PrivacyOptionsViewModel extends BaseViewModel {
  PrivacyData? privacyData;
  bool isSavingData  = false;
  bool isInitialising = false;
  final endPointRef = EndpointRef();
  final auth = FirebaseAuth.instance;
  final prefManager = PrefManager();

  void refreshView(){
    notifyListeners();
  }

  void savePrivacySettings() async {
    isSavingData = true;
    notifyListeners();
    await endPointRef.userPrivacySettingRef(auth!.currentUser!.uid).set(privacyData!.toJson());
    final userSettings =  PrivacyData.fromJson(privacyData!.toJson());
    prefManager.save(Variables.UserPrivacyPref, userSettings);
    isSavingData = false;
    notifyListeners();
    showToastMessage("Saved");
  }



  void showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }

}