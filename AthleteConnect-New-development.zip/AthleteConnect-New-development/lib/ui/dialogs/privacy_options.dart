

import 'package:athleteconnect/app/util.dart';
import 'package:athleteconnect/constants/asset.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/PrivateData.dart';
import 'package:athleteconnect/models/extra_data.dart';
import 'package:athleteconnect/ui/dialogs/privacy_options_viewmodel.dart';
import 'package:athleteconnect/ui/views/recommended/recommended_viewmodel.dart';
import 'package:athleteconnect/ui/views/setting/setting_view_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:googleapis/admob/v1.dart';
import 'package:googleapis/authorizedbuyersmarketplace/v1.dart';
import 'package:stacked/stacked.dart';

import '../../constants/colors.dart';
import '../widgets/custom_button.dart';

class PrivacyOptionsDialog extends StatelessWidget {
  const PrivacyOptionsDialog({super.key,
    required this.privacyObject,
    required this.isAgent,

  });

  final PrivacyData privacyObject;
  final bool isAgent;

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<PrivacyOptionsViewModel>.reactive(
        viewModelBuilder: () => PrivacyOptionsViewModel(),
        onModelReady: (viewModel) {
          viewModel.privacyData = privacyObject;
        },
        builder: (context, viewModel, child) =>
            Container(
                padding: const EdgeInsets.all(15),
                margin: const EdgeInsets.only(top: 10, left: 10),
                child: Stack(
                  children: [
                    Column(
                      children: [
                        Expanded(child: ListView(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(''),

                                InkWell(
                                  onTap: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: const Icon(
                                    Icons.close, color: AppColors.buttonColor,
                                    weight: 10,),
                                )
                              ],
                            ),
                            const SizedBox(
                              height: 5,
                            ),
                            Text(
                              "Data Options",
                              textAlign: TextAlign.start,
                              style: context.textTheme.titleMedium
                                  ?.copyWith(color: AppColors.textGrey),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Email",
                                  textAlign: TextAlign.start,
                                  style: context.textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.white),
                                ),

                                Switch(
                                  value: viewModel.privacyData!.email!,
                                  onChanged: (bool newValue) {
                                    viewModel.privacyData!.email = newValue;
                                    viewModel.refreshView();
                                  },
                                  activeColor: AppColors.buttonColor,
                                  // Customize color when on
                                  activeTrackColor: AppColors.fieldGrey,
                                  inactiveThumbColor: AppColors.fillColor,
                                  // Customize color when off
                                  inactiveTrackColor: AppColors.fieldGrey,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),

                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Phone number",
                                  textAlign: TextAlign.start,
                                  style: context.textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.white),
                                ),

                                Switch(
                                  value: viewModel.privacyData!.phone!,
                                  onChanged: (bool newValue) {
                                    viewModel.privacyData!.phone = newValue;
                                    viewModel.refreshView();
                                  },
                                  activeColor: AppColors.buttonColor,
                                  // Customize color when on
                                  activeTrackColor: AppColors.fieldGrey,
                                  inactiveThumbColor: AppColors.fillColor,
                                  // Customize color when off
                                  inactiveTrackColor: AppColors.fieldGrey,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Bio",
                                  textAlign: TextAlign.start,
                                  style: context.textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.white),
                                ),

                                Switch(
                                  value: viewModel.privacyData!.bio!,
                                  onChanged: (bool newValue) {
                                    viewModel.privacyData!.bio = newValue;
                                    viewModel.refreshView();
                                  },
                                  activeColor: AppColors.buttonColor,
                                  // Customize color when on
                                  activeTrackColor: AppColors.fieldGrey,
                                  inactiveThumbColor: AppColors.fillColor,
                                  // Customize color when off
                                  inactiveTrackColor: AppColors.fieldGrey,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            isAgent ?
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Clients",
                                  textAlign: TextAlign.start,
                                  style: context.textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.white),
                                ),

                                Switch(
                                  value: viewModel.privacyData!.clients!,
                                  onChanged: (bool newValue) {
                                    viewModel.privacyData!.clients = newValue;
                                    viewModel.refreshView();
                                  },
                                  activeColor: AppColors.buttonColor,
                                  // Customize color when on
                                  activeTrackColor: AppColors.fieldGrey,
                                  inactiveThumbColor: AppColors.fillColor,
                                  // Customize color when off
                                  inactiveTrackColor: AppColors.fieldGrey,
                                ),
                              ],
                            ) : Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Education",
                                  textAlign: TextAlign.start,
                                  style: context.textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.white),
                                ),

                                Switch(
                                  value: viewModel.privacyData!.education!,
                                  onChanged: (bool newValue) {
                                    viewModel.privacyData!.education = newValue;
                                    viewModel.refreshView();
                                  },

                                  activeColor: AppColors.buttonColor,
                                  // Customize color when on
                                  activeTrackColor: AppColors.fieldGrey,
                                  inactiveThumbColor: AppColors.fillColor,
                                  // Customize color when off
                                  inactiveTrackColor: AppColors.fieldGrey,
                                ),
                              ],
                            ),

                            const SizedBox(
                              height: 10,
                            ),
                            !isAgent ? Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Achievements",
                                  textAlign: TextAlign.start,
                                  style: context.textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.white),
                                ),

                                Switch(
                                  value: viewModel.privacyData!.achievements!,
                                  onChanged: (bool newValue) {
                                    viewModel.privacyData!.achievements = newValue;
                                    viewModel.refreshView();
                                  },
                                  activeColor: AppColors.buttonColor,
                                  // Customize color when on
                                  activeTrackColor: AppColors.fieldGrey,
                                  inactiveThumbColor: AppColors.fillColor,
                                  // Customize color when off
                                  inactiveTrackColor: AppColors.fieldGrey,
                                ),
                              ],
                            ) : Container(),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Attachments",
                                  textAlign: TextAlign.start,
                                  style: context.textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.white),
                                ),

                                Switch(
                                  value: viewModel.privacyData!.media!,
                                  onChanged: (bool newValue) {
                                    viewModel.privacyData!.media = newValue;
                                    viewModel.refreshView();
                                  },
                                  activeColor: AppColors.buttonColor,
                                  // Customize color when on
                                  activeTrackColor: AppColors.fieldGrey,
                                  inactiveThumbColor: AppColors.fillColor,
                                  // Customize color when off
                                  inactiveTrackColor: AppColors.fieldGrey,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Allow everyone to send you messages",
                                  textAlign: TextAlign.start,
                                  style: context.textTheme.bodyMedium
                                      ?.copyWith(color: AppColors.white,
                                      fontWeight: FontWeight.w300,
                                      fontSize: 14),
                                ),

                                Switch(
                                  value: viewModel.privacyData!.openMessages!,
                                  onChanged: (bool newValue) {
                                    viewModel.privacyData!.openMessages = newValue;
                                    viewModel.refreshView();
                                  },
                                  activeColor: AppColors.buttonColor,
                                  // Customize color when on
                                  activeTrackColor: AppColors.fieldGrey,
                                  inactiveThumbColor: AppColors.fillColor,
                                  // Customize color when off
                                  inactiveTrackColor: AppColors.fieldGrey,
                                ),
                              ],
                            ),
                            const SizedBox(
                              height: 15,
                            ),

                          ],
                        ),),
                        Padding(
                          padding: const EdgeInsets.all(5.0),
                          child: viewModel.isSavingData ? Text(
                            "Saving Changes ...",
                            textAlign: TextAlign.center,
                            style: context.textTheme.bodyMedium
                                ?.copyWith(color: AppColors.white,
                                fontWeight: FontWeight.w300,
                                fontSize: 14),
                          ) : CustomButton(text:  "Save",
                            onTap: () {
                              viewModel.savePrivacySettings();
                            },
                            textColor: AppColors.white,),
                        ),
                      ],
                    ),
                    viewModel.isInitialising ? Utils().loadingContainer("", AppColors.white, true) : Container()
                  ],
                ),
            ));
  }
}