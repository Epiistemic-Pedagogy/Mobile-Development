

import 'package:athleteconnect/constants/asset.dart';
import 'package:athleteconnect/constants/colors.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/views/userprofile/user_profile_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:googleapis/admob/v1.dart';

import '../widgets/custom_button.dart';

class AddReview extends StatelessWidget {
  const AddReview (
      {super.key,
        required this.viewModel,
      });

   final UserProfileViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB( 16, 5, 16,
        MediaQuery.of(context).viewInsets.bottom, // Adds padding to accommodate the keyboard
      ),
      child:   ListView(
        children: [
          const SizedBox(
            height: 16,
          ),
          Align(
            alignment: Alignment.topRight,
            child:  InkWell(
              onTap: () {
                Navigator.of(context).pop();
              },
              child: const Icon(Icons.close, color: AppColors.white, weight: 10,),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Center(
            child: SvgPicture.asset(AppAssets.whiteLogo, height: 50, width: 70,),
          ),
          const SizedBox(
            height: 10,
          ),
          Align(
            alignment: Alignment.center,
            child: Text(
              "Drop a Rating",
              textAlign: TextAlign.start,
              style: context.textTheme.titleMedium
                  ?.copyWith(color: AppColors.white),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Align(
            alignment: Alignment.center,
            child: RatingBar(
              initialRating: 0,
              direction: Axis.horizontal,
              allowHalfRating: false,
              itemCount: 5,
              ratingWidget: RatingWidget(
                  full: Icon(
                    Icons.star, color: AppColors.appGreen, size: 40,),
                  empty: Icon(Icons.star, color: AppColors.textGrey,),
                half: Icon(Icons.star, color: AppColors.textGrey,),
              ),
              itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
              onRatingUpdate: (rating) {
                viewModel.addUserRating(rating.toInt());
              },
            )
          ),
          const SizedBox(
            height: 10,
          ),
          Align(
            alignment: Alignment.center,
            child: Text(
              "Thank you for rating, Please add a comment",
              textAlign: TextAlign.start,
              style: context.textTheme.titleMedium
                  ?.copyWith(color: AppColors.white),
            ),
          ),
          const SizedBox(
            height: 15,
          ),
          Container(
              margin: EdgeInsets.only(top: 20.0),
              height: 120.0,
              child: Container(
                padding: EdgeInsets.all(10.0),
                decoration: BoxDecoration(
                    border: Border.all(
                        color: AppColors.textGrey,
                        style: BorderStyle.solid,
                        width: 0.5
                    ),
                    color: Colors.transparent,
                    borderRadius: BorderRadius.circular(4.0)
                ),
                child:  Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Expanded(
                      child: TextFormField(
                        keyboardType: TextInputType.multiline,
                        maxLines: null,
                        controller: viewModel.reviewController,
                        style: context.textTheme.bodyMedium?.copyWith(
                            color:  AppColors.white,
                            fontSize: 14, fontWeight: FontWeight.normal),
                        decoration: InputDecoration(
                          focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: AppColors.fieldGrey)
                          ),
                          hintText: 'Comments and Review',
                          hintStyle: context.textTheme.bodyLarge
                            ?.copyWith(color: AppColors.textGrey, fontWeight: FontWeight.w300),
                        ),
                      ),
                    ),
//                    Icon(Icons.expand_more,
//                        color: colorClass.appGrey,
//                        size: 13.0),
                  ],
                ),
              )
          ),

          const SizedBox(
            height: 15,
          ),

           viewModel.isAddingReview ? Center(
             child: CircularProgressIndicator(
               color: AppColors.buttonColor,
             ),
           ) : CustomButton(text: "Submit Review",
            onTap: (){
            viewModel.saveUSerRating(context);
            },
            color: AppColors.buttonColor,
            textColor: AppColors.white ,),
        ],
      ),
    );
  }
}