

import 'package:athleteconnect/constants/asset.dart';
import 'package:athleteconnect/constants/variables.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/ui/views/login/login_viewmodel.dart';
import 'package:athleteconnect/ui/views/register/register_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

import '../../constants/colors.dart';
import '../widgets/custom_button.dart';

class ConfirmEmailBottomSheet extends StatelessWidget {
  const ConfirmEmailBottomSheet(
      {super.key,
        required this.onConfirmAction,
        required this.isLogin,
        required this.loginViewModel,
        required this.registerViewModel
      });

  final VoidCallback onConfirmAction;
  final bool isLogin;
  final LoginViewModel? loginViewModel;
  final RegisterViewModel? registerViewModel;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      margin: const EdgeInsets.only(top: 10, left: 10),
      child: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const SizedBox(
                height: 20,
              ),
              Align(
                alignment: Alignment.center,
                child: Text(
                  "",
                  textAlign: TextAlign.start,
                  style: context.textTheme.titleMedium
                      ?.copyWith(color: AppColors.white),
                ),
              ),
              InkWell(
                onTap: () {
                  Navigator.of(context).pop();
                },
                child: const Icon(Icons.close, color: AppColors.white, weight: 10,),
              )

            ],
          ),
          const SizedBox(
            height: 6,
          ),
          Align(
              alignment: Alignment.center,
              child: Column(
                children: [
                  isLogin ? Image.asset(AppAssets.verifyEmail, width: 60, height: 60,):
                  SvgPicture.asset(AppAssets.successLogo, width: 60, height: 60,),

                  Text( isLogin ? "Verify Email" :
                     "Account created successfully",
                    textAlign: TextAlign.center,
                    style: context.textTheme.bodyLarge
                        ?.copyWith(color: AppColors.white, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  Text(
                    Variables.confirmEmail,
                    textAlign: TextAlign.center,
                    style: context.textTheme.bodyMedium
                        ?.copyWith(color: AppColors.white, fontWeight: FontWeight.w400),
                  ),

                ],
              )
          ),

          const SizedBox(
            height: 15,
          ),

          const Spacer(),

          CustomButton(text: "Continue",
            onTap: (){
            Navigator.of(context).pop();
            isLogin ? loginViewModel!.goToNextPage()
                  : registerViewModel!.goToLogin() ;

            },
            textColor: AppColors.white ,),
          const SizedBox(
            height: 4,
          ),
          Align(
            alignment: Alignment.center,
            child:  InkWell(
              onTap: () {
                isLogin ? loginViewModel!.resendEmailConfirmation()
                    : {};
              },
              child: Text(
                "Resend email confirmation mail",
                textAlign: TextAlign.center,
                style: context.textTheme.bodySmall
                    ?.copyWith(color: AppColors.buttonColor, fontWeight: FontWeight.w400, fontSize: 12),
              ),
            )
          )
            ],
          ),
      );
  }
}