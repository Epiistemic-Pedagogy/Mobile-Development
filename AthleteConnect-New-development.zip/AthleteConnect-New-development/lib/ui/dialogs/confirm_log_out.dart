
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/ui/views/setting/setting_view_model.dart';
import 'package:athleteconnect/ui/views/userprofile/user_profile_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../constants/colors.dart';
import '../../services/prefmanager.dart';

class ConfirmLogOut {
  final prefManager = PrefManager();

  void showMyDialog(BuildContext context, SettingViewModel viewModel) async{
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            backgroundColor: AppColors.white,
            title: Text(
              'Logout',
              style: context.textTheme.titleLarge?.copyWith(
                  color:  AppColors.boxBlack,
                  fontSize: 16, fontWeight: FontWeight.normal),
            ),
            content: Text('Are you sure you want to log out?',
              style: context.textTheme.bodyMedium?.copyWith(
                  color:  AppColors.deepBlack,
                  fontSize: 14, fontWeight: FontWeight.normal),),
            actions: <Widget>[
              TextButton(child:  Text('No', style: context.textTheme.bodyMedium?.copyWith(
                  color:  AppColors.deepBlack,
                  fontSize: 14, fontWeight: FontWeight.normal), ), onPressed: () {
                Navigator.pop(context);
              }),
              TextButton(child:  Text('Yes', style: context.textTheme.bodyMedium?.copyWith(
                  color:  AppColors.deepBlack,
                  fontSize: 14, fontWeight: FontWeight.normal),), onPressed: () {
                viewModel.signOutUser();
                Navigator.pop(context);
              }),
            ],
          );
        }
    );
  }
}