

import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../constants/colors.dart';

class CustomDropdown extends StatefulWidget {
  const CustomDropdown(
      {super.key,
        required this.assetList,
        required this.selectedValue,
        required this.placeHolderText,
        required this.onChanged,
        });
  final List<String> assetList;
  final String? selectedValue;
  final String placeHolderText;
  final ValueChanged<String?>? onChanged; // Callback when an item is selected
  @override
  _CustomDropdown createState() => _CustomDropdown();
}


class _CustomDropdown extends State<CustomDropdown> {

  @override
  Widget build(BuildContext context) {
    return DropdownButton<String>(
      isExpanded: true,
      underline: Container(),
      hint: Text(widget.placeHolderText), // Placeholder text
      value: widget.selectedValue, // Currently selected value
      onChanged: widget.onChanged,
      icon: const Icon(Icons.arrow_drop_down, color: AppColors.white, size: 13,),
      dropdownColor: AppColors.deepBlack,
      items: widget.assetList.map((String item) {
        return DropdownMenuItem<String>(
          value: item,
          child: Text(item, style: context.textTheme.bodyMedium?.copyWith(
          color: AppColors.white,
              fontWeight: FontWeight.w700
          ),),
        );
      }).toList(),
    );
  }
}