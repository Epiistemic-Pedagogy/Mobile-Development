

import 'package:athleteconnect/constants/colors.dart';
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:flutter/cupertino.dart';

class ChatBubble extends StatelessWidget {

  const ChatBubble({super.key,
    required this.content,
    required this.right,
  });

  final String content;
  final bool right;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: right ? EdgeInsets.only(left: 10) : EdgeInsets.only(right: 15),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: right ? AppColors.buttonColor : AppColors.appGreen,
        borderRadius:  BorderRadius.only(
          topRight:  Radius.circular(10),
          topLeft: Radius.circular(10),
          bottomLeft: right ? Radius.circular(10) : Radius.circular(0),
          bottomRight: right? Radius.circular(0) : Radius.circular(10),
        ),
        border: Border.all(color: right ? AppColors.buttonColor : AppColors.appGreen, width: .7),
      ),
      child: Text(
        content,
        style: context.textTheme.titleLarge?.copyWith(
        color: AppColors.white,
          fontSize: 15, fontWeight: FontWeight.w600),)
    );
  }
}