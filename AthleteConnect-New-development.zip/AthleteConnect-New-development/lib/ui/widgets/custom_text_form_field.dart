
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../../constants/colors.dart';

class CustomTextFormField extends StatefulWidget {
  const CustomTextFormField(
      {super.key,
        required this.label,
        this.hint,
        required this.controller,
        this.isPassword = false,
        this.isObscure = false,
        this.errorText,
        this.onTap,
        this.onChange,
        this.validate,
        this.textInputType,
        this.readOnly = false,
        this.floating = false,
        this.suffix,
        this.focus,
        this.max});
  final String label;
  final String? hint;
  final TextEditingController controller;
  final bool isPassword;
  final bool isObscure;
  final String? errorText;
  final FocusNode? focus;
  final VoidCallback? onTap;
  final Function(String?)? onChange;
  final String? Function(String?)? validate;
  final TextInputType? textInputType;
  final bool readOnly;
  final bool floating;
  final int? max;
  final Widget? suffix;
  @override
  State<CustomTextFormField> createState() => _CustomTextFormFieldState();
}

class _CustomTextFormFieldState extends State<CustomTextFormField> {
  bool _isFocused = false;
  @override
  Widget build(BuildContext context) {
    return
      TextFormField(
      controller: widget.controller,
      obscureText: widget.isObscure,
      keyboardType: widget.textInputType ?? TextInputType.text,
      readOnly: widget.readOnly,
      validator: widget.validate,
      focusNode: widget.focus,
      maxLines: widget.max,
      onChanged: widget.onChange,
      style: context.textTheme.labelLarge?.copyWith(color: AppColors.white),
      decoration: InputDecoration(
          filled: true,
          label: Text(widget.label),
          labelStyle: context.textTheme.labelMedium?.copyWith(
              color: _isFocused ? AppColors.textGrey : AppColors.white),
          fillColor: AppColors.fillColor,
          hintText: widget.hint,
          hintStyle: TextStyle(
              color: AppColors.buttonColor.withOpacity(0.3), fontSize: 11),
          errorText: widget.errorText,
          floatingLabelBehavior: widget.floating
              ? FloatingLabelBehavior.always
              : FloatingLabelBehavior.auto,
          border: const UnderlineInputBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(7), topRight: Radius.circular(7)),
            borderSide: BorderSide(color: AppColors.white),
          ),
          enabledBorder: const UnderlineInputBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(7), topRight: Radius.circular(7)),
            borderSide: BorderSide(color: AppColors.white),
          ),
          focusedBorder: const UnderlineInputBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(7), topRight: Radius.circular(7)),
            borderSide: BorderSide(
                color: AppColors.buttonColor), // Orange border when focused
          ),
          suffixIcon: widget.suffix ??
              (widget.isPassword
                  ? IconButton(
                onPressed: widget.onTap,
                icon: Icon(
                  widget.isObscure
                      ? Icons.visibility_off_outlined
                      : Icons.visibility_outlined,
                  color: AppColors.white,
                ),
              )
                  : null)),
    );
  }
}