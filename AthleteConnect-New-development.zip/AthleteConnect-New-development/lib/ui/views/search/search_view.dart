
import 'package:athleteconnect/constants/colors.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/events.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/views/search/search_viewmodel.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/util.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<SearchViewModel>.reactive(
        viewModelBuilder: () => SearchViewModel(),
        onModelReady: (model) {
          model.auth = FirebaseAuth.instance;
          model.getAllAppData();
        },
        builder: (context, model, child) =>
            Scaffold(
              backgroundColor: AppColors.fillColor,
              appBar: AppBar(
                backgroundColor: AppColors.fillColor,
                leading: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(width: 10,),
                    InkWell(
                      onTap: () => Navigator.of(context).pop(),
                      child: const Icon(Icons.arrow_back, color: AppColors.white, size: 24,),
                    ),

                  ],
                ),
                title:Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const SizedBox(width: 10,),
                    Expanded(child: TextFormField(
                      controller: model.searchController,
                      maxLines: 1,
                      style: context.textTheme.labelLarge?.copyWith(color: AppColors.white, fontSize: 12,fontWeight: FontWeight.w400),
                      decoration:   InputDecoration(
                        filled: false,
                        hintText: "Search anything",
                        hintStyle: const TextStyle(
                            color: AppColors.textGrey, fontSize: 11),
                        focusedBorder:  UnderlineInputBorder(
                          borderRadius:  BorderRadius.circular(3),
                          // Orange border when focused
                        ),
                        border: UnderlineInputBorder(
                          borderRadius:  BorderRadius.circular(3),
                          borderSide: const BorderSide(
                              color: AppColors.fillColor), // Orange border when focused
                        ),
                        enabledBorder: UnderlineInputBorder(
                          borderRadius:  BorderRadius.circular(3),
                          borderSide: const BorderSide(
                              color: AppColors.fillColor), // Orange border when focused
                        ),
                      ),
                    ),),
                    const SizedBox(width: 10.0),



                  ],
                ),

                actions: [
                  Align(
                    alignment: Alignment.centerRight,
                    child: GestureDetector(
                      onTap: (){
                        model.performSearch();
                      },
                      child: Text(
                        'Search',
                        style: context.textTheme.bodyMedium?.copyWith(
                            color:  AppColors.buttonColor,
                            fontSize: 13, fontWeight: FontWeight.w400),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10.0),
                ],
              ),
              body: Padding(
                padding: const EdgeInsets.all(12),
                child: Expanded(
                  child: ListView(
                      children: [
                        const SizedBox(height: 10.0),
                        Text(
                          'Agent',
                          style: context.textTheme.bodyMedium?.copyWith(
                              color:  AppColors.textGrey,
                              fontSize: 13, fontWeight: FontWeight.w400),
                        ),
                        const SizedBox(height: 6,),
                        model.agentList.isNotEmpty?
                        Expanded(child:  ListView.builder(
                            itemCount: model.agentList.length,
                            physics: const NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemBuilder: (BuildContext context, int index) {
                              return SearchUser(viewModel: model, userProfile: model.agentList[index]);
                            }
                        ))
                            :
                        Center(
                          child: Text(
                            'No data',
                            style: context.textTheme.bodyMedium?.copyWith(
                                color:  AppColors.textGrey,
                                fontSize: 13, fontWeight: FontWeight.w400),
                          ),
                        ),
                        const SizedBox(height: 6,),
                        Text(
                          'Athlete',
                          style: context.textTheme.bodyMedium?.copyWith(
                              color:  AppColors.textGrey,
                              fontSize: 13, fontWeight: FontWeight.w400),
                        ),
                        const SizedBox(height: 6,),
                        model.athleteList.isNotEmpty ?
                        Expanded(
                          child:
                          ListView.builder(
                              itemCount: model.athleteList.length,
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemBuilder: (BuildContext context, int index) {
                                return Wrap(children: [
                                  SearchUser(viewModel: model, userProfile: model.athleteList[index])
                                ],);
                              }
                          ),
                        ) : Center(
                          child: Text(
                            'No data',
                            style: context.textTheme.bodyMedium?.copyWith(
                                color:  AppColors.textGrey,
                                fontSize: 13, fontWeight: FontWeight.w400),
                          ),
                        ),
                        const SizedBox(height: 6,),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Events',
                            style: context.textTheme.bodyMedium?.copyWith(
                                color:  AppColors.textGrey,
                                fontSize: 13, fontWeight: FontWeight.w400),
                          ),
                        ),

                        const SizedBox(height: 6,),
                        model.filteredEventList.isEmpty ?  Center(
                          child: Text(
                            'No data',
                            style: context.textTheme.bodyMedium?.copyWith(
                                color:  AppColors.textGrey,
                                fontSize: 13, fontWeight: FontWeight.w400),
                          ),
                        ) : Expanded(
                          child:
                          ListView.builder(
                              itemCount: model.filteredEventList.length,
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemBuilder: (BuildContext context, int index) {
                                return SearchEventItem(eventObject: model.filteredEventList[index], model: model);
                              }
                          ),
                        ),


                      ]
                  ),
                )
              ),

            ));
  }

}

class SearchUser extends StatelessWidget {
  const SearchUser({
    super.key,
    required this.viewModel,
    required this.userProfile,
  });
  final UserProfile userProfile;
  final SearchViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        viewModel.goToUserProfile(userProfile);
      },
      child: Container(
          height: 90,
          padding: const EdgeInsets.all(6),
          margin: const EdgeInsets.symmetric(horizontal: 2),
          child:Row(
            children: [
              CircleAvatar(
                backgroundImage: NetworkImage(userProfile.dpUrl!, scale: 2),
                radius: 25,
              ),
              const SizedBox(width: 10,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 10,),
                  Text(
                    "${userProfile.firstname} ${userProfile.lastname}",
                    style: context.textTheme.bodyLarge?.copyWith(
                        color: AppColors.white, fontWeight: FontWeight.w500,
                        fontSize: 14),
                  ),
                  Text(
                    userProfile.isAgent! ? "${userProfile.interest!.length} Sports "
                        : "${userProfile.interest!.length} interest ",
                    style: context.textTheme.bodySmall?.copyWith(
                        color: AppColors.textGrey, fontWeight: FontWeight.w300,
                        fontSize: 12),
                  ),
                ],
              ),
            ],
          )
      ),
    );
  }
}

class SearchEventItem extends StatelessWidget {
  const SearchEventItem({
    super.key,
    required this.eventObject,
    required this.model,
  });

  final EventObject eventObject;
  final SearchViewModel model;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        model.goToEventProfile(eventObject);
      },
      child: Row (
        children: [
          Container(
              width: 100,
              decoration:  BoxDecoration(
                color: AppColors.solidGrey,
                borderRadius: BorderRadius.circular(9.0),
              ),
              child: Image.network(eventObject.imageUrl!, height: 90, width: 90, fit: BoxFit.cover,),
          ),
          const SizedBox( width: 10,),
          Column(
            children: [
              const SizedBox(height: 6,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    eventObject.title!,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: context.textTheme.labelLarge?.copyWith(
                        color: AppColors.white, fontWeight: FontWeight.w500,
                        fontSize: 14),
                  ),
                  const SizedBox(height: 6,),
                  Text(
                    eventObject.time!,
                    style: context.textTheme.bodySmall?.copyWith(
                        color: AppColors.white, fontWeight: FontWeight.w200,
                        fontSize: 13),
                  ),
                  const SizedBox(height: 6,),
                  Text(
                    Utils().formatEventDate(eventObject.date!),
                    style: context.textTheme.bodyMedium?.copyWith(
                        color: AppColors.white, fontWeight: FontWeight.w500,
                        fontSize: 13),
                  ),

                  const SizedBox(height: 6,),
                  Text(
                    eventObject.address!,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: context.textTheme.bodySmall?.copyWith(
                        color: AppColors.white, fontWeight: FontWeight.w200,
                        fontSize: 13),
                  ),

                ],
              ),

            ],
          )
        ],
      ) ,
    );
  }
}