
import 'package:athleteconnect/constants/colors.dart';
import 'package:athleteconnect/ui/views/search/search_viewmodel.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';

class NewSearchView extends StatelessWidget {
  const NewSearchView ({super.key});


  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<SearchViewModel>.reactive(
        viewModelBuilder: () => SearchViewModel(),
    onModelReady: (model) {
    model.auth = FirebaseAuth.instance;
    model.getAllAppData();
    },
    builder: (context, model, child) =>
    Scaffold(
    backgroundColor: AppColors.fillColor,
    appBar: AppBar(
      title: Row(
        children: [

        ],
      ),
    ),
    body: Container(),
    ));
  }
}