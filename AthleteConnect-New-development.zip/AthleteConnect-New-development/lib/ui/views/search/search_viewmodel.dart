

import 'dart:convert';

import 'package:athleteconnect/services/endpoint_ref.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/locator.dart';
import '../../../constants/routes.dart';
import '../../../models/events.dart';
import '../../../models/user_profile.dart';

class SearchViewModel extends BaseViewModel {
  bool isSearching = false;
  final searchController = TextEditingController();
  List<UserProfile> userList = [];
  List<UserProfile> filteredUserList = [];
  List<EventObject> eventList = [];
  List<EventObject> filteredEventList = [];
  List<UserProfile> athleteList  = [];
  List<UserProfile> agentList = [];
  EndpointRef endpointRef = EndpointRef();
  FirebaseAuth? auth;
  String filter = '';


  void _showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }

  void getAllAppData() async {
    // First Get all users
    final userSnapshot = await endpointRef.userRef().get();
    if (userSnapshot.exists) {
      for (DataSnapshot snapshot in userSnapshot.children) {
        final refKey = snapshot.ref.key.toString();
        final userData = await endpointRef.userProfileRef(refKey).get();
        final String profileJsonData = jsonEncode(userData.value);
        Map<String, dynamic> profileResponse = jsonDecode(profileJsonData);
        final userProfile = UserProfile.fromJson(profileResponse);
        userList.add(userProfile);
      }
      if (filter.isEmpty) {
        filteredUserList = userList;
      }
      for (UserProfile userProfile in filteredUserList){
        if (userProfile.isAgent!){
          agentList.add(userProfile);
        }else {
          athleteList.add(userProfile);
        }
      }

      final eventSnapshot = await endpointRef.currentEvent().get();
      if (eventSnapshot.exists) {
        for (DataSnapshot snapshot in eventSnapshot.children) {
          final String eventJsonData = jsonEncode(snapshot.value);
          Map<String, dynamic> eventResponse = jsonDecode(eventJsonData);
          final eventObject = EventObject.fromJson(eventResponse);
          eventList.add(eventObject);
        }
        if (filter.isEmpty) {
          filteredEventList = eventList;
        }
      }
      notifyListeners();
    }
  }

  void performSearch() {
    if (searchController.text.isEmpty) {
      filter = "";
      filteredEventList = eventList;
      filteredUserList = userList;
      for (UserProfile userProfile in filteredUserList){
        if (userProfile.isAgent!){
          agentList.add(userProfile);
        }else {
          athleteList.add(userProfile);
        }
      }
      notifyListeners();
    } else {
      filter = searchController.text;
      if (filter.isNotEmpty) {
        List<UserProfile> tmpUserList = [];
        filteredUserList = userList;
        athleteList.clear();
        agentList.clear();
        for (int i = 0; i < filteredUserList.length; i++) {
          if (filteredUserList[i].firstname!.toLowerCase().contains(
              filter.toLowerCase()) ||
              filteredUserList[i].lastname!.toLowerCase().contains(
                  filter.toLowerCase())) {
            tmpUserList.add(filteredUserList[i]);
          }
        }
        filteredUserList = tmpUserList;

        for (UserProfile userProfile in filteredUserList){
          if (userProfile.isAgent!){
            agentList.add(userProfile);
          }else {
            athleteList.add(userProfile);
          }
        }

        List<EventObject> tmpEventList = [];
        for (int i = 0; i < filteredEventList.length; i++) {
          if (filteredEventList[i].title!.toLowerCase().contains(
              filter.toLowerCase())) {
            tmpEventList.add(filteredEventList[i]);
          }
        }
        filteredEventList = tmpEventList;
      } else {
        filteredEventList = eventList;
      }
      notifyListeners();
    }
  }

  void goToEventProfile(EventObject eventObject){
    locator<GoRouter>().push(AppRoutes.eventProfileScreen, extra: eventObject);
  }

  void goToUserProfile(UserProfile userProfile){
    locator<GoRouter>().push(AppRoutes.userProfileScreen, extra: userProfile);
  }

}

