
 import 'dart:ffi';

import 'package:athleteconnect/app/locator.dart';
import 'package:athleteconnect/constants/routes.dart';
import 'package:athleteconnect/constants/variables.dart';
import 'package:athleteconnect/models/agent_profile.dart';
import 'package:athleteconnect/models/athlete_profile.dart';
import 'package:athleteconnect/models/extra_data.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/services/prefmanager.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

class DashboardViewmodel extends BaseViewModel{

 final prefManager = PrefManager();
 final auth = FirebaseAuth.instance;
 UserProfile? userProfile;

 void showToastMessage(String message) {
  Toast.show(message, duration: Toast.lengthLong, gravity: Toast.bottom);
 }

 void moveToRecommended(){
   locator<GoRouter>().push(AppRoutes.recommendedViewScreen, extra: userProfile!);
 }

 void moveToCurrentUserProfile(){
  locator<GoRouter>().push(AppRoutes.userProfileScreen, extra: userProfile);
 }

 void createNewEvent(){
   locator<GoRouter>().push(AppRoutes.newEventScreen);
 }

 void goToSearchScreen(){
  locator<GoRouter>().push(AppRoutes.searchViewScreen);
 }

 void goToResourceView(){
  locator<GoRouter>().push(AppRoutes.resourceScreen);
 }

 void goToAllEvents(bool isUpcoming){
  final extraData = ExtraData(stringValue: null, boolValue: isUpcoming);
  locator<GoRouter>().push(AppRoutes.allEventScreen, extra: extraData);
 }

 void moveToChatHistory(){
  locator<GoRouter>().push(AppRoutes.chatHistoryScreen, extra: userProfile!.isAgent!);
 }

 void fetchStoredData () async{
  var data = await prefManager.readObject(Variables.Users);
  if (data != null){
   userProfile = UserProfile.fromJson(data);
  }
 }
 
 }