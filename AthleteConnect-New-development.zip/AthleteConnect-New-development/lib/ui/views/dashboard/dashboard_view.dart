
import 'dart:ffi';

import 'package:athleteconnect/constants/variables.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/views/dashboard/dashboard_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/svg.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../constants/asset.dart';
import '../../../constants/colors.dart';

class DashboardView extends StatelessWidget {
  const DashboardView({
    super.key,
    required this.userProfile,
  });

  final UserProfile userProfile;

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<DashboardViewmodel>.reactive(
        viewModelBuilder: () => DashboardViewmodel(),
        onViewModelReady: (model) {
          model.fetchStoredData();
        },
        builder: (context, model, child) => Scaffold(
            backgroundColor: AppColors.deepBlack,
            appBar: AppBar(
              automaticallyImplyLeading: false,
              backgroundColor: AppColors.deepBlack,
              title: Row(
                children: [
                  InkWell(
                    onTap: () { model.moveToCurrentUserProfile();},
                    child: model.userProfile != null ? CircleAvatar(
                      backgroundImage: NetworkImage(model.userProfile!.dpUrl!,),
                      radius: 15,
                    ) : CircleAvatar(
                      backgroundImage: AssetImage(AppAssets.photoAvatar),
                      radius: 15,
                    ),
                  ),
                  const SizedBox(
                    width: 16,
                  ),
                  Text(
                    "Home",
                    style: context.textTheme.titleLarge?.copyWith(
                        color:  AppColors.white,
                        fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
              actions: [
                Row(
                  children: [
                     InkWell(
                      onTap: () {
                        model.goToSearchScreen();
                      },
                      child: const Icon(Icons.search, weight: 30, color: AppColors.buttonColor, ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    InkWell(
                      onTap: () { model.goToResourceView();},
                      child: const Icon(Icons.help_outline_sharp, weight: 30, color: AppColors.buttonColor, ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                  ],
                )

              ],
            ),
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(10),
              child: Stack(
                children: [
                  Expanded(
                    child: ListView(
                      children: [
                        happeningNow(context, model),
                        const SizedBox(height: 16,),
                        userProfile.isAgent! ? recommendedAthlete(context, model) :
                        recommendedAgent(context, model) ,
                        const SizedBox(height: 16,),
                        upcomming(context, model),
                        const SizedBox(height: 16,),
                        quickChat(context, model),
                        const SizedBox(height: 16,),
                        reviewCard(context),
                        const SizedBox(height: 10,),
                      ],
                    ),
                  ),

                ],
              )
            ),
          ),

          floatingActionButton: FloatingActionButton(
            onPressed: () {
              model.createNewEvent();
            },
            backgroundColor: AppColors.buttonColor,
            child: const Icon(Icons.add, color: AppColors.white,),
          ),
          floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,

        ));
  }

  Widget happeningNow (BuildContext context, DashboardViewmodel model){
   return Container(
     child: Column(
       children: [
         Row(
           mainAxisAlignment: MainAxisAlignment.spaceBetween,
           children: [
             Text(
               "Happening now",
               style: context.textTheme.bodyMedium?.copyWith(
                   color:  AppColors.white,
                   fontSize: 14, fontWeight: FontWeight.w500),
             ),

             GestureDetector(
               onTap: () { model.goToAllEvents(false); },
               child: Row(
                 children: [
                   Text(
                     "View all",
                     style: context.textTheme.bodySmall?.copyWith(
                         color:  AppColors.buttonColor,
                         fontSize: 12, fontWeight: FontWeight.w300),
                   ),
                   const SizedBox(
                     width: 5,
                   ),
                   const Icon(Icons.arrow_forward_ios, color: AppColors.buttonColor, size: 12,),
                 ],
               ),
             ),

           ],
         ),
         const SizedBox(height: 8,),
         SizedBox(
          height: 200,
           child: ListView(
             scrollDirection: Axis.horizontal,
             shrinkWrap: true,
             children: [
               eventCard(context, AppAssets.authBg),
               const SizedBox(width: 8,),
               eventCard(context, AppAssets.peopleImg),
               const SizedBox(width: 8,),
               eventCard(context, AppAssets.peopleImg),
               const SizedBox(width: 8,),
             ],
           ),
         )

       ],
     ),
   );
  }

  Container eventCard(BuildContext context, String assetImage){
    return Container(
      width: 160,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Image.asset(assetImage, height: 120, width: 160, fit: BoxFit.cover,),
          const SizedBox(height: 10,),
          Text(
            "Australia Open",
            style: context.textTheme.bodyMedium?.copyWith(
                color:  AppColors.white,
                fontSize: 15, fontWeight: FontWeight.w400),
          ),
          Text(
            "Time: 4pm",
            style: context.textTheme.bodySmall?.copyWith(
                color:  AppColors.white,
                fontSize: 12, fontWeight: FontWeight.w300),
          ),
          Text(
            "The Zone UK London",
            style: context.textTheme.bodySmall?.copyWith(
                color:  AppColors.white,
                fontSize: 12, fontWeight: FontWeight.w300),
          ),


        ],
      ),
    );
  }

  Container recommendedAgent(BuildContext context, DashboardViewmodel model){
    return Container(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                 "Recommended Agents",
                style: context.textTheme.bodyMedium?.copyWith(
                    color:  AppColors.white,
                    fontSize: 14, fontWeight: FontWeight.w500),
              ),
              InkWell(
                  onTap: model.moveToRecommended,
                  child: Row(
                    children: [

                      Text(
                        "View all",
                        style: context.textTheme.bodySmall?.copyWith(
                            color:  AppColors.buttonColor,
                            fontSize: 12, fontWeight: FontWeight.w300),
                      ),

                      const SizedBox(
                        width: 5,
                      ),
                      const Icon(Icons.arrow_forward_ios, color: AppColors.buttonColor, size: 12,),
                    ],
                  )
              ),

            ],
          ),
          const SizedBox(height: 16,),
          SizedBox(
            height: 80,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                agentCard(context, "Football", AppAssets.faceImage),
                const SizedBox(width: 5,),
                agentCard(context, "Basketball", AppAssets.ericface),
                const SizedBox(width: 5,),
                agentCard(context, "Table Tennis", AppAssets.faceImage),
                const SizedBox(width: 5,),
                agentCard(context, "Swimming", AppAssets.markFace),
                const SizedBox(width: 5,),
              ],
            ),
          )
        ],
      ),
    );
  }

  Container recommendedAthlete(BuildContext context,  DashboardViewmodel model){
    return Container(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                  "Recommended Athlete",
                style: context.textTheme.bodyMedium?.copyWith(
                    color:  AppColors.white,
                    fontSize: 14, fontWeight: FontWeight.w500),
              ),
              InkWell(
                onTap: model.moveToRecommended,
                child: Row(
                  children: [
                    Text(
                      "View all",
                      style: context.textTheme.bodySmall?.copyWith(
                          color:  AppColors.buttonColor,
                          fontSize: 12, fontWeight: FontWeight.w300),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Icon(Icons.arrow_forward_ios, color: AppColors.buttonColor, size: 12,),
                  ],
                ),
              )

            ],
          ),
          const SizedBox(height: 16,),
          SizedBox(
            height: 80,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                agentCard(context, "Sprinting", AppAssets.faceImage),
                const SizedBox(width: 5,),
                agentCard(context, "Basketball", AppAssets.ericface),
                const SizedBox(width: 5,),
                agentCard(context, "Long Tennis", AppAssets.faceImage),
                const SizedBox(width: 5,),
                agentCard(context, "Swimming", AppAssets.markFace),
                const SizedBox(width: 5,),
              ],
            ),
          )
        ],
      ),
    );
  }

  Container agentCard(BuildContext context, String sport, String assetImages){
    return Container(
      width: 100,
      child: Column(
        children: [
           CircleAvatar(
            backgroundImage: AssetImage(assetImages),
            radius: 25,
          ),
          const SizedBox(height: 10,),
          Expanded(child: Text(
           !userProfile.isAgent! ? "$sport agent": "$sport" , textAlign: TextAlign.center,
            style: context.textTheme.bodyMedium?.copyWith(
                color:  AppColors.white,
                fontSize: 12, fontWeight: FontWeight.w400),
          ),)
        ],
      ),
    );
  }

  Widget upcomming (BuildContext context, DashboardViewmodel model){
    return Container(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Upcoming event",
                style: context.textTheme.bodyMedium?.copyWith(
                    color:  AppColors.white,
                    fontSize: 14, fontWeight: FontWeight.w500),
              ),

              GestureDetector(
                onTap: () { model.goToAllEvents(true); },
                child: Row(
                  children: [
                    Text(
                      "View all",
                      style: context.textTheme.bodySmall?.copyWith(
                          color:  AppColors.buttonColor,
                          fontSize: 12, fontWeight: FontWeight.w300),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Icon(Icons.arrow_forward_ios, color: AppColors.buttonColor, size: 12,),
                  ],
                ) ,
              )

            ],
          ),
          const SizedBox(height: 8,),
          SizedBox(
            height: 200,
            child: ListView(
              scrollDirection: Axis.horizontal,
              shrinkWrap: true,
              children: [
                eventCard(context, AppAssets.confrImg),
                const SizedBox(width: 8,),
                eventCard(context, AppAssets.cupImage),
                const SizedBox(width: 8,),
                eventCard(context, AppAssets.peopleImg),
                const SizedBox(width: 8,),
              ],
            ),
          )

        ],
      ),
    );
  }

  Container quickChat(BuildContext context, DashboardViewmodel model){
    return Container(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                "Quick chat",
                style: context.textTheme.titleLarge?.copyWith(
                    color:  AppColors.white,
                    fontSize: 14, fontWeight: FontWeight.w500),
              ),
              InkWell(
                onTap: model.moveToChatHistory,
                child: Row(
                  children: [
                    Text(
                      "View all",
                      style: context.textTheme.bodySmall?.copyWith(
                          color:  AppColors.buttonColor,
                          fontSize: 12, fontWeight: FontWeight.w300),
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Icon(Icons.arrow_forward_ios, color: AppColors.buttonColor, size: 12,),
                  ],
                ),
              ),

            ],
          ),
          const SizedBox(height: 16,),
          SizedBox(
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                chatCard(context, "Mike", AppAssets.markFace),
                const SizedBox(width: 5,),
                chatCard(context, "Solomon", AppAssets.ericface),
                const SizedBox(width: 5, ),
                chatCard(context, "Elvis", AppAssets.faceImage),
                const SizedBox(width: 5,),
                chatCard(context, "Eric", AppAssets.markFace),
                const SizedBox(width: 5,),
              ],
            ),
          )

        ],
      ),
    );
  }

  Widget chatCard(BuildContext context, String name, String assetImage){
    return Container(
      width: 74,
      child: Column(
        children: [
           Container(
            decoration:  BoxDecoration(
              color: AppColors.fillColor,
              borderRadius: BorderRadius.circular(2.0),
            ),
            child: Image.asset(assetImage, height: 70, width: 74, fit: BoxFit.cover,),
          ),
          const SizedBox(height: 10,),
          Expanded(child: Text(
            name, textAlign: TextAlign.center,
            style: context.textTheme.bodyMedium?.copyWith(
                color:  AppColors.white,
                fontSize: 12, fontWeight: FontWeight.w400),
          ),)
        ],
      ),
    );
  }

  Widget reviewCard (BuildContext context){
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              "Recent reviews",
              style: context.textTheme.titleLarge?.copyWith(
                  color:  AppColors.white,
                  fontSize: 14, fontWeight: FontWeight.w500),
            ),
            Row(
              children: [
                Text(
                  "View all",
                  style: context.textTheme.bodySmall?.copyWith(
                      color:  AppColors.buttonColor,
                      fontSize: 12, fontWeight: FontWeight.w300),
                ),
                const SizedBox(
                  width: 5,
                ),
                const Icon(Icons.arrow_forward_ios, color: AppColors.buttonColor, size: 12,),
              ],
            )
          ],
        ),
        const SizedBox(height: 16,),
        SizedBox(height: 220, child: ListView(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          children: [
            ReviewItems(context, 3.0, "Mark", Variables.defaultRating),
            const SizedBox(height: 5,),
            ReviewItems(context, 4.0, "Solomon", Variables.defaultRating),
            const SizedBox(height: 5, ),
            ReviewItems(context, 5.0, "Eric", Variables.defaultRating),
            const SizedBox(height: 5,),
          ],
        ),)

      ],
    );
  }

  Widget ReviewItems (BuildContext context, double rating, String name, body){
    return Container(
      height: 64,
      child: Column(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child:  RatingBarIndicator(
              rating: rating, // The rating you want to display
              itemBuilder: (context, index) => const Icon(
                Icons.star,
                color: AppColors.appGreen,
              ),
              itemCount: 5, // Number of stars
              unratedColor: AppColors.fieldGrey,
              itemSize: 20.0, // Size of the stars
              direction: Axis.horizontal, // Direction of the rating bar
            ),
          ),
          const SizedBox(height: 5,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                name,
                style: context.textTheme.bodyMedium?.copyWith(
                    color:  AppColors.white,
                    fontSize: 12, fontWeight: FontWeight.w400),
              ),

              Text(
                "2 days ago",
                style: context.textTheme.bodySmall?.copyWith(
                    color:  AppColors.white,
                    fontSize: 10, fontWeight: FontWeight.w200),
              ),
            ],
          ),
          const SizedBox(height: 4,),
          Expanded(child: Text(
            "$name $body",
            style: context.textTheme.bodyMedium?.copyWith(
                color:  AppColors.white,
                fontSize: 12, fontWeight: FontWeight.w400),
          ),)
        ],
      ),
    ) ;
  }

}
