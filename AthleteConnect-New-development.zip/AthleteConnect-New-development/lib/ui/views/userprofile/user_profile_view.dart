

import 'dart:ffi';

import 'package:athleteconnect/app/util.dart';
import 'package:athleteconnect/constants/asset.dart';
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/agent_profile.dart';
import 'package:athleteconnect/models/athlete_profile.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/dialogs/confirm_log_out.dart';
import 'package:athleteconnect/ui/views/userprofile/user_profile_viewmodel.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../constants/colors.dart';
import '../../../constants/variables.dart';
import '../setupscreen/agent_setup_screen.dart';

class UserProfileScreen extends StatelessWidget {
  const UserProfileScreen({super.key,
  required this.userProfile,
  });

  final UserProfile? userProfile;
  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<UserProfileViewModel>.reactive(
        viewModelBuilder: () => UserProfileViewModel(),
        onModelReady: (model) {
          if (userProfile != null){
            model.auth = FirebaseAuth.instance;
            model.userProfile = userProfile;
            model.retrieveUserData();
            model.loadUserReviews();
          }
        },
        builder: (context, model, child) =>
            Scaffold(
              backgroundColor: AppColors.fillColor,
              body: SafeArea(
                child:
                model.isInitialising ? Utils().loadingContainer("", AppColors.white, true) : Expanded(child: ListView(
                  children: [
                    Stack(
                      children: [
                        Expanded(child: Image.network(userProfile!.dpUrl!, height: 350, fit: BoxFit.fill, scale: 2,)),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Align(
                              alignment: Alignment.topLeft,
                              child: InkWell(
                                onTap: () => Navigator.of(context).pop(),
                                child: Container(
                                    margin:  EdgeInsets.all(16),
                                    child: const Icon(Icons.arrow_back, color: AppColors.white, weight: 16,)
                                ),
                              ),
                            ),

                            model.auth!.currentUser!.uid == userProfile!.id! ? InkWell(
                              onTap: () {
                                model.goToSettings();
                              },
                              child: const Icon(Icons.settings, size: 28, color: AppColors.buttonColor,),
                            ) : Container()
                          ],
                        )
                      ],
                    ),
                    const SizedBox(height: 16,),
                    Align(
                        alignment: Alignment.center,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            model.isUserVerified ? const Icon(Icons.stars_sharp, color: AppColors.buttonColor, size: 15,) : Container() ,
                            const SizedBox(width: 5,),

                            Text(
                              "${userProfile!.firstname} ${userProfile!.lastname}",
                              style: context.textTheme.titleLarge?.copyWith(
                                  color:  AppColors.white,
                                  fontSize: 16, fontWeight: FontWeight.w500),
                            ),
                          ],
                        )
                    ),
                    const SizedBox(height: 5,),
                    Align(
                      alignment: Alignment.center,
                      child: emailAndPhoneView(model, context),
                    ),
                    const SizedBox(height: 5,),

                    !userProfile!.isAgent! ?

                    Align(
                      alignment: Alignment.center,
                      child: model.currentUserSettings != null && model.currentUserSettings!.education! ?
                      Text(
                        "Education: ${userProfile!.education}",
                        style: context.textTheme.labelMedium
                            ?.copyWith(
                            color:  AppColors.white,
                            fontSize: 13, fontWeight: FontWeight.w300),
                      ) : Text("*****"),
                    ) : Container(),

                    const SizedBox(height: 5,),

                    Align(
                      alignment: Alignment.center,
                      child: Text(
                        "About Me",
                        style: context.textTheme.bodyMedium
                            ?.copyWith(
                            color:  AppColors.white,
                            fontSize: 10, fontWeight: FontWeight.bold),
                      ) ,
                    ),
                    //;f;f
                    Padding(padding: EdgeInsets.all(10),
                      child:  Align(
                        alignment:  Alignment.center,
                        child: model.currentUserSettings != null && model.currentUserSettings!.bio! ?
                        Text(
                          "${userProfile!.bio}", textAlign: TextAlign.center,
                          style: context.textTheme.bodyMedium?.copyWith(
                              color:  AppColors.white,
                              fontSize: 13, fontWeight: FontWeight.normal),
                        ) : Text("***** ",  textAlign: TextAlign.center,
                          style: context.textTheme.bodyMedium?.copyWith(
                              color:  AppColors.white,
                              fontSize: 13, fontWeight: FontWeight.normal),),
                      ),),
                    const SizedBox(height: 10,),
                    model.auth!.currentUser!.uid == userProfile!.id ?
                    Align(
                      alignment: Alignment.center,
                      child: GestureDetector(
                        onTap: model.goToAllUserEvents,
                        child: Container(
                            width: 100,
                            padding: const EdgeInsets.all(6),
                            margin: const EdgeInsets.symmetric(horizontal: 2),
                            decoration: BoxDecoration(
                                color: AppColors.buttonColor,
                                border: Border.all(
                                    color:  AppColors.buttonColor ),
                                borderRadius: BorderRadius.circular(7)),
                            child: Center(
                              child: Text(
                                "Events",
                                style: context.textTheme.bodyMedium?.copyWith(
                                  color:  AppColors.white, fontWeight: FontWeight.w400,
                                  fontSize:13, ),
                              ),
                            )
                        ),
                      ),
                    )
                        :  Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        model.currentUserSettings!.openMessages! ?
                        GestureDetector(
                            onTap: () {
                              model.goToUserChat();
                            },
                            child: Expanded(child: Container(
                              height: 40,
                              padding: const EdgeInsets.all(6),
                              margin: const EdgeInsets.symmetric(horizontal: 2),
                              decoration: BoxDecoration(
                                  color: AppColors.buttonColor,
                                  border: Border.all(
                                      color:  AppColors.buttonColor ),
                                  borderRadius: BorderRadius.circular(7)),
                              child: Text(
                                "Send Message",
                                style: context.textTheme.bodyMedium?.copyWith(
                                  color:  AppColors.white, fontWeight: FontWeight.w400,
                                  fontSize:13, ),
                              ),
                            ),)
                        ) : Container(),
                        const SizedBox(width: 10,),
                        GestureDetector(
                            onTap: (){
                              model.showPreviewDialog(context);
                            },
                            child:Expanded (
                              child:  Container(
                                height: 40,
                                padding: const EdgeInsets.all(6),
                                margin: const EdgeInsets.symmetric(horizontal: 2),
                                decoration: BoxDecoration(
                                    color: AppColors.appGreen,
                                    border: Border.all(
                                        color:  AppColors.appGreen ),
                                    borderRadius: BorderRadius.circular(7)),
                                child:Text(
                                  "Write a review",
                                  style: context.textTheme.bodyMedium?.copyWith(
                                    color:  AppColors.white, fontWeight: FontWeight.w400,
                                    fontSize:13, ),
                                ),
                              ),
                            )
                        )
                      ],
                    ),

                    const SizedBox(
                      height: 20,
                    ),

                    Padding(padding: EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Sport Interest",
                            style: context.textTheme.bodyMedium?.copyWith(
                                color:  AppColors.white,
                                fontSize: 14, fontWeight: FontWeight.w500),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          const
                          Wrap(
                            spacing: 4,
                            runSpacing: 8,
                            alignment: WrapAlignment.start,
                            children: [
                              ProfileInterestWidget(
                                title: "Football",
                              ),
                              ProfileInterestWidget(
                                title: "BasketBall",
                              ),

                              ProfileInterestWidget(
                                title: "Badminton",
                              ),
                              ProfileInterestWidget(
                                title: "Running",

                              ),
                              ProfileInterestWidget(
                                title: "Archery",
                              ),
                              ProfileInterestWidget(
                                title: "Cycling",
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 16,
                          ),

                          !userProfile!.isAgent! ?
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              model.auth!.currentUser!.uid != model.currentUser!.id ?
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Achievements",
                                    style: context.textTheme.bodyMedium?.copyWith(
                                        color:  AppColors.white,
                                        fontSize: 14, fontWeight: FontWeight.w500),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  Text(
                                    userProfile!.achievements!,
                                    style: context.textTheme.bodyMedium?.copyWith(
                                        color:  AppColors.white,
                                        fontSize: 14, fontWeight: FontWeight.w300),
                                  ),
                                ],
                              ) :  model.currentUserSettings!.achievements! ?
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Achievements",
                                    style: context.textTheme.bodyMedium?.copyWith(
                                        color:  AppColors.white,
                                        fontSize: 14, fontWeight: FontWeight.w500),
                                  ),
                                  const SizedBox(
                                    height: 5,
                                  ),
                                  Text(
                                    userProfile!.achievements!,
                                    style: context.textTheme.bodyMedium?.copyWith(
                                        color:  AppColors.white,
                                        fontSize: 14, fontWeight: FontWeight.w300),
                                  ),
                                ],
                              ) : Column(),

                              const SizedBox(
                                height: 10,
                              ),
                              Text(
                                "Goals",
                                style: context.textTheme.bodyMedium?.copyWith(
                                    color:  AppColors.white,
                                    fontSize: 14, fontWeight: FontWeight.w500),
                              ),
                              const SizedBox(
                                height: 5,
                              ),

                              Text(
                                userProfile!.goals!,
                                maxLines: 5,
                                style: context.textTheme.bodyMedium?.copyWith(
                                    color:  AppColors.white,
                                    fontSize: 14, fontWeight: FontWeight.w300),
                              ),
                              const SizedBox(
                                height: 16,
                              ),
                              userProfile!.mediaUrl != null ? attachmentView(model, context):
                              Container(),
                              const SizedBox(
                                height: 10,
                              ),


                            ],
                          ) :
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              pastClientsView(model, context),
                              const SizedBox(
                                height: 16,
                              ),
                              userProfile!.mediaUrl != null ? attachmentView(model, context):
                              Container(),
                              const SizedBox(
                                height: 10,
                              ),
                              
                            ],
                          ),

                          Text(
                            "Reviews",
                            style: context.textTheme.bodyMedium?.copyWith(
                                color:  AppColors.white,
                                fontSize: 14, fontWeight: FontWeight.w500),
                          ),

                          model.reviewList.isNotEmpty ?
                          ListView.builder(
                              itemCount: model.reviewList.length,
                              physics: const NeverScrollableScrollPhysics(),
                              shrinkWrap: true,
                              itemBuilder: (BuildContext context, int index) {
                                return ReviewItems(context, double.parse(model.reviewList[index].score!.toString()), model.reviewList[index].customerName!, model.reviewList[index].comment!, model.reviewList[index].ratedAt!);
                              }) : Center(
                            child: Text(
                              "No Reviews",
                              style: context.textTheme.bodyMedium?.copyWith(
                                  color:  AppColors.white,
                                  fontSize: 14, fontWeight: FontWeight.w200),
                            ),
                          ),

                        ],
                      ),),
                    //ddd

                  ],
                )),
              )
            ));
  }

  Widget emailAndPhoneView(UserProfileViewModel model, BuildContext context){
   if   (model.currentUserSettings != null) {
      return Text(
         "${model.currentUserSettings!.email! ? userProfile!.email : "*****"}  |  ${model.currentUserSettings!.phone! ? userProfile!.phone : "*****"}",
        style: context.textTheme.titleLarge?.copyWith(
            color:  AppColors.white,
            fontSize: 12, fontWeight: FontWeight.normal),
      );
    }
   else{
     return Text(
       "${userProfile!.email} | ${userProfile!.phone}",
       style: context.textTheme.titleLarge?.copyWith(
           color:  AppColors.white,
           fontSize: 12, fontWeight: FontWeight.normal),
     );
   }
  }

  Widget attachmentView(UserProfileViewModel model, BuildContext context){
    if (model.auth!.currentUser!.uid == model.currentUser!.id){
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Attached Media",
            style: context.textTheme.bodyMedium?.copyWith(
                color:  AppColors.white,
                fontSize: 14, fontWeight: FontWeight.w500),
          ),
          const SizedBox(
            height: 10,
          ),

          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.network(userProfile!.mediaUrl!, scale: 1, height: 80, width: 80,),
              const SizedBox(
                width: 10,
              ),
              InkWell(
                onTap: (){

                },
                child: Text(
                  "View file",
                  style: context.textTheme.bodyMedium?.copyWith(
                      color:  AppColors.white,
                      fontSize: 14, fontWeight: FontWeight.w300),
                ),
              )

            ],
          )
        ],
      );
    }
    else {
      if (model.currentUserSettings!.media!){
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Attached Media",
              style: context.textTheme.bodyMedium?.copyWith(
                  color:  AppColors.white,
                  fontSize: 14, fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 10,
            ),

            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.network(userProfile!.mediaUrl!, scale: 1, height: 80, width: 80,),
                const SizedBox(
                  width: 10,
                ),
                InkWell(
                  onTap: (){

                  },
                  child: Text(
                    "View file",
                    style: context.textTheme.bodyMedium?.copyWith(
                        color:  AppColors.white,
                        fontSize: 14, fontWeight: FontWeight.w300),
                  ),
                )

              ],
            )
          ],
        );
      }else{
        return Container();
      }
  }
  }

  Widget pastClientsView(UserProfileViewModel model, BuildContext context){
    if (model.auth!.currentUser!.uid == model.currentUser!.id){
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Past Clients",
            style: context.textTheme.bodyMedium?.copyWith(
                color:  AppColors.white,
                fontSize: 14, fontWeight: FontWeight.w500),
          ),
          const SizedBox(
            height: 5,
          ),
          Center(child: Text(
            userProfile!.clients!.join(', '),
            style: context.textTheme.bodyMedium?.copyWith(
                color:  AppColors.white,
                fontSize: 14, fontWeight: FontWeight.w300),
          ),),
        ],
      );
    }else {
      if (model.currentUserSettings!.clients!) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Past Clients",
              style: context.textTheme.bodyMedium?.copyWith(
                  color:  AppColors.white,
                  fontSize: 14, fontWeight: FontWeight.w500),
            ),
            const SizedBox(
              height: 5,
            ),
            Center(child: Text(
              userProfile!.clients!.join(', '),
              style: context.textTheme.bodyMedium?.copyWith(
                  color:  AppColors.white,
                  fontSize: 14, fontWeight: FontWeight.w300),
            ),),
          ],
        );
      }else{
        return Container();
      }
    }
  }

  Widget ReviewItems (BuildContext context, double rating, String name, String body, String date){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 15,),
        RatingBarIndicator(
          rating: rating, // The rating you want to display
          itemBuilder: (context, index) => const Icon(
            Icons.star,
            color: AppColors.appGreen,
          ),
          itemCount: 5, // Number of stars
          unratedColor: AppColors.fieldGrey,
          itemSize: 17.0, // Size of the stars
          direction: Axis.horizontal, // Direction of the rating bar
        ),
        const SizedBox(height: 5,),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              name,
              style: context.textTheme.bodyLarge?.copyWith(
                  color:  AppColors.white,
                  fontSize: 12, fontWeight: FontWeight.w900),
            ),

            Text(
              Utils().formatMillisecondsDate(date),
              style: context.textTheme.bodySmall?.copyWith(
                  color:  AppColors.white,
                  fontSize: 10, fontWeight: FontWeight.w200),
            ),
          ],
        ),
        const SizedBox(height: 4,),

        Text(
          body,
          maxLines: 4,
          style: context.textTheme.bodyMedium?.copyWith(
              color:  AppColors.white,
              fontSize: 12, fontWeight: FontWeight.w400),
        ),
      ],
    );
  }
}

class ProfileInterestWidget extends StatelessWidget {
  const ProfileInterestWidget({
    super.key,
    required this.title,
  });
  final String title;
  @override
  Widget build(BuildContext context) {
    return Container(
        padding: const EdgeInsets.all(6),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
            color:  AppColors.textGrey,
            border: Border.all(
                color:  AppColors.textGrey ),
            borderRadius: BorderRadius.circular(7)),
        child: Expanded(
          child: Text(
            "${title}",
            style: context.textTheme.labelLarge?.copyWith(
                color: AppColors.primary,
                fontSize: context.widthPercent(0.03)),
          ),
        )
    );
  }
}