

import 'dart:convert';

import 'package:athleteconnect/constants/form_validation.dart';
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/PrivateData.dart';
import 'package:athleteconnect/models/agent_profile.dart';
import 'package:athleteconnect/models/athlete_profile.dart';
import 'package:athleteconnect/models/extra_data.dart';
import 'package:athleteconnect/models/rating_object.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/services/endpoint_ref.dart';
import 'package:athleteconnect/services/prefmanager.dart';
import 'package:athleteconnect/ui/dialogs/add_review_modal.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/games/v1.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';
import '../../../app/locator.dart';
import '../../../constants/colors.dart';
import '../../../constants/routes.dart';
import '../../../constants/variables.dart';

class UserProfileViewModel extends BaseViewModel {

  UserProfile? userProfile, currentUser;
  bool isOnline = false;
  bool isAddingReview = false;
  final prefManager = PrefManager();
  int selectedRating = 0;
  FirebaseAuth? auth;
  bool hasRated = false;
  final reviewController = TextEditingController();
  final endPointRef = EndpointRef();
  bool hasReviews = false;
  List<RatingObject> reviewList = [];
  PrivacyData? currentUserSettings;
  bool isUserVerified = false;
  bool isInitialising = false;

  void retrieveUserData() async {
    isInitialising = true;
    var data = await prefManager.readObject(Variables.Users);
    if (data != null){
      currentUser = UserProfile.fromJson(data);
      notifyListeners();
    }
    fetchStoredSettings(userProfile!.id!);
  }

  void fetchStoredSettings(String uID) async {
    DatabaseReference settingRef =  endPointRef.userPrivacySettingRef(uID);
    settingRef.onValue.listen((event) async {
      if (event.snapshot.exists) {
        final String jsonData = jsonEncode(event.snapshot.value);
        Map<String, dynamic> responseData = jsonDecode(jsonData);
        currentUserSettings = PrivacyData.fromJson(responseData);
        notifyListeners();
      }
      isInitialising = false;
    });
  }

  void addUserRating(int rating){
    selectedRating = rating;
    if (selectedRating == 0){
      hasRated = false;
    }else{
      hasRated = true;
    }
    notifyListeners();
  }

  void showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }


  void goToAllUserEvents(){
    final extraData = ExtraData(stringValue: userProfile!.id, boolValue: null);
    locator<GoRouter>().push(AppRoutes.allEventScreen, extra: extraData);
  }

  void saveUSerRating(BuildContext buildContext) async {
    final response = FormValidation.stringValidation(reviewController.text);
    if (response != null) {
      showToastMessage(response);
      return;
    }

    if (!hasRated){
      showToastMessage("Please select a rating");
      return;
    }
    isAddingReview = true;
    notifyListeners();

    final ratingId = auth!.currentUser!.uid + DateTime.now().millisecondsSinceEpoch.toString();

    final rateObject = RatingObject(ratingId, selectedRating, DateTime.now().millisecondsSinceEpoch.toString(), "${currentUser!.firstname}  ${currentUser!.lastname}" , "${userProfile!.firstname} ${userProfile!.lastname}", currentUser!.dpUrl!, userProfile!.dpUrl!,
        reviewController.text, currentUser!.id!, userProfile!.id!);

    endPointRef.allReviewRef().child(rateObject.id!).set(rateObject.toJson());
    endPointRef.userReviews(userProfile!.id!).child(rateObject.id!).set(rateObject.toJson());
    isAddingReview = false;
    notifyListeners();
    Navigator.of(buildContext).pop();

  }

  void goToSettings(){
    locator<GoRouter>().push(AppRoutes.appSettingsScreen, extra: userProfile);
  }

  void goToUserChat(){
    locator<GoRouter>().push(AppRoutes.chatScreen, extra: userProfile);
  }

  void showPreviewDialog(BuildContext context){
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30.0),
          topRight: Radius.circular(30.0),
        ),
      ),
      backgroundColor: AppColors.solidGrey,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      constraints: BoxConstraints(
          maxHeight: context.heightPercent(0.5)),
      builder: (BuildContext context) {
        return AddReview(viewModel: this,
        );
      },
    );
  }

  void loadUserReviews () async {
    DatabaseReference rateRef =  endPointRef.userReviews(userProfile!.id!);
    rateRef.onValue.listen((event) async {
      if (event.snapshot.exists){
        reviewList.clear();
        hasReviews = true;
        // Check if User is verified
        if (event.snapshot.children.length > 3 ){
          isUserVerified = true;
        }else{
          isUserVerified = false;
        }
        // load up the reviews
        for (DataSnapshot snapshot in event.snapshot.children) {
          final String jsonData = jsonEncode(snapshot.value);
          Map<String, dynamic> responseData = jsonDecode(jsonData);
          final reviewObject = RatingObject.fromJson(responseData);
          reviewList.insert(0, reviewObject);
          notifyListeners();
          // Extract the inner map using the key (first entry in the map)
          // if (responseData.isNotEmpty) {
          //   Map<String, dynamic> innerData = responseData.values.first as Map<String, dynamic>;
          //   // Now pass the innerData to the fromJson method
          //   final reviewObject = RatingObject.fromJson(innerData);
          //   reviewList.insert(0, reviewObject);
          //   }
          }
      }else {
        hasReviews = false;
        isUserVerified = false;
        notifyListeners();
      }
    });
  }

}