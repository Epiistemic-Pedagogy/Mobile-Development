

import 'package:athleteconnect/app/util.dart';
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/views/chat/chat_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';
import '../../../constants/colors.dart';
import '../../../models/message_object.dart';
import '../../widgets/chat_bubble.dart';

class UserChatScreen extends StatelessWidget {
  const UserChatScreen({super.key, required this.userProfile,
  });

  final UserProfile userProfile;
  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<ChatViewModel>.reactive(
        viewModelBuilder: () => ChatViewModel(),
        onModelReady: (model) {
          model.fetchStoredData();
          model.recipient = userProfile;
          model.getUserChat(userProfile.id!);
          model.checkTextField();
        },
        builder: (context, model, child) =>
            Scaffold(
              backgroundColor: AppColors.fieldGrey,

              appBar: AppBar(
                backgroundColor: AppColors.fillColor,
                leading: Row(
                  children: [
                    const SizedBox(width: 10,),
                    InkWell(
                      onTap: () => Navigator.of(context).pop(),
                      child: const Icon(
                        Icons.arrow_back, color: AppColors.white,),
                    ),
                    const SizedBox(width: 10,),

                  ],
                ),
                title: Expanded(
                    child: Text(
                  '${userProfile.firstname} ',
                   style: context.textTheme.titleLarge?.copyWith(
                      color: AppColors.white,
                      fontSize: 15, fontWeight: FontWeight.w600),)),

                actions: [
                  Row(
                    children: [

                      InkWell(
                        onTap: () {
                          model.initiateVideoCall();
                        },
                        child: const Icon(Icons.video_call, size: 28, color: AppColors.buttonColor,),
                      ),

                      const SizedBox(width: 15,),

                      // InkWell(
                      //   onTap: () {
                      //     model.showToastMessage("Make a voice call");
                      //   },
                      //   child: const Icon(Icons.call, size: 28, color: AppColors.buttonColor,),
                      // ),
                      //
                      // const SizedBox(width: 15,),

                    ],
                  )
                ],

              ),

              body: Column(
                children: [
                  Expanded(
                      child: model.messages.isEmpty ? Center(child: Text(
                        "No Message",
                        style: context.textTheme.bodyMedium?.copyWith(
                            color: AppColors.buttonColor, fontSize: 14,
                            fontWeight: FontWeight.w800),
                      ), ) : messageBody(model.messages, context, model)),

                  Padding(
                      padding: const EdgeInsets.all(10.0),
                      child:
                      Container(
                          padding: EdgeInsets.symmetric(horizontal: 10, vertical: 7),
                          decoration: BoxDecoration(
                            color: AppColors.white,
                            border: Border.all(color: AppColors.primary.withOpacity(.5)),
                            borderRadius: const BorderRadius.all(Radius.circular(15)),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Expanded(child: TextFormField(
                                controller: model.fieldController,
                                style: context.textTheme.bodyMedium?.copyWith(color: AppColors.deepBlack, fontSize: 12,fontWeight: FontWeight.w400),
                                decoration: const InputDecoration(
                                  border: InputBorder.none,
                                  hintText: 'Type message here...',
                                ),
                              ),),
                              const SizedBox(height: 10,),
                              model.showButton ?
                              InkWell(
                                onTap: (){
                                  model.sendMessage(userProfile.id!);
                                },
                                child: Text(
                                  "Send",
                                  style: context.textTheme.bodyMedium?.copyWith(
                                      color: AppColors.buttonColor, fontSize: 14,
                                      fontWeight: FontWeight.w800),
                                ),
                              ) : Container()
                            ],
                          )
                      )

                  )
                ],
              ),
            ));
  }

  ListView messageBody(List<MessageObject> messages, BuildContext context, ChatViewModel model ) {
    String userId = model.auth!.currentUser!.uid;
    return ListView.builder(
      padding: EdgeInsets.symmetric(horizontal: context.widthPercent(0.03)),
      reverse: true,
      physics: BouncingScrollPhysics(),
      itemCount: messages.length,
      itemBuilder: (context, index) =>
          Container(
            padding: EdgeInsets.only(bottom: 10),
            child: SingleChatUI(
              right: messages[index].sender == userId ? true : false,
              message: messages[index],
            ),
          ),
    );
  }
}

class SingleChatUI extends StatelessWidget {
  SingleChatUI({super.key,
    required this.right, required this.message});

  final bool right;
  final MessageObject message;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: right ? CrossAxisAlignment.end : CrossAxisAlignment.start,
        children: [
          SizedBox(width: context.widthPercent(0.5)),
          ChatBubble(
            right: right, content: message.message,
          ),
          const SizedBox(
            height: 8,
          ),
          Text(
            Utils().changeDateToChatFormat(message.sentAt),
            style: const TextStyle(
              fontSize: 13,
              color: AppColors.textGrey,
            ),
          ),
        ],
      ),
    );
  }
}

