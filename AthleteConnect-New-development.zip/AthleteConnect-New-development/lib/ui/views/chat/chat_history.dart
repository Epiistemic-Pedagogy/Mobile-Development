

import 'package:athleteconnect/constants/variables.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/ui/views/chat/chat_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/util.dart';
import '../../../constants/asset.dart';
import '../../../constants/colors.dart';

class ChatHistoryScreen extends StatelessWidget {
  const ChatHistoryScreen({super.key, required this.isUserAgent});

final bool isUserAgent;
  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<ChatViewModel>.reactive(
        viewModelBuilder: () => ChatViewModel(),
        onModelReady: (model) {
          model.isOnline = false;
        },
        builder: (context, model, child) =>
            Scaffold(
              backgroundColor: AppColors.fillColor,
              appBar: AppBar(
                automaticallyImplyLeading: false,
                backgroundColor: AppColors.fillColor,
                title: Row(
                  children: [
                    InkWell(
                      onTap: () => Navigator.of(context).pop(),
                      child: const Icon(Icons.arrow_back, color: AppColors.white,),
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    Text(
                      'Chat History',
                      style: context.textTheme.titleLarge?.copyWith(
                          color:  AppColors.white,
                          fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
              body: Stack(
                fit: StackFit.expand,
                children: [
                  // Your content
                  Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                            child: model.isOnline ?
                            ListView(
                              children: [
                                const SizedBox(height: 19),
                                Container(),
                              ],
                            ) :
                            ListView.builder(
                                itemCount: 7,
                                itemBuilder: (BuildContext context, int index) {
                                  return HistoryItems(message: Variables.defaultMessage, name: "Henry", imageUrl: AppAssets.markFace, isRead: false, date: "2 days ago", isOnline: false,);
                                }
                            ),
                          ),
                        ]
                    ),
                  ),

                  model.isLoading ? Utils().loadingContainer("Please wait", AppColors.white, false) : Container()
                ],
              ),
            ));
  }
}

class HistoryItems extends StatelessWidget {
  const HistoryItems({
    super.key,
    required this.message,
    required this.name,
    required this.imageUrl,
    required this.isRead,
    required this.date,
    required this.isOnline
  });
  final String message;
  final String name;
  final String imageUrl;
  final bool isRead;
  final String date;
  final bool isOnline;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 90,
        padding: const EdgeInsets.all(6),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        child:Row(
          children: [
            CircleAvatar(
              backgroundImage: AssetImage(imageUrl),
              radius: 20,
            ),
            const SizedBox(width: 10,),
            Expanded(child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      name,
                      style: context.textTheme.bodyLarge?.copyWith(
                          color: AppColors.white, fontWeight: isRead ? FontWeight.w600 : FontWeight.w400,
                          fontSize: 14),
                    ),
                    Text(
                      isOnline ? Utils().changeDateFormat(date) : date,
                      style: context.textTheme.bodySmall?.copyWith(
                          color: AppColors.textGrey, fontWeight: FontWeight.w200,
                          fontSize: 12),
                    ),
                  ],
                ),

                Text(
                  message,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis, // Adds '...' if the text overflows
                  style: context.textTheme.labelMedium?.copyWith(
                      color: AppColors.white, fontWeight: isRead ? FontWeight.w300 : FontWeight.w300,
                      fontSize: 12),
                ),
              ],
            )),
          ],
        )
    );
  }
}