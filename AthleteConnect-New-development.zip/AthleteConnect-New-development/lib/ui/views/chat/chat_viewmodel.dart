

import 'dart:convert';

import 'package:athleteconnect/app/locator.dart';
import 'package:athleteconnect/constants/form_validation.dart';
import 'package:athleteconnect/models/extra_data.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/services/endpoint_ref.dart';
import 'package:athleteconnect/services/prefmanager.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../constants/routes.dart';
import '../../../constants/variables.dart';
import '../../../models/message_object.dart';

class ChatViewModel extends BaseViewModel {

  final fieldController = TextEditingController();
  bool isOnline = false;
  List<MessageObject> messages = [];
  bool showButton = false;
  bool isLoading = false;
  final endPoints = EndpointRef();
  final prefManager = PrefManager();
  FirebaseAuth? auth;
  UserProfile? recipient, currentUser;

  void showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }

  void fetchStoredData () async{
    var data = await prefManager.readObject(Variables.Users);
    if (data != null){
      currentUser = UserProfile.fromJson(data);
    }
  }

  void checkTextField(){
    fieldController.addListener(() {
      // Show button if the field has text, hide if it's empty
      showButton = fieldController.text.isNotEmpty;
      notifyListeners();
    });
  }

  void initiateVideoCall(){
    final videoData = ExtraVideoData(currentUser: currentUser, recipient: recipient );
    locator<GoRouter>().push(AppRoutes.videoViewScreen, extra: videoData );
  }

  void getUserChat(String receiverId){
    auth ??= FirebaseAuth.instance;
    DatabaseReference messageRef = endPoints.userMessages(auth!.currentUser!.uid, receiverId);
    messageRef.orderByChild("sentAt").onValue.listen((event) async {
      if (event.snapshot.exists){
        messages = [];
        for (final child in event.snapshot.children){
          final String jsonData = jsonEncode(child.value);
          Map<String, dynamic> responseData = jsonDecode(jsonData);
          final messageObject = MessageObject.fromJson(responseData);
          messages.insert(0, messageObject);
          notifyListeners();
        }
      }
    });
  }

  void sendMessage(String receiverId){
    auth ??= FirebaseAuth.instance;
    String? response  = FormValidation.stringValidation(fieldController.text);
    if (response != null){
      showToastMessage(response);
      return;
    }
    final currentUserId = auth!.currentUser!.uid;
    final currentTime = DateTime.now().millisecondsSinceEpoch.toString();
    final messageId = currentUserId + currentTime;
    
    final messageObject = MessageObject(messageId, currentUserId, currentTime, fieldController.text, false);
    endPoints.userLastMessage(currentUserId, receiverId).set(messageObject.toJson());
    endPoints.userMessages(currentUserId, receiverId).child(messageId).set(messageObject.toJson());
    endPoints.userLastMessage(receiverId, currentUserId).set(messageObject.toJson());
    endPoints.userMessages(receiverId, currentUserId).child(messageId).set(messageObject.toJson());
    fieldController.text = "";
    notifyListeners();
  }


}