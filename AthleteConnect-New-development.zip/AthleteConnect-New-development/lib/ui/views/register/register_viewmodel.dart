
import 'package:athleteconnect/constants/form_validation.dart';
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/ui/dialogs/verify_email.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/locator.dart';
import '../../../constants/colors.dart';
import '../../../constants/routes.dart';

class RegisterViewModel extends BaseViewModel {
  final emailAddressController = TextEditingController();
  final passwordController = TextEditingController();
  final agentEmailAddressController = TextEditingController();
  final agentPasswordController = TextEditingController();
  final focusNode = FocusNode();
  final agentFocusNode = FocusNode();
  bool isVisible = true;
  bool isAgentVisible = true;
  bool isLoggingIn = false;
  int currentIndex = 0;
  bool isForAgent = false;
  FirebaseAuth? auth;
  BuildContext? context;

  void toggleVisibility() {
    isVisible = !isVisible;
    notifyListeners();
  }

  void toggleAgentVisibility(){
    isAgentVisible = !isAgentVisible;
    notifyListeners();
  }

  void showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }


  void goToLogin() {
    locator<GoRouter>().push(AppRoutes.loginScreen);
  }

  void registerUser() async {
    String email, password;
    if (isForAgent){
      email = agentEmailAddressController.text;
      password = agentPasswordController.text;
    }else{
      email = emailAddressController.text;
      password = passwordController.text;
    }
    String? response = FormValidation.emailValidation(email);
    if (response != null){
      showToastMessage(response);
      return;
    }
    String? passwordResponse = FormValidation.passwordValidation(password);
    if (passwordResponse != null){
      showToastMessage(passwordResponse);
      return;
    }
    isLoggingIn = true;
    notifyListeners();
    auth ??= FirebaseAuth.instance;
    showToastMessage(password);
     try {
      final credential = await auth!.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      print(credential.user);
      showToastMessage("Is logging in");
      // Send Email verificationlink
      ActionCodeSettings actionCodeSettings = ActionCodeSettings(
        url: "",
        handleCodeInApp: false,
        androidPackageName: 'com.team.athleteconnect',
        androidInstallApp: false,
        androidMinimumVersion: '12',
        iOSBundleId: 'com.team.athleteconnect',
      );
      try {
        showToastMessage("Sending email link");
        auth!.sendSignInLinkToEmail(email: emailAddressController.text, actionCodeSettings: actionCodeSettings);
        showPreviewDialog(context!);
      }
      catch (e) {
        print('Failed to send email verification: $e');
        showToastMessage('Failed to send email verification: $e');
      }

    } on FirebaseAuthException catch (e) {
      isLoggingIn = false;
      if (e.code == 'weak-password') {
        print('The password provided is too weak.');
        showToastMessage('The password provided is too weak.');
      } else if (e.code == 'email-already-in-use') {
        showToastMessage('The account already exists for that email.');
      }
      notifyListeners();
    } catch (e) {
      showToastMessage('$e');
      isLoggingIn = false;
      notifyListeners();
    }
  }

  void showPreviewDialog(BuildContext context){
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30.0),
          topRight: Radius.circular(30.0),
        ),
      ),
      backgroundColor: AppColors.solidGrey,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      constraints: BoxConstraints(
          maxHeight: context.heightPercent(0.5)),
      builder: (BuildContext context) {
        return ConfirmEmailBottomSheet(onConfirmAction: goToLogin, isLogin: false, loginViewModel: null, registerViewModel: this,
        );
      },
    );
  }

}