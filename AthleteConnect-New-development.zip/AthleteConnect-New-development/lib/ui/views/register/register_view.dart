
  import 'package:athleteconnect/app/util.dart';
  import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
  import 'package:athleteconnect/ui/views/login/login_view.dart';
  import 'package:athleteconnect/ui/views/register/register_viewmodel.dart';
  import 'package:flutter/cupertino.dart';
  import 'package:flutter/material.dart';
  import 'package:flutter_svg/svg.dart';
  import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

  import '../../../constants/asset.dart';
  import '../../../constants/colors.dart';
  import '../../widgets/custom_button.dart';
  import '../../widgets/custom_text_form_field.dart';

  class RegisterView extends StatelessWidget {
    const RegisterView({super.key});

    @override
    Widget build(BuildContext context) {
      ToastContext().init(context);
      return ViewModelBuilder<RegisterViewModel>.reactive(
          viewModelBuilder: () => RegisterViewModel(),
          onViewModelReady: (model) {
            model.isForAgent = false;
            model.context = context;
          },
          builder: (context, model, child) => SafeArea(
              child: DefaultTabController(
                initialIndex: 0,
                length: 2,
                child: DefaultTabControllerListener(
                    onTabChanged:(int index) {
                      model.currentIndex = index;
                      if ( index == 1) {
                        model.isForAgent = true;
                      }else {
                        model.isForAgent = false;
                      }
                    },
                    child:  Scaffold(
                      backgroundColor: AppColors.deepBlack,
                      body: Stack(
                        fit: StackFit.expand,
                        children: [
                          // Background image
                          Image.asset(
                            AppAssets.registerBg, // Path to your image in assets folder
                            fit: BoxFit.cover, // Ensures the image covers the entire screen
                          ),
                          // Your content
                          Padding(
                            padding: const EdgeInsets.all(16),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                    child: ListView(
                                      children: [
                                        const SizedBox(height: 19),
                                        Align(
                                          alignment: Alignment.centerLeft,
                                          child: InkWell(
                                            onTap: () => Navigator.of(context).pop(),
                                            child: Container(
                                                margin: const EdgeInsets.symmetric(horizontal: 5),
                                                child: const Icon(Icons.arrow_back, color: AppColors.white, weight: 16,)
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 45),

                                        SvgPicture.asset(AppAssets.whiteLogo, width: 60, height: 50,),
                                        const SizedBox(height: 25,),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              "Regi",
                                              style: context.textTheme.titleLarge?.copyWith(
                                                  color: AppColors.white,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                            Text(
                                              "ster",
                                              style: context.textTheme.titleLarge?.copyWith(
                                                  color: AppColors.buttonColor,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                          ],),
                                        const SizedBox(height: 75,),
                                        SizedBox(
                                          height: 50,
                                          child: TabBar(
                                            isScrollable: false,
                                            dividerColor: AppColors.appGreen ,
                                            dividerHeight: 0,
                                            unselectedLabelColor: AppColors.white,
                                            labelColor: AppColors.buttonColor,
                                            labelStyle: context.textTheme.bodyLarge?.copyWith(
                                                color: AppColors.white,
                                                fontWeight: FontWeight.w500),
                                            unselectedLabelStyle:
                                            context.textTheme.bodyLarge?.copyWith(
                                                color: AppColors.white,
                                                fontWeight: FontWeight.w500),
                                            indicatorColor: AppColors.buttonColor,
                                            indicatorWeight: 3.0,
                                            tabAlignment: TabAlignment.fill,
                                            tabs: const [
                                              Tab(
                                                  child: Expanded(
                                                    child: Text(
                                                      'Athlete',
                                                    ),
                                                  )
                                              ),
                                              Tab(
                                                  child:  Expanded(
                                                    child: Text(
                                                      'Agent',
                                                    ),
                                                  )),
                                            ],
                                          ),
                                        ),
                                        SizedBox(
                                          height: 400,
                                          child: TabBarView(
                                            children: [
                                              SingleChildScrollView(
                                                child: Padding (
                                                    padding: const EdgeInsets.all(16.0),
                                                    child:Column(
                                                      children: [
                                                        const SizedBox(
                                                          height: 30,
                                                        ),
                                                        CustomTextFormField(
                                                            label: "Email",
                                                            textInputType: TextInputType.emailAddress,
                                                            controller: model.emailAddressController),
                                                        const SizedBox(
                                                          height: 30,
                                                        ),
                                                        CustomTextFormField(
                                                            label: "Password",
                                                            focus: model.focusNode,
                                                            isPassword: true,
                                                            max: 1,
                                                            onTap: model.toggleVisibility,
                                                            isObscure: model.isVisible,
                                                            controller: model.passwordController),
                                                        const SizedBox(
                                                          height: 30,
                                                        ),
                                                      ],
                                                    )) ,
                                              ),
                                              SingleChildScrollView(
                                                child: Padding (
                                                    padding: const EdgeInsets.all(16.0),
                                                    child:Column(
                                                      children: [
                                                        const SizedBox(
                                                          height: 30,
                                                        ),
                                                        CustomTextFormField(
                                                            label: "Email",
                                                            textInputType: TextInputType.emailAddress,
                                                            controller: model.agentEmailAddressController),
                                                        const SizedBox(
                                                          height: 30,
                                                        ),
                                                        CustomTextFormField(
                                                            label: "Password",
                                                            focus: model.agentFocusNode,
                                                            isPassword: true,
                                                            max: 1,
                                                            isObscure: model.isAgentVisible,
                                                            onTap: model.toggleAgentVisibility,
                                                            controller: model.agentPasswordController),
                                                        const SizedBox(
                                                          height: 30,
                                                        ),
                                                      ],
                                                    )) ,
                                              ),// Content for Tab 2
                                            ],
                                          ),
                                        )
                                      ],
                                    )
                                ),
                                Padding(
                                    padding: const EdgeInsets.all(0.0),
                                    child: Column(
                                      children: [
                                        CustomButton(text:  "Register", onTap: () =>
                                            model.registerUser()),
                                        const SizedBox(height: 9,),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Text(
                                              "Already have an account? ",
                                              style: context.textTheme.bodyMedium?.copyWith(
                                                  color: AppColors.white,
                                                  fontWeight: FontWeight.w300),
                                            ),
                                            InkWell(
                                              onTap: model.goToLogin,
                                              child: Text(
                                                "login",
                                                style: context.textTheme.bodyLarge?.copyWith(
                                                    color: AppColors.buttonColor,
                                                    fontWeight: FontWeight.w500),
                                              ),
                                            )
                                          ],)

                                      ],
                                    )

                                ),

                              ],
                            ),
                          ),

                          model.isLoggingIn ? Utils().loadingContainer("Creating account", AppColors.white, true) : Container()
                        ],
                      ),
                    )),
              )
      ));
    }
  }