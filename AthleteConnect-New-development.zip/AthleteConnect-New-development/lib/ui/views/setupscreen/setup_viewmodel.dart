

import 'package:athleteconnect/constants/form_validation.dart';
import 'package:athleteconnect/models/agent_profile.dart';
import 'package:athleteconnect/models/athlete_profile.dart';
import 'package:athleteconnect/models/auth_data.dart';
import 'package:athleteconnect/ui/views/dashboard/dashboard_view.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/locator.dart';
import 'dart:math';
import '../../../constants/routes.dart';

class SetupScreenViewModel extends BaseViewModel {
  final firstnameController = TextEditingController();
  final lastnameController = TextEditingController();
  final aboutMeController = TextEditingController();
  final phoneController = TextEditingController();
  final clientNameController = TextEditingController();
  final futureGoals = TextEditingController();
  final achievementsController = TextEditingController();
  List<String> myList = [];
  List<String> clientNames = [];
  bool isDocumentAvailable = false;
  String? fileName;
  String? fileSize;
  String selectedValue = "Select an option";
  PlatformFile? documentFile;

  bool isForAgent = false;
  String allClients = "";

  final List <String> spinnerItems = [
    'Select an option',
    'Masters Degree (MSC)',
    'B.S.C Bachelors Degree',
    'Postgraduate qualification',
    'Doctoral degree',
    'A Level',
    'High School Diploma',
    'I have no education'
  ];


  void switchValue(String newValue) {
    selectedValue = newValue;
    notifyListeners();
  }
  
  void addClientListener(){
    clientNameController.addListener(() {
      String text = clientNameController.text;
      if (text.endsWith(', ')) {
        // Remove the last comma and trim the text
        String trimmedText = text.substring(0, text.length - 1).trim();
        if (trimmedText.isNotEmpty) {
          // Add the text to the list
            clientNames.add(trimmedText);
           // displayNames();
            notifyListeners();

          // Clear the TextField after adding
          clientNameController.clear();
        }
      } });
  }


  void requestPermission() async {
    // Request permission
    PermissionStatus status = await Permission.storage.request();

    if (status.isGranted) {
      pickFile();
    } else {
      _showToastMessage("Permission Denied");
    }
  }

  void pickFile() async {
    // Using file picker to select image or PDF files
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf', 'png', 'jpg', 'jpeg'],
    );

    if (result != null && result.files.isNotEmpty) {
      // Get the selected file
      PlatformFile file = result.files.first;
      documentFile = file;
      fileName = file.name;
      fileSize = _formatBytes(file.size, 2);
      notifyListeners();
    } else {
      // If no file selected
      fileName = null;
      fileSize = null;
      notifyListeners();
    }
  }

  // Utility function to format bytes in a readable form
  String _formatBytes(int bytes, int decimals) {
    if (bytes <= 0) return "0 B";
    const suffixes = ["B", "KB", "MB", "GB", "TB"];
    var i = (log(bytes.toDouble()) / log(1024)).floor();
    var size = bytes / pow(1024, i);
    return "${size.toStringAsFixed(decimals)} ${suffixes[i]}";
  }

  void _showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }


  void goToPhotoSetup() {
    if (isForAgent){
      final agentData = AgentProfile(firstname: firstnameController.text, lastname:
      lastnameController.text, bio: aboutMeController.text, phone: phoneController.text, interest: myList, clients: clientNames, mediaUrl: null, dpUrl: null);
      final authData = AuthData(agentProfile: agentData, athleteProfile: null, file: documentFile);
      locator<GoRouter>().push(AppRoutes.profilePhotoScreen, extra: authData);
    }else {
      final athleteData = AthleteProfile(firstname: firstnameController.text,lastname:  lastnameController.text, bio: aboutMeController.text, phone: phoneController.text,
      interest: myList, education: selectedValue, mediaUrl: null, goals: futureGoals.text, dpUrl: null, achievements: achievementsController.text);
      final authData = AuthData(agentProfile: null, athleteProfile: athleteData, file: documentFile);
      locator<GoRouter>().push(AppRoutes.profilePhotoScreen, extra: authData);
    }
  }

  void checkForAthleteData(){
    if (FormValidation.stringValidation(firstnameController.text) != null){
      _showToastMessage(FormValidation.stringValidation(firstnameController.text)!);
      return;
    }

    if (FormValidation.stringValidation(lastnameController.text) != null){
      _showToastMessage(FormValidation.stringValidation(lastnameController.text)!);
      return;
    }

    if (FormValidation.stringValidation(phoneController.text) != null){
      _showToastMessage(FormValidation.stringValidation(phoneController.text)!);
      return;
    }

    if (FormValidation.stringValidation(achievementsController.text) != null){
      _showToastMessage(FormValidation.stringValidation(achievementsController.text)!);
      return;
    }

    if (FormValidation.stringValidation(futureGoals.text) != null){
      _showToastMessage(FormValidation.stringValidation(futureGoals.text)!);
      return;
    }
    
    if (myList.isEmpty){
      _showToastMessage("Select your sport interest");
      return;
    }

    if (selectedValue == spinnerItems[0]){
      _showToastMessage("Select your educational status");
      return;
    }

    goToPhotoSetup();
   
  }

  void checkForAgentData(){
    if (FormValidation.stringValidation(firstnameController.text) != null){
      _showToastMessage(FormValidation.stringValidation(firstnameController.text)!);
      return;
    }

    if (FormValidation.stringValidation(lastnameController.text) != null){
      _showToastMessage(FormValidation.stringValidation(lastnameController.text)!);
      return;
    }

    if (FormValidation.stringValidation(phoneController.text) != null){
      _showToastMessage(FormValidation.stringValidation(phoneController.text)!);
      return;
    }


    if (myList.isEmpty){
      _showToastMessage("Select your sport interest");
      return;
    }

    goToPhotoSetup();

  }


  bool isActive(String sport){
    if (myList.contains(sport)){
       return true;
    }else{
      return false;
    }
  }

  void updateList(String sport){
    if (myList.contains(sport)){
      myList.remove(sport);
      isActive(sport);
    }else {
      myList.add(sport);
    }
    isActive(sport);
    notifyListeners();
  }



}