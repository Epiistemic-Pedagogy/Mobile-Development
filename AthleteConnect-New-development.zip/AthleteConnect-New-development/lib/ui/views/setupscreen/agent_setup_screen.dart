
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/ui/views/setupscreen/setup_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:stacked/stacked.dart';

import '../../../constants/asset.dart';
import '../../../constants/colors.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_text_form_field.dart';

class AgentSetUpView extends StatelessWidget {
  const AgentSetUpView({super.key});

  @override
  Widget build(BuildContext context) {

    return ViewModelBuilder<SetupScreenViewModel>.reactive(
        viewModelBuilder: () => SetupScreenViewModel(),
        onViewModelReady: (model) {
          model.addClientListener();
        },
        builder: (context, model, child) => Scaffold(
          backgroundColor: AppColors.fillColor,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: AppColors.fillColor,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                InkWell(
                  onTap: () => Navigator.of(context).pop(),
                  child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 5),
                      child: const Icon(Icons.arrow_back, color: AppColors.white, weight: 16,)
                  ),
                ),
                Text(
                  "Agent Account Setup",
                  style: context.textTheme.titleMedium?.copyWith(
                      color: AppColors.white, fontWeight: FontWeight.w600),
                ),
                const SizedBox(
                  width: 10,
                )
              ],
            ),
          ),
          body: SafeArea(
            child: Padding(
                padding: const EdgeInsets.all(16),
                child: Form(
                child:  Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Expanded(child: ListView (
                      children: [
                        CustomTextFormField(
                            label: "First name",
                            textInputType: TextInputType.text,
                            controller: model.firstnameController),
                        const SizedBox(
                          height: 16,
                        ),
                        CustomTextFormField(
                            label: "Lastname",
                            controller: model.lastnameController
                        ),
                        const SizedBox(
                          height: 16,
                        ),
                        CustomTextFormField(
                            label: "About me (optional)",
                            controller: model.aboutMeController
                        ),
                        const SizedBox(
                          height: 16,
                        ),
                        CustomTextFormField(
                            label: "Phone",
                            textInputType: TextInputType.phone,
                            controller: model.phoneController
                        ),
                        const SizedBox(
                          height: 16,
                        ),
                        Text(
                          "What sports are you responsible for",
                          style: context.textTheme.bodyMedium?.copyWith(
                              color: AppColors.white, fontWeight: FontWeight.w400),
                        ),
                        const SizedBox(height: 6,),
                        // Section for the different sports
                         Expanded(child:
                         Wrap(
                           spacing: 4,
                           runSpacing: 8,
                           alignment: WrapAlignment.start,
                           children: [
                             InkWell(
                               onTap: () {
                                 model.updateList("Football");
                               },
                               child:  InterestWidget(
                                 title: "Football",
                                 isActive: model.isActive("Football"),
                               ),
                             ),
                             InkWell(
                               onTap: () { model.updateList("BasketBall");},
                               child: InterestWidget(
                                 title: "BasketBall",
                                 isActive: model.isActive("BasketBall"),
                               ),
                             ),
                             InkWell(
                               onTap: () { model.updateList("Table Tennis");},
                               child: InterestWidget(
                                 title: "Table Tennis",
                                 isActive: model.isActive("Table Tennis"),
                               ),
                             ),
                             InkWell(
                               onTap: () { model.updateList("Badminton");},
                               child: InterestWidget(
                                 title: "Badminton",
                                 isActive: model.isActive("Badminton"),
                               ),
                             ),
                             InkWell(
                               onTap: () { model.updateList("Swimming");},
                               child: InterestWidget(
                                 title: "Swimming",
                                 isActive: model.isActive("Swimming"),
                               ),
                             ),
                             InkWell(
                               onTap: () { model.updateList("Running");},
                               child: InterestWidget(
                                 title: "Running",
                                 isActive: model.isActive("Running"),
                               ),
                             ),
                             InkWell(
                               onTap: () { model.updateList("Archery");},
                               child: InterestWidget(
                                 title: "Archery",
                                 isActive: model.isActive("Archery"),
                               ),
                             ),
                             InkWell(
                               onTap: () { model.updateList("Cycling");},
                               child: InterestWidget(
                                 title: "Cycling",
                                 isActive: model.isActive("Cycling"),
                               ),
                             ),
                           ],
                         ),),
                        const SizedBox(height: 16,),
                        Wrap(
                          children: [
                            Text(
                              "List some of your past clients",
                              style: context.textTheme.bodyMedium?.copyWith(
                                  color: AppColors.white, fontWeight: FontWeight.w400),
                            ),
                            Text(
                              "(Use comma ',' to seperate the names of the clients)",
                              style: context.textTheme.bodySmall?.copyWith(
                                  color: AppColors.white, fontWeight: FontWeight.w300),
                            ),
                          ],
                        ),
                        Expanded(child:
                        Text(
                          model.clientNames.isEmpty ? 'No items yet' : model.clientNames.join(', '),
                          style: context.textTheme.bodyMedium?.copyWith(
                              color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 12),
                        ),),
                        const SizedBox(height: 5,),
                        CustomTextFormField(
                            label: "Type here",
                            controller: model.clientNameController
                        ),
                        const SizedBox(height: 16,),
                        Wrap(
                          children: [
                            Text(
                              "Documents (.pdf, .jpeg, .jpg)",
                              style: context.textTheme.bodyMedium?.copyWith(
                                  color: AppColors.white, fontWeight: FontWeight.w400),
                            ),
                            Text(
                              "(Add a certificate or relevant document to validate your profile)",
                              style: context.textTheme.bodySmall?.copyWith(
                                  color: AppColors.white, fontWeight: FontWeight.w300, fontSize: 12),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10,),
                        GestureDetector(
                          onTap: () { model.requestPermission();},
                          child: Text(
                            "Upload document",
                            style: context.textTheme.labelLarge?.copyWith(
                                color:  AppColors.buttonColor,
                                decoration: TextDecoration.underline,
                                fontSize: context.widthPercent(0.03)),
                          )
                        ),
                        const SizedBox(height: 10),

                        // Display file name and size if a file is selected
                        if (model.fileName != null && model.fileSize != null)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "File Name: ${model.fileName!}",
                          style: context.textTheme.bodyMedium?.copyWith(
                        color:  AppColors.white,
                              fontWeight: FontWeight.w500,
                              fontSize: 10
                        ),),
                        const SizedBox(height: 5),
                        Text(
                          "File Size: ${model.fileSize}",
                          style: context.textTheme.bodySmall?.copyWith(
                              color:  AppColors.white,
                              fontWeight: FontWeight.w300,
                              fontSize: 8
                          )
                        ),
                      ],
                    )



                      ],
                    )),
                    Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: CustomButton(text:  "Next", onTap: () {
                          model.isForAgent = true;
                            model.checkForAgentData();
                        }),

                    )
                  ],
                ),
            )
            )
          )
        ));
  }

}

class InterestWidget extends StatelessWidget {
  const InterestWidget({
    super.key,
    required this.isActive,
    required this.title,
  });
  final bool isActive;
  final String title;
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(6),
      margin: const EdgeInsets.symmetric(horizontal: 2),
      decoration: BoxDecoration(
          color: isActive ? AppColors.textGrey : AppColors.deepBlack,
          border: Border.all(
              color: isActive ? AppColors.buttonColor : AppColors.white),
          borderRadius: BorderRadius.circular(7)),
      child: Expanded(
        child: Text(
          "${title}",
          style: context.textTheme.labelLarge?.copyWith(
              color: isActive ? AppColors.buttonColor : AppColors.white,
              fontSize: context.widthPercent(0.03)),
        ),
      )
    );
  }
}