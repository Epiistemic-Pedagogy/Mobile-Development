

import 'package:athleteconnect/app/util.dart';
import 'package:athleteconnect/constants/asset.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/events.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../constants/colors.dart';
import 'event_viewmodel.dart';

class EventProfileScreen extends StatelessWidget {
  const EventProfileScreen({super.key, required this.eventObject, required this.isNew});

  final EventObject? eventObject;
  final bool? isNew;

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<EventViewModel>.reactive(
        viewModelBuilder: () => EventViewModel(),
        onModelReady: (model) {
          model.retriveUserData();
          if (eventObject != null){
            model.checkForAttendees(eventObject!.eventId!);
            model.getUserInfo(eventObject!.ownerId!);
          }
          model.ctx = context;
        },
        builder: (context, model, child) =>
        Scaffold(
            backgroundColor: AppColors.fillColor,
            body: Column(
              children: [
                Expanded(
                  child:
                  ListView(
                    children: [
                      Container(
                          height: 300,
                          child: Stack(
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Image.network(eventObject!.imageUrl!, height: 300.0,  fit: BoxFit.fitWidth ,),
                                  ),
                                ],
                              ),


                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Padding(padding: EdgeInsets.all(16),
                                  child: InkWell(
                                    onTap: () {
                                      if (isNew != null){
                                         model.goToHomePage();
                                      }else{
                                        Navigator.of(context).pop();
                                      }
                                    },
                                    child: const Icon(Icons.arrow_back, color: AppColors.white,),
                                  ),),
                                  Padding(padding: EdgeInsets.all(16),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            eventObject!.title!,
                                            style: context.textTheme.bodyLarge?.copyWith(
                                                color:  AppColors.white,
                                                fontSize: 15, fontWeight: FontWeight.w900),
                                          ),

                                          const SizedBox(height: 9.0),
                                          Text(
                                            "Date: ${Utils().formatEventDate(eventObject!.date!)} \nTime: ${eventObject!.time!}",
                                            style: context.textTheme.bodyMedium?.copyWith(
                                                color:  AppColors.white,
                                                fontSize: 14, fontWeight: FontWeight.w400),
                                          ),
                                          const SizedBox(height: 3.0),
                                          Text(
                                            eventObject!.address!,
                                            style: context.textTheme.bodyMedium?.copyWith(
                                                color:  AppColors.white,
                                                fontSize: 14, fontWeight: FontWeight.w400),
                                          ),
                                        ],
                                      ),

                                      model.eventOwner != null ?  CircleAvatar(
                                        backgroundImage:  NetworkImage(model.eventOwner!.dpUrl!, ),
                                        radius: 20,
                                      ) :
                                      const CircleAvatar(
                                        backgroundImage: AssetImage(AppAssets.photoAvatar,),
                                        radius: 20,
                                      ),
                                    ],
                                  ),)
                                ],
                              ),

                            ],
                          )

                      ),
                      const SizedBox(height: 20.0),
                      Padding(padding: EdgeInsets.all(10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('About Event',
                              style: TextStyle(color: AppColors.white, fontSize: 12.0, fontWeight: FontWeight.bold)),
                          const SizedBox(height: 20.0),
                          Text(
                            eventObject!.about!,
                            style: context.textTheme.bodyMedium?.copyWith(
                                color:  AppColors.white,
                                fontSize: 14, fontWeight: FontWeight.normal),
                          ),
                          const SizedBox(height: 16.0),
                          Text(
                            "Attendees",
                            style: context.textTheme.bodyMedium?.copyWith(
                                color:  AppColors.white,
                                fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                          const SizedBox(height: 10.0),

                          model.attendeesList.isEmpty ? Center(
                            child: Text('No Attendee',
                                style: TextStyle(color: AppColors.white,
                                    fontSize: 11.0, fontWeight: FontWeight.w200)),
                          ) :
                          SizedBox(
                            height: 60,
                            child: ListView.builder(
                                itemCount: model.attendeesList.length,
                                physics: const NeverScrollableScrollPhysics(),
                                scrollDirection: Axis.horizontal,
                                shrinkWrap: true,
                                itemBuilder: (BuildContext context, int index) {
                                  return AttendeeItems(imageUrl: model.attendeesList[index]!.dpUrl! );
                                }
                            ),
                          )

                        ],
                      ),),

                    ],
                  ),

                ),

                model.userInfo != null ? model.attendeesIdList.contains(model.userInfo!.id!) ? Container() :
                Padding(padding: EdgeInsets.all(10.0),
                    child: GestureDetector(
                      onTap: () {
                        model.addEventToCalendar(eventObject!);
                      },
                      child: Container(
                          height: 41.0,
                          decoration: BoxDecoration(
                              border: Border.all(color:  AppColors.buttonColor,
                                  style: BorderStyle.solid,
                                  width: 0.5),
                              color:  AppColors.buttonColor,
                              borderRadius: BorderRadius.circular(5.0)
                          ),
                          padding: EdgeInsets.all(10.0),
                          child: Center(
                            child: Text('Add to Calender',
                              style: context.textTheme.bodyMedium?.copyWith(
                                  color:  AppColors.white,
                                  fontSize: 14, fontWeight: FontWeight.bold),
                            ),
                          )
                      ),

                    )
                ) : Container(),
              ],
            )
        ));
  }
}

class AttendeeItems extends StatelessWidget {
  const AttendeeItems({
    super.key,
    required this.imageUrl,

  });

  final String? imageUrl;

  @override
  Widget build(BuildContext context) {
    return Container(
        width: 50,
        padding: const EdgeInsets.all(6),
        margin: const EdgeInsets.symmetric(horizontal: 2),
        decoration: BoxDecoration(
            border: Border.all(color:  AppColors.buttonColor,
                style: BorderStyle.solid,
                width: 0.5),
            color:  AppColors.buttonColor,
            borderRadius: BorderRadius.circular(5.0)
        ),
        child: userImage(imageUrl, context),);
  }

  Image userImage(String? image, BuildContext cont) {
    if (image != null) {
      return Image.network(image, height: 50.0, width:50, fit: BoxFit.fitWidth);
    }else{
      return Image.asset(AppAssets.photoAvatar, height: 40.0,  width: MediaQuery.of(cont).size.width, fit: BoxFit.fitWidth,);
    }
  }
}

