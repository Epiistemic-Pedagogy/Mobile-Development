

import 'dart:convert';
import 'dart:io';

import 'package:athleteconnect/constants/form_validation.dart';
import 'package:athleteconnect/constants/variables.dart';
import 'package:athleteconnect/models/events.dart';
import 'package:athleteconnect/models/extra_data.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/services/prefmanager.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:googleapis/calendar/v3.dart' as calendar;
import 'package:googleapis/tagmanager/v1.dart';
import 'package:googleapis_auth/auth_io.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../app/locator.dart';
import '../../../constants/routes.dart';
import '../../../services/endpoint_ref.dart';

class EventViewModel extends BaseViewModel {
  final titleController =TextEditingController();
  final addressController =TextEditingController();
  final aboutController = TextEditingController();
  TimeOfDay? selectedTime;
  DateTime? selectedDate;
  DateTime? selectedEndDate;
  FirebaseAuth? auth;
  bool isLoading = false;
  bool isFetching = false;
  bool isForAgent = false;
  bool isCreatingEvent = false;
  bool isOffline = false;
  File? selectedImage;
  final endpoints = EndpointRef();
  final prefManager = PrefManager();
  UserProfile? userInfo, eventOwner;
  List<EventObject> eventList = [];
  List<UserProfile> attendeesList = [];
  List<String> attendeesIdList = [];
  BuildContext? ctx;


  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: [calendar.CalendarApi.calendarScope],
  );

  calendar.CalendarApi? calendarApi;
  bool _isLoggedIn = false;


  void _showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }

  void goToEventProfile(EventObject eventObject, bool isNew){
    if (isNew){
      eventObject.isNew = true;
      locator<GoRouter>().go(AppRoutes.eventProfileScreen, extra: eventObject);
    }else {
    locator<GoRouter>().push(AppRoutes.eventProfileScreen, extra: eventObject);
    }

  }

  void goToHomePage(){
    locator<GoRouter>().go(AppRoutes.homeScreen, extra: userInfo);
  }

  void requestPermission() async {
    PermissionStatus status = await Permission.storage.request();
    if (status.isGranted) {
      pickFile();
    } else {
      _showToastMessage("Permission Denied");
    }
  }

  void retriveUserData() async {
    var data = await prefManager.readObject(Variables.Users);
    if (data != null){
      userInfo = UserProfile.fromJson(data);
      notifyListeners();
    }

  }

  void pickFile() async {
    // Using file picker to select image or PDF files
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
    );

    if (result != null && result.files.isNotEmpty) {
      // Get the selected file
      selectedImage = File(result.files.single.path!);
      notifyListeners();
    } else {
      // If no file selected
      _showToastMessage("Cancelled");
    }
  }


  void selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate) {
      selectedDate = picked;
      notifyListeners();
    }
  }

  void selectEndDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedEndDate ?? DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedEndDate) {
      selectedEndDate = picked;
      notifyListeners();
    }
  }

  void selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime ?? TimeOfDay.now(),
    );
    if (picked != null && picked != selectedTime) {
      selectedTime = picked;

      notifyListeners();
    }
  }


  void checkNewEvent(BuildContext buildContext) async {
    String? response = FormValidation.stringValidation(titleController.text);
    if (response != null){
      _showToastMessage(response);
      return;
    }
    String? addressResponse = FormValidation.stringValidation(addressController.text);
    if (addressResponse != null){
      _showToastMessage(addressResponse);
      return;
    }

    String? aboutResponse = FormValidation.stringValidation(aboutController.text);
    if (aboutResponse != null){
      _showToastMessage(aboutResponse);
      return;
    }

    if(selectedDate == null){
      _showToastMessage('Select an Event Date');
      return;
    }
    if(selectedTime == null){
      _showToastMessage('Select an Event Time');
      return;
    }

    if(selectedImage == null){
      _showToastMessage('Add an image for the event');
      return;
    }

    auth = FirebaseAuth.instance;
    final eventId = auth!.currentUser!.uid + DateTime.now().millisecondsSinceEpoch.toString() ;
    var eventObject = EventObject(title: titleController.text, date: selectedDate!.millisecondsSinceEpoch.toString(), endDate: selectedEndDate!.millisecondsSinceEpoch.toString() , ownerId: auth!.currentUser!.uid,
        time: selectedTime!.format(buildContext), eventId: eventId, address: addressController.text,imageUrl: null, about: aboutController.text);
    isCreatingEvent = true;
    notifyListeners();
    try {
      File fileToUpload = File(selectedImage!.path);
      Reference storageRef = endpoints.eventMediaRef().child(eventObject.eventId!);
      UploadTask uploadTask = storageRef.putFile(fileToUpload);
      TaskSnapshot snapshot = await uploadTask;
      String downloadUrl = await snapshot.ref.getDownloadURL();
      eventObject.imageUrl = downloadUrl;
      await endpoints.currentEvent().child(eventObject.eventId!).set(eventObject.toJson());
      await endpoints.userEventRef(auth!.currentUser!.uid).child(eventId).child("id").set(eventObject.eventId);
      _showToastMessage("Event Successfully Created");
      goToEventProfile(eventObject, true);

    } catch (e){
      print('Error while saving Profile: $e');
      isCreatingEvent = false;
      notifyListeners();
    }
  }


  void addEventToCalendarUsingWebRoute(EventObject eventObject) async {
    //final String formattedStartDateTime = dateFormat.format(DateTime.parse(eventObject.date!).toUtc());
    //final String formatedEndDateTime = dateFormat.format(DateTime.parse(eventObject.endDate!).toUtc());
    final DateFormat dateFormat = DateFormat("yyyyMMdd'T'HHmmss'Z'");
    DateTime dateTime = DateTime.fromMillisecondsSinceEpoch(int.parse(eventObject.date!));
    DateTime endDateTime = DateTime.fromMillisecondsSinceEpoch(int.parse(eventObject.endDate!));


    String formattedDate = dateFormat.format(dateTime.toUtc());
    String formattedEndDate = dateFormat.format(endDateTime.toUtc());
    _showToastMessage("It got here");
    // Create the Google Calendar event URL
    final String calendarUrl =
        'https://www.google.com/calendar/render?action=TEMPLATE'
        '&text=${eventObject.title}'
        '&dates=$formattedDate/$formattedEndDate'
        '&details=${eventObject.about}'
        '&location=${eventObject.address}'
        '&sf=true&output=xml';

    // Encode the URL to ensure it's valid
    final Uri encodedUrl = Uri.parse(calendarUrl);

    // Launch the URL to open the Google Calendar
    if (await canLaunchUrl(encodedUrl)) {
    await launchUrl(encodedUrl);
    } else {
      _showToastMessage("Could not launch $encodedUrl");
    throw 'Could not launch $encodedUrl';
    }
  }


 void _handleGoogleSignIn(BuildContext context, EventObject eventObject) async {
    try {
      final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
      if (googleUser == null) {
        // User canceled the sign-in
        return;
      }

      final GoogleSignInAuthentication googleAuth = await googleUser.authentication;
      final AuthClient authClient = authenticatedClient(
        http.Client(),
        AccessCredentials(
          AccessToken(
            'Bearer',
            googleAuth.accessToken!, // Use only access token
            DateTime.now().add(const Duration(hours: 1)).toUtc(),
          ),
          null, // Set refreshToken to null
          const ['https://www.googleapis.com/auth/calendar'],
        ),
      );

      // Initialize the Google Calendar API with the authenticated client
      _isLoggedIn = true;
      calendarApi = calendar.CalendarApi(authClient);
      notifyListeners();
      addEventToCalendar(eventObject);
    } catch (error) {
      print('Error in Google Sign-In: $error');
    }
  }

  void addEventToCalendar( EventObject eventObject) async {
    if (!_isLoggedIn && calendarApi == null) {
      // If not logged in, prompt to log in
       _handleGoogleSignIn(ctx!, eventObject);
       return;
    }
    final DateFormat dateFormat = DateFormat("yyyyMMdd'T'HHmmss'Z'");
    DateTime dateTime = DateTime.fromMillisecondsSinceEpoch(int.parse(eventObject.date!));
    DateTime endDateTime = DateTime.fromMillisecondsSinceEpoch(int.parse(eventObject.endDate!));


    String formattedDate = dateFormat.format(dateTime);
    String formattedEndDate = dateFormat.format(endDateTime);
    final event = calendar.Event(
      summary: eventObject.title,
      location: eventObject.address,
      start: calendar.EventDateTime(
        dateTime: dateTime.toUtc(),
        timeZone: 'GMT',
      ),
      end: calendar.EventDateTime(
        dateTime: endDateTime.toUtc(),
        timeZone: 'GMT',
      ),
    );

    try {
      final createdEvent = await calendarApi!.events.insert(event, "primary");
      if (createdEvent.status == "confirmed") {
        _showToastMessage('Event added to Google Calendar!');
        auth ??= FirebaseAuth.instance;
        final currentUserId = auth!.currentUser!.uid;
        endpoints.registeredMembers( eventObject.eventId!).child(currentUserId).child(Variables.id).set(currentUserId);
        endpoints.userRegisteredEventRef( currentUserId, eventObject.eventId!).child(Variables.id).set(eventObject.eventId!);
        notifyListeners();
        ScaffoldMessenger.of(ctx!).showSnackBar(
          SnackBar(content: Text('Event added to Google Calendar!')),
        );
      } else {
        _showToastMessage('Failed to add event to Google Calendar.');
      }
    } catch (error) {
      print('Error adding event to Google Calendar: $error');
      ScaffoldMessenger.of(ctx!).showSnackBar(
        const SnackBar(content: Text('Error adding event to Google Calendar.')),
      );
    }
  }

  void checkForAttendees(String eventId) {
    endpoints.registeredMembers(eventId).onValue.listen((event) async {
      for (final child in event.snapshot.children)  {
        // Handle the attendee data.
        final String jsonData = jsonEncode(child.value);
        Map<String, dynamic> responseData = jsonDecode(jsonData);
        final extraData =  ExtraData.fromJson(responseData);
        if (!attendeesIdList.contains(extraData.id)){
          attendeesIdList.add(extraData.id!);
        }
          final data = await endpoints.userProfileRef(extraData.id!).get();
          final String profileJsonData = jsonEncode(data.value);
          Map<String, dynamic> profileResponse = jsonDecode(profileJsonData);
          final userProfile =  UserProfile.fromJson(profileResponse);
          attendeesList.add(userProfile);
        notifyListeners();
      }
    }, onError: (error) {
      // Error.
    });
  }


  void createNewEvent(){
    locator<GoRouter>().push(AppRoutes.newEventScreen);
  }


  void fetchEventList(String? userId)  {
    DatabaseReference? eventRef;
    if (userId != null){
      eventRef = endpoints.userEventRef(userId);
    }else {
      eventRef = endpoints.currentEvent();
    }

    isFetching = true;
    notifyListeners();

    eventRef.orderByChild("date").onValue.listen((event) async {
      if (event.snapshot.exists){
        isFetching = false;
        for (final child in event.snapshot.children) {
          final String jsonData = jsonEncode(child.value);
          Map<String, dynamic> responseData = jsonDecode(jsonData);
          if (userId != null){
            final extraData =  ExtraData.fromJson(responseData);
            final ref = endpoints.currentEvent().child(extraData.id!);
            final snapshot = await ref.get();
            if (snapshot.exists) {
              final String newJsonData = jsonEncode(snapshot.value);
              Map<String, dynamic> newResponseData = jsonDecode(newJsonData);
              final eventObject =  EventObject.fromJson(newResponseData);
              eventList.insert(0,eventObject);
              notifyListeners();
            }
          }else{
            final eventObject =  EventObject.fromJson(responseData);
            eventList.insert(0, eventObject);
            notifyListeners();
          }
        }


      }else {
        isFetching = false;
        notifyListeners();
        _showToastMessage("No Data");
      }

    }, onError: (error) {
      isFetching = false;
      notifyListeners();
      _showToastMessage(error!);
      // Error.
    });
  }

  void getUserInfo(String userId) async {
    final response = await endpoints.userProfileRef(userId).get();
    if (response.exists){
      final String jsonData = jsonEncode(response.value);
      Map<String, dynamic> responseData = jsonDecode(jsonData);
      final user =  UserProfile.fromJson(responseData);
      eventOwner = user;
      notifyListeners();
    }
  }
}