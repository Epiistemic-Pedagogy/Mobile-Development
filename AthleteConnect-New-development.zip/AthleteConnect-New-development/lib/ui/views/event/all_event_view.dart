

import 'package:athleteconnect/app/util.dart';
import 'package:athleteconnect/constants/asset.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/events.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/views/event/event_viewmodel.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../constants/colors.dart';

class AllEventView extends StatelessWidget  {
  const AllEventView({super.key,
  required this.userId,
  required this.isUpcoming});


  final String? userId;
  final bool? isUpcoming;

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<EventViewModel>.reactive(
        viewModelBuilder: () => EventViewModel(),
        onModelReady: (model) {
          model.retriveUserData();
          model.fetchEventList(userId);
        },
        builder: (context, model, child) =>
            Scaffold(
              backgroundColor: AppColors.fillColor,
              appBar: AppBar(
                automaticallyImplyLeading: false,
                backgroundColor: AppColors.fillColor,
                title: Row(
                  children: [
                    InkWell(
                      onTap: () => Navigator.of(context).pop(),
                      child: const Icon(Icons.arrow_back, color: AppColors.white,),
                    ),
                    const SizedBox(
                      width: 16,
                    ),
                    Text( isUpcoming != null ?
                    isUpcoming! ? "Upcoming Events" : "Happening Now" : 'Events',
                      style: context.textTheme.titleLarge?.copyWith(
                          color:  AppColors.white,
                          fontSize: 16, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                actions: [
                  InkWell(
                    onTap: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('This action is not available yet')),
                      );
                    },
                    child: const Icon(Icons.search, size: 24, color: AppColors.buttonColor,),
                  ),

                  const SizedBox(width: 16,),
                ],
              ),
              body: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Expanded(
                        child: model.isFetching ?
                        Utils().loadingContainer("Please wait", AppColors.white, false):
                        ListView.builder(
                            itemCount: model.eventList.length,
                            itemBuilder: (BuildContext context, int index) {
                              if (model.eventList.isEmpty){
                                return Center(child: Text('No Data'),);
                              }else{
                                return EventCards(eventObject: model.eventList[index], dpUrl: model.userInfo?.dpUrl, eventViewModel: model, );
                              }
                            }
                        ),
                      ),
                    ]
                ),
              ),

                 floatingActionButton: userId == null ? FloatingActionButton(
                onPressed: () {
                  model.createNewEvent();
                },
                backgroundColor: AppColors.buttonColor,
                child: const Icon(Icons.add, color: AppColors.white,),
              ) : null,
                floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
            ));
  }
}

class EventCards extends StatelessWidget {
  const EventCards({
    super.key,
    required this.eventObject,
    required this.dpUrl,
    required this.eventViewModel,

  });
  final EventObject eventObject;
  final String? dpUrl;
  final EventViewModel eventViewModel;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap:() { eventViewModel.goToEventProfile(eventObject, false); },
      child: Container(
          height: 250,
          decoration: BoxDecoration(
              color: AppColors.fillColor,
              border: Border.all(
                  color:  AppColors.fillColor.withOpacity(1) ),
              borderRadius: BorderRadius.circular(10)),
          padding: const EdgeInsets.all(6),
          margin: const EdgeInsets.symmetric(horizontal: 2),
          child:Stack(
            children: [
              Row(
                children: [
                  Expanded(child: Image.network(eventObject.imageUrl!, scale: 2, fit: BoxFit.cover,),)
                ],
              ),
              Column(
                children: [
                  Expanded(
                    child: Container(
                        height: 41.0,
                        decoration: BoxDecoration(
                            border: Border.all(color:  AppColors.buttonColor.withOpacity(0),
                                style: BorderStyle.solid,
                                width: 0.5),
                            color:  AppColors.buttonColor.withOpacity(0),
                            borderRadius: BorderRadius.circular(5.0)
                        ),
                        padding: EdgeInsets.all(10.0),
                        child: Center(
                          child: Text('',
                            style: context.textTheme.bodyMedium?.copyWith(
                                color:  AppColors.white,
                                fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        )
                    ),
                  ),
                  Padding(padding: EdgeInsets.all(10.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              eventObject.title!,
                              maxLines: 2,
                              style: context.textTheme.bodyLarge?.copyWith(
                                  color: AppColors.white, fontWeight: FontWeight.w900,
                                  fontSize: 16),
                            ),
                            const SizedBox(height: 5,),
                            Text(
                              Utils().formatEventDate(eventObject.date!),
                              style: context.textTheme.bodySmall?.copyWith(
                                  color: AppColors.white, fontWeight: FontWeight.normal,
                                  fontSize: 14),
                            ),
                            const SizedBox(height: 5,),
                            Text(
                              eventObject.time!,
                              style: context.textTheme.bodySmall?.copyWith(
                                  color: AppColors.white, fontWeight: FontWeight.normal,
                                  fontSize: 12),
                            ),
                          ],
                        ),

                        Text(''),
                      ],
                    ),
                  )
                ],
              )



            ],
          )
      ),
    );
  }
}