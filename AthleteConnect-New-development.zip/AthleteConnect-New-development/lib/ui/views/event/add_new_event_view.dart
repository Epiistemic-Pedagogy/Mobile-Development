

import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/ui/widgets/custom_text_form_field.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/util.dart';
import '../../../constants/colors.dart';
import 'event_viewmodel.dart';

class CreateNewEvent extends StatelessWidget {
  const CreateNewEvent({super.key});

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<EventViewModel>.reactive(
        viewModelBuilder: () => EventViewModel(),
        onModelReady: (model) {

        },
        builder: (context, model, child) =>
            // Scaffold(
            //   backgroundColor: AppColors.fillColor,
            //   appBar: AppBar(
            //     backgroundColor: AppColors.fillColor,
            //     automaticallyImplyLeading: false,
            //     title: Row(
            //       children: [
            //         InkWell(
            //           onTap: () => Navigator.of(context).pop(),
            //           child: const Icon(Icons.arrow_back, color: AppColors.white,),
            //         ),
            //         const SizedBox(
            //           width: 16,
            //         ),
            //         Text(
            //           "New Events",
            //           style: context.textTheme.titleLarge?.copyWith(
            //               color:  AppColors.white,
            //               fontSize: 16, fontWeight: FontWeight.w600),
            //         ),
            //       ],
            //     ),
            //   ),
            //   body: Stack(
            //     fit: StackFit.expand,
            //     children: [
            //       // Your content
            //       Padding(
            //         padding: const EdgeInsets.all(16),
            //         child: Column(
            //             mainAxisAlignment: MainAxisAlignment.center,
            //             children: [
            //               Container(
            //                 child: ,
            //               ),
            //               Expanded(
            //                 child: model.selectedImage != null ? Image.file(model.selectedImage!, height: 240,
            //                   fit: BoxFit.cover,) :
            //                Center(
            //                  child: Column(
            //                    children: [
            //
            //                    ],
            //                  ),
            //                ),
            //               ),
            //             ]
            //         ),
            //       ),
            //       model.isCreatingEvent ? Utils().loadingContainer("Creating Profile", AppColors.white, false) : Container()
            //     ],
            //   ),
            // ));
        Scaffold(
            backgroundColor: AppColors.fillColor,
            appBar:  AppBar(
              backgroundColor: AppColors.fillColor,
              automaticallyImplyLeading: false,
              title: Row(
                children: [
                  InkWell(
                    onTap: () => Navigator.of(context).pop(),
                    child: const Icon(Icons.arrow_back, color: AppColors.white,),
                  ),
                  const SizedBox(
                    width: 16,
                  ),
                  Text(
                    "Create an Event",
                    style: context.textTheme.titleLarge?.copyWith(
                        color:  AppColors.white,
                        fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            body: Stack(
              children: [
                Container(
                    padding: EdgeInsets.all(10.0),
                    child:
                    ListView(
                      children: [
                        SizedBox(height: 16.0),
                        Column(
                          crossAxisAlignment:  CrossAxisAlignment.start,
                          children: [
                            const Text('Event Title', style: TextStyle(color: AppColors.white, fontSize: 11.0, fontWeight: FontWeight.w400)),
                             CustomTextFormField(label: "Type here", controller: model.titleController),
                            const SizedBox(height: 16.0),
                            const Text('About Event (Min 150 characters', style: TextStyle(color: AppColors.white, fontSize: 11.0, fontWeight: FontWeight.w400)),
                            Container(
                                margin: EdgeInsets.only(top: 20.0),
                                height: 76.0,
                                child: Container(
                                  padding: EdgeInsets.all(10.0),
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          color: AppColors.solidGrey,
                                          style: BorderStyle.solid,
                                          width: 0.5
                                      ),
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.circular(4.0)
                                  ),
                                  child:  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: <Widget>[
                                      Expanded(
                                        child: TextFormField(
                                          keyboardType: TextInputType.multiline,
                                          maxLines: null,
                                          controller: model.aboutController,
                                          style: context.textTheme.bodyMedium?.copyWith(
                                              color:  AppColors.white,
                                              fontSize: 14, fontWeight: FontWeight.normal),
                                          decoration: InputDecoration(
                                            focusedBorder: UnderlineInputBorder(
                                                borderSide: BorderSide(color: AppColors.fieldGrey)
                                            ),
                                            hintText: 'Type about here',
                                            hintStyle: TextStyle(color: AppColors.fieldGrey, fontWeight: FontWeight.w300, fontFamily: 'Avenir', fontSize:  15.0),
                                          ),
                                        ),
                                      ),
//                    Icon(Icons.expand_more,
//                        color: colorClass.appGrey,
//                        size: 13.0),
                                    ],
                                  ),
                                )
                            ),


                            const SizedBox(height: 20.0),
                            Row(
                              children: [
                                InkWell(

                                  child: Text(
                                      'Select Start Date',
                                    style: context.textTheme.bodyMedium?.copyWith(
                                        color:  AppColors.buttonColor,
                                        fontSize: 14, fontWeight: FontWeight.w500),
                                  ),
                                  onTap: () => model.selectDate(context),
                                ),
                                const SizedBox(width: 15.0),

                                Text(
                                  model.selectedDate != null
                                      ? Utils().changeDateFormat("${model.selectedDate!.toLocal()}".split(' ')[0])
                                      : "No Date Selected",
                                  style: context.textTheme.bodyMedium?.copyWith(
                                      color:  AppColors.white,
                                      fontSize: 14, fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),

                            const SizedBox(height: 20.0),

                            Row(
                              children: [
                                InkWell(
                                  onTap: () => model.selectTime(context),
                                  child: Text(
                                    'Select Time',
                                    style: context.textTheme.bodyMedium?.copyWith(
                                        color:  AppColors.buttonColor,
                                        fontSize: 14, fontWeight: FontWeight.w500),
                                  ),
                                ),
                                const SizedBox(width: 15.0),

                                Text(
                                  model.selectedTime != null
                                      ? model.selectedTime!.format(context)
                                      : "No Time Selected",
                                  style: context.textTheme.bodyMedium?.copyWith(
                                      color:  AppColors.white,
                                      fontSize: 14, fontWeight: FontWeight.w500),
                                ),

                              ],
                            ),

                            const SizedBox(height: 20.0),
                            Row(
                              children: [
                                InkWell(

                                  child: Text(
                                    'Selected End Date',
                                    style: context.textTheme.bodyMedium?.copyWith(
                                        color:  AppColors.buttonColor,
                                        fontSize: 14, fontWeight: FontWeight.w500),
                                  ),
                                  onTap: () => model.selectEndDate(context),
                                ),
                                const SizedBox(width: 15.0),

                                Text(
                                  model.selectedEndDate != null
                                      ? Utils().changeDateFormat("${model.selectedEndDate!.toLocal()}".split(' ')[0])
                                      : "No Date Selected",
                                  style: context.textTheme.bodyMedium?.copyWith(
                                      color:  AppColors.white,
                                      fontSize: 14, fontWeight: FontWeight.w500),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10.0),
                          ],
                        ),
                        Column(
                          crossAxisAlignment:  CrossAxisAlignment.start,
                          children: [
                            const Text("Venue", style: TextStyle(color: AppColors.white, fontSize: 11.0, fontWeight: FontWeight.w400)),
                            CustomTextFormField(label: "Enter event venue here", controller: model.addressController),

                          ],
                        ),

                        SizedBox(height:10.0),
                        Container(
                          child: model.selectedImage == null ? Center(
                            child:  Text('No image selected.')) :
                            Expanded(child: Image.file(model.selectedImage!, height: 300.0,fit: BoxFit.fill),),
                        ),
                        SizedBox(height:17.0),
                        Row(
                            children: <Widget>[
                              Text('Upload Event picture', style: TextStyle(color: AppColors.white, fontSize:15.0, fontWeight: FontWeight.bold, fontFamily: 'Avenir')),
                              SizedBox(width:20.0),
                              GestureDetector(
                                onTap: () {
                                  model.requestPermission();
                                },
                                child:  Container(
                                  width: 101,
                                  height: 50.0,
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                        color: AppColors.primary.withAlpha(5), width: 0.3),
                                    borderRadius: BorderRadius.circular(4.0),
                                    color: AppColors.primary,
                                  ),
                                  child: Center(
                                    child: Text('Add Image', style: TextStyle(color: AppColors.white, fontSize:15.0, fontWeight: FontWeight.bold, fontFamily: 'Avenir')),
                                  ) ,
                                ),
                              ),

                            ]

                        ),
                        SizedBox(height:50.0),
                        GestureDetector(
                          onTap: () {
                            model.checkNewEvent(context);
                          },
                          child: Container(
                              height: 41.0,
                              decoration: BoxDecoration(
                                  border: Border.all(color:  AppColors.buttonColor,
                                      style: BorderStyle.solid,
                                      width: 0.5),
                                  color:  AppColors.buttonColor,
                                  borderRadius: BorderRadius.circular(5.0)
                              ),
                              padding: EdgeInsets.all(10.0),
                              child: Center(
                                child: Text('CREATE EVENT',
                                  style: TextStyle(color: AppColors.white,
                                      fontSize: 15.0, fontWeight: FontWeight.bold, fontFamily: 'Avenir'), textAlign: TextAlign.center,),
                              )
                          ),

                        )

                      ],
                    )
                ),
                model.isCreatingEvent ? Utils().loadingContainer("Creating Event", AppColors.white, true) : Container(),
              ],
            )
        ));
  }

}