
  import 'package:athleteconnect/constants/asset.dart';
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
  import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/user_profile.dart';
  import 'package:athleteconnect/ui/views/recommended/recommended_viewmodel.dart';
import 'package:firebase_auth/firebase_auth.dart';
  import 'package:flutter/cupertino.dart';
  import 'package:flutter/material.dart';
  import 'package:stacked/stacked.dart';
  import 'package:toast/toast.dart';

  import '../../../app/util.dart';
  import '../../../constants/colors.dart';

  class RecommendedScreen extends StatelessWidget {
    const RecommendedScreen({super.key,
    required this.userProfile});

    final UserProfile userProfile;
    @override
    Widget build(BuildContext context) {
     ToastContext().init(context);
      return ViewModelBuilder<RecommendedViewModel>.reactive(
          viewModelBuilder: () => RecommendedViewModel(),
          onModelReady: (model) {
            model.auth = FirebaseAuth.instance;
            model.loadRecommendedUsers(userProfile.isAgent!); // load agent when the value for this is false meaning that this is an athlete account looking for agents
          },
          builder: (context, model, child) =>
              Scaffold(
                backgroundColor: AppColors.fillColor,
                appBar: AppBar(
                  backgroundColor: AppColors.fillColor,
                  automaticallyImplyLeading: false,
                  title: Row(
                    children: [
                      InkWell(
                        onTap: () => Navigator.of(context).pop(),
                        child: const Icon(Icons.arrow_back, color: AppColors.white,),
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      Text(
                        userProfile.isAgent! ? "Recommended Athlete" : "Recommended Agent",
                        style: context.textTheme.titleLarge?.copyWith(
                            color:  AppColors.white,
                            fontSize: 16, fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                  actions: [
                    Row(
                      children: [
                        InkWell(
                          onTap: () {
                            model.showPreviewDialog(context);
                          },
                          child: const Icon(Icons.filter_list, weight: 30, color: AppColors.buttonColor, ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                      ],
                    )
                  ],
                ),
                body: Stack(
                  fit: StackFit.expand,
                  children: [
                    // Your content
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                              child: model.userList.isNotEmpty ?
                          ListView.builder(
                          itemCount: model.userList.length,
                          itemBuilder: (BuildContext context, int index) {
                            return RecommendedItems(userProfile: model.userList[index], viewModel: model);
                          }
                      ) :
                              Center(
                                child: Text(
                                  'No data',
                                  style: context.textTheme.bodyMedium?.copyWith(
                                      color:  AppColors.textGrey,
                                      fontSize: 13, fontWeight: FontWeight.w400),
                                ),
                              ),
                          ),
                        ]
                      ),
                    ),
                    model.isLoading ? Utils().loadingContainer("Please wait", AppColors.white, false) : Container()
                  ],
                ),
              ));
    }
  }

  class RecommendedItems extends StatelessWidget {
    const RecommendedItems({
      super.key,
      required this.userProfile,
      required this.viewModel,
    });

    final UserProfile userProfile;
    final RecommendedViewModel viewModel;
    @override
    Widget build(BuildContext context) {
      return Container(
          width: 150,
          decoration:  BoxDecoration(
            color: AppColors.solidGrey,
            borderRadius: BorderRadius.circular(5.0),
          ),
          padding: const EdgeInsets.only(bottom: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Image.network(userProfile.dpUrl!, height: 100, width: 150, fit: BoxFit.cover,),
              const SizedBox(height: 6,),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Text(
                    userProfile.firstname!,
                    style: context.textTheme.labelLarge?.copyWith(
                        color: AppColors.white, fontWeight: FontWeight.w600,
                        fontSize: 14),
                  ),
                  const SizedBox(height: 6,),
                  InkWell(
                    onTap: (){
                      viewModel.goToProfilePage(userProfile);
                    },
                    child: Container(
                        padding: const EdgeInsets.all(6),
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                            color: AppColors.buttonColor,
                            border: Border.all(
                                color: AppColors.buttonColor),
                            borderRadius: BorderRadius.circular(7)),
                        child: Expanded(
                          child: Text(
                            "View Profile",
                            style: context.textTheme.labelLarge?.copyWith(
                                color: AppColors.white,
                                fontSize: context.widthPercent(0.03)),
                          ),
                        )
                    ),
                  )
                ],
              ),


            ],
          )






      );
    }
  }