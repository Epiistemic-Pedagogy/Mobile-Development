

import 'dart:convert';

import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/services/endpoint_ref.dart';
import 'package:athleteconnect/ui/dialogs/filter_options.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/locator.dart';
import '../../../constants/colors.dart';
import '../../../constants/routes.dart';

class RecommendedViewModel extends BaseViewModel {

  bool isForAgent = false;
  bool isOffline = true;
  bool isLoading = false;
  List<UserProfile> userList = [];
  final endPointRef = EndpointRef();
  FirebaseAuth? auth;

  void goToProfilePage(UserProfile userProfile){
    locator<GoRouter>().push(AppRoutes.userProfileScreen, extra: userProfile);
  }


  void loadRecommendedUsers(bool loadAgents) async {
    final userResponse = await endPointRef.userRef().get();
    if (userResponse.exists){
      for (DataSnapshot snapshot in userResponse.children){
        final refKey = snapshot.ref.key.toString();
        final userData = await endPointRef.userProfileRef(refKey).get();
        final String profileJsonData = jsonEncode(userData.value);
        Map<String, dynamic> profileResponse = jsonDecode(profileJsonData);
        final userProfile = UserProfile.fromJson(profileResponse);
        if (loadAgents){
          if (!userProfile.isAgent!){
            userList.add(userProfile);
          }
        }else{
          if (userProfile.isAgent!){
            userList.add(userProfile);
          }
        }
      }
      notifyListeners();
    }
  }

  void filterBySportUsers() async {
    final userResponse = await endPointRef.userRef().get();
    if (userResponse.exists){

    }
  }

  void filterBasedOnAI() async {
    final userResponse = await endPointRef.userRef().get();
    if (userResponse.exists){

    }
    showToastMessage("Option not available at this time, not enough data to train model");
  }

  void clearAllFilters() {
    userList = [];
    loadRecommendedUsers(isForAgent);
  }


  void showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }

  void showPreviewDialog(BuildContext context){
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30.0),
          topRight: Radius.circular(30.0),
        ),
      ),
      backgroundColor: AppColors.solidGrey,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      constraints: BoxConstraints(
          maxHeight: context.heightPercent(0.5)),
      builder: (BuildContext context) {
        return FilterOptionDialog(viewModel: this,
        );
      },
    );
  }

}