
import 'dart:convert';

import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/models/athlete_profile.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/services/prefmanager.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/locator.dart';
import '../../../constants/colors.dart';
import '../../../constants/form_validation.dart';
import '../../../constants/routes.dart';
import '../../../constants/variables.dart';
import '../../../services/endpoint_ref.dart';
import '../../dialogs/verify_email.dart';


class LoginViewModel extends BaseViewModel {

  final emailAddressController = TextEditingController();
  final passwordController = TextEditingController();
  final agentEmailAddressController = TextEditingController();
  final agentPasswordController = TextEditingController();
  FirebaseAuth? auth;

  TabController? tabController;

  final focusNode = FocusNode();
  final agentFocusNode = FocusNode();
  bool isVisible = true;
  bool isAgentVisible = true;
  bool isLoggingIn = false;
  bool isForAgent = false;
  int currentIndex = 0;
  final prefManager = PrefManager();
  final databaseRef = EndpointRef();
  BuildContext? context;

  void toggleVisibility() {
    isVisible = !isVisible;
    notifyListeners();
  }

  void toggleAgentVisibility(){
    isAgentVisible = !isAgentVisible;
    notifyListeners();
  }

  void initTab(TickerProvider vsync){
    // Initialize the TabController
    tabController = TabController(length: 2, vsync: vsync);

    tabController!.addListener(() {
      if (tabController!.indexIsChanging) {
        isForAgent = tabController!.index == 1;
        print('Selected Tab: ${tabController!.index}');
      }
    });
  }

  void goToRegister() {
    locator<GoRouter>().push(AppRoutes.registerScreen);
  }
  void goToNextPage(){
    if (currentIndex == 0){
      goToAthleteSetup();
    }else{
      goToSetup();
    }
  }
  void goToSetup() {
    locator<GoRouter>().push(AppRoutes.agentProfileSetUpScreen);
  }
  void goToAthleteSetup() {
    locator<GoRouter>().push(AppRoutes.athleteProfileSetupScreen);
  }

  void goToHomePage(UserProfile userProfile){
    locator<GoRouter>().go(AppRoutes.homeScreen, extra: userProfile);
  }


  void loginUser() async {
    String email, password;
    if (isForAgent){
      email = agentEmailAddressController.text;
      password = agentPasswordController.text;
    }else{
      email = emailAddressController.text;
      password = passwordController.text;
    }
    String? response = FormValidation.emailValidation(email);
    if (response != null){
      showToastMessage(response);
      return;
    }
    String? passwordResponse = FormValidation.passwordValidation(password);
    if (passwordResponse != null){
      showToastMessage(passwordResponse);
      return;
    }
    isLoggingIn = true;
    notifyListeners();
    auth ??= FirebaseAuth.instance;
    if (context != null){
      try {
        await auth!.signInWithEmailAndPassword(email: email, password: password);
        showToastMessage("Login success");
        final val =  await prefManager.readObject(Variables.Users);
        if (val != null ){
          goToHomePage(UserProfile.fromJson(val));
        }else {
          // Check if the database has the stored details
          DatabaseReference userRef = databaseRef.userProfileRef(auth!.currentUser!.uid);
          final snapshot = await userRef.get();

          if (snapshot.exists) {
            final String jsonData = jsonEncode(snapshot.value);
            Map<String, dynamic> responseData = jsonDecode(jsonData);
            final userProfile =  UserProfile.fromJson(responseData);
            prefManager.save(Variables.Users, userProfile);
            goToHomePage(userProfile);
          } else {
            if (currentIndex == 0){
              goToAthleteSetup();
            }else {
              goToSetup();

            }
          }
        }
      } on FirebaseAuthException catch (e) {
        isLoggingIn = false;
        if (e.code == 'user-not-found') {
          print('No user found for that email.');
        } else if (e.code == 'wrong-password') {
          print('Wrong password provided for that user.');
        }
        notifyListeners();
      } catch (e) {
        showToastMessage('$e');
        isLoggingIn = false;
        notifyListeners();
      }
    }
  }

  void resendEmailConfirmation() async {
    ActionCodeSettings actionCodeSettings = ActionCodeSettings(
      url: "",
      handleCodeInApp: false,
      androidPackageName: 'com.team.athleteconnect',
      androidInstallApp: false,
      androidMinimumVersion: '12',
      iOSBundleId: 'com.team.athleteconnect',
    );
    auth ??= FirebaseAuth.instance;
    await auth!.sendSignInLinkToEmail(email: agentEmailAddressController.text.trim(), actionCodeSettings: actionCodeSettings);
    showToastMessage("Sent");
  }

  void showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }

  void showPreviewDialog(BuildContext context){
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30.0),
          topRight: Radius.circular(30.0),
        ),
      ),
      backgroundColor: AppColors.solidGrey,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      constraints: BoxConstraints(
          maxHeight: context.heightPercent(0.5)),
      builder: (BuildContext context) {
        return ConfirmEmailBottomSheet(onConfirmAction: () {
          }, isLogin: true, loginViewModel: this, registerViewModel: null,
        );
      },
    );
  }
}