
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/ui/views/login/login_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/util.dart';
import '../../../constants/asset.dart';
import '../../../constants/colors.dart';
import '../../widgets/custom_button.dart';
import '../../widgets/custom_text_form_field.dart';

class LoginView extends StatelessWidget {
  const LoginView({super.key});

  @override
  Widget build(BuildContext context) {
 //   TabController _tabController = TabController( length: 3, vsync: this);
    ToastContext().init(context);
    return ViewModelBuilder<LoginViewModel>.reactive(
        viewModelBuilder: () => LoginViewModel(),
        onModelReady: (model) {
          //model.initTab(TickerProviderStateMixin(context));
          model.isForAgent = false;
          model.context = context;
        },
        builder: (context, model, child) =>
            SafeArea(child:
            DefaultTabController(
              initialIndex: 0,
              length: 2,
              child: DefaultTabControllerListener(
                  onTabChanged: (int index) {
                    model.currentIndex = index;
                    if (index == 1){
                      model.isForAgent = true;
                    }else {
                      model.isForAgent = false;
                    }
                  },
                  child: Scaffold(
                    backgroundColor: AppColors.deepBlack,
                    body: Stack(
                      fit: StackFit.expand,
                      children: [
                        // Background image
                        Image.asset(
                          AppAssets.registerBg, // Path to your image in assets folder
                          fit: BoxFit.cover, // Ensures the image covers the entire screen
                        ),
                        // Your content
                        Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Expanded(
                                  child: ListView(
                                    children: [
                                      const SizedBox(height: 19),
                                      Align(
                                        alignment: Alignment.centerLeft,
                                        child: InkWell(
                                          onTap: () => Navigator.of(context).pop(),
                                          child: Container(
                                              margin: const EdgeInsets.symmetric(horizontal: 5),
                                              child: const Icon(Icons.arrow_back, color: AppColors.white, weight: 16,)
                                          ),
                                        ),
                                      ),
                                      const SizedBox(height: 45),

                                      SvgPicture.asset(AppAssets.whiteLogo, width: 40, height: 30,),
                                      const SizedBox(height: 25,),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            "Log",
                                            style: context.textTheme.titleLarge?.copyWith(
                                                color: AppColors.white,
                                                fontWeight: FontWeight.w500),
                                          ),
                                          Text(
                                            "in",
                                            style: context.textTheme.titleLarge?.copyWith(
                                                color: AppColors.buttonColor,
                                                fontWeight: FontWeight.w500),
                                          ),
                                        ],),
                                      const SizedBox(height: 75,),
                                      SizedBox(
                                        height: 50,
                                        child: TabBar(
                                          isScrollable: false,
                                          dividerColor: AppColors.appGreen ,
                                          dividerHeight: 0,
                                          unselectedLabelColor: AppColors.white,
                                          labelColor: AppColors.buttonColor,
                                          labelStyle: context.textTheme.bodyLarge?.copyWith(
                                              color: AppColors.white,
                                              fontWeight: FontWeight.w500),
                                          unselectedLabelStyle:
                                          context.textTheme.bodyLarge?.copyWith(
                                              color: AppColors.white,
                                              fontWeight: FontWeight.w500),
                                          indicatorColor: AppColors.buttonColor,
                                          indicatorWeight: 3.0,
                                          tabAlignment: TabAlignment.fill,
                                          tabs: const [
                                            Tab(
                                                child: Expanded(
                                                  child: Text(
                                                    'Athlete',
                                                  ),
                                                )
                                            ),
                                            Tab(
                                                child:  Expanded(
                                                  child: Text(
                                                    'Agent',
                                                  ),
                                                )),
                                          ],
                                        ),
                                      ),
                                      SizedBox(
                                        height: 400,
                                        child: TabBarView(
                                          children: [
                                            SingleChildScrollView(
                                              child: Padding (
                                                  padding: const EdgeInsets.all(16.0),
                                                  child:Column(
                                                    children: [
                                                      const SizedBox(
                                                        height: 30,
                                                      ),
                                                      CustomTextFormField(
                                                          label: "Email",
                                                          textInputType: TextInputType.emailAddress,
                                                          controller: model.emailAddressController),
                                                      const SizedBox(
                                                        height: 30,
                                                      ),
                                                      CustomTextFormField(
                                                          label: "Password",
                                                          focus: model.focusNode,
                                                          isPassword: true,
                                                          max: 1,
                                                          isObscure: model.isVisible,
                                                          onTap: model.toggleVisibility,
                                                          controller: model.passwordController),
                                                      const SizedBox(
                                                        height: 30,
                                                      ),
                                                    ],
                                                  )) ,
                                            ),
                                            SingleChildScrollView(
                                              child: Padding (
                                                  padding: const EdgeInsets.all(16.0),
                                                  child:Column(
                                                    children: [
                                                      const SizedBox(
                                                        height: 30,
                                                      ),
                                                      CustomTextFormField(
                                                          label: "Email",
                                                          textInputType: TextInputType.emailAddress,
                                                          controller: model.agentEmailAddressController),
                                                      const SizedBox(
                                                        height: 30,
                                                      ),
                                                      CustomTextFormField(
                                                          label: "Password",
                                                          focus: model.agentFocusNode,
                                                          isPassword: true,
                                                          max: 1,
                                                          isObscure: model.isAgentVisible,
                                                          controller: model.agentPasswordController,
                                                      onTap: model.toggleAgentVisibility,),
                                                      const SizedBox(
                                                        height: 30,
                                                      ),
                                                    ],
                                                  )) ,
                                            ),// Content for Tab 2
                                          ],
                                        ),
                                      )
                                    ],
                                  )
                              ),
                              Padding(
                                  padding: const EdgeInsets.all(0.0),
                                  child: Column(
                                    children: [
                                      CustomButton(text:  "Login", onTap: () =>
                                          model.loginUser()),
                                      const SizedBox(height: 9,),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            "Don't have an account? ",
                                            style: context.textTheme.bodyMedium?.copyWith(
                                                color: AppColors.white,
                                                fontWeight: FontWeight.w300),
                                          ),
                                          InkWell(
                                            onTap: model.goToRegister,
                                            child: Text(
                                              "Register",
                                              style: context.textTheme.bodyLarge?.copyWith(
                                                  color: AppColors.buttonColor,
                                                  fontWeight: FontWeight.w500),
                                            ),
                                          )
                                        ],)

                                    ],
                                  )

                              )
                            ],
                          ),
                        ),

                        model.isLoggingIn ? Utils().loadingContainer("Logging in", AppColors.white, true) : Container()

                      ],
                    ),
                  )),
            )
        ));
  }
}

class DefaultTabControllerListener extends StatefulWidget {
  const DefaultTabControllerListener({
    required this.onTabChanged,
    required this.child,
    super.key,
  });

  final ValueChanged<int> onTabChanged;

  final Widget child;

  @override
  State<DefaultTabControllerListener> createState() =>
      _DefaultTabControllerListenerState();
}

class _DefaultTabControllerListenerState
    extends State<DefaultTabControllerListener> {
  TabController? _controller;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();

    final TabController? defaultTabController =
    DefaultTabController.maybeOf(context);

    assert(() {
      if (defaultTabController == null) {
        throw FlutterError(
          'No DefaultTabController for ${widget.runtimeType}.\n'
              'When creating a ${widget.runtimeType}, you must ensure that there '
              'is a DefaultTabController above the ${widget.runtimeType}.',
        );
      }
      return true;
    }());

    if (defaultTabController != _controller) {
      _controller?.removeListener(_listener);
      _controller = defaultTabController;
      _controller?.addListener(_listener);
    }
  }

  void _listener() {
    final TabController? controller = _controller;

    if (controller == null || controller.indexIsChanging) {
      return;
    }

    widget.onTabChanged(controller.index);
  }

  @override
  void dispose() {
    _controller?.removeListener(_listener);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return widget.child;
  }
}