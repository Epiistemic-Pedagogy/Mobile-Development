

import 'dart:convert';

import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/models/PrivateData.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/services/endpoint_ref.dart';
import 'package:athleteconnect/ui/dialogs/privacy_options.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:stacked/stacked.dart';
import 'package:googleapis/calendar/v3.dart' as calendar;
import 'package:toast/toast.dart';
import '../../../app/locator.dart';
import '../../../constants/colors.dart';
import '../../../constants/routes.dart';
import '../../../services/prefmanager.dart';
import '../../dialogs/confirm_log_out.dart';

class SettingViewModel extends BaseViewModel {


  PrivacyData? privacyData;
  UserProfile? userProfile;
  final GoogleSignIn _googleSignIn = GoogleSignIn(
    scopes: [calendar.CalendarApi.calendarScope],
  );
  FirebaseAuth? auth;
  final prefManager = PrefManager();
  final endPointRef = EndpointRef();
  bool isSavingData  = false;
  bool isInitialising = false;

  void initItems(){
    auth = FirebaseAuth.instance;
    loadAllSettings();
  }


  void logOutAction(BuildContext context){
    ConfirmLogOut().showMyDialog(context, this);
  }

  void signOutUser() async {
    try {
      final googleUser = await _googleSignIn.signOut();
      if (googleUser == null) {
        auth!.signOut();
        prefManager.clearAll();
        locator<GoRouter>().go(AppRoutes.authScreen);
      }
    }
    catch (e){
      showToastMessage(e.toString());
    }
  }


  void showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }

  void loadAllSettings() async {
    isInitialising = true;
    notifyListeners();
    auth ??= FirebaseAuth.instance;
    final response  = await endPointRef.userPrivacySettingRef(auth!.currentUser!.uid).get();
    if (response.exists){
      final String jsonData = jsonEncode(response.value);
      Map<String, dynamic> responseData = jsonDecode(jsonData);
      privacyData =  PrivacyData.fromJson(responseData);
    }else {
      privacyData ??= PrivacyData(phone: true, bio: true, goals: true, media: true, achievements: true, openMessages: true, education: true, clients:  true, email: true);
    }
    isInitialising = false;
    notifyListeners();
  }

  void showPreviewDialog(BuildContext context){
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(30.0),
          topRight: Radius.circular(30.0),
        ),
      ),
      backgroundColor: AppColors.solidGrey,
      clipBehavior: Clip.antiAliasWithSaveLayer,
      constraints: BoxConstraints(
          maxHeight: context.heightPercent(0.5)),
      builder: (BuildContext context) {
        return PrivacyOptionsDialog(privacyObject: privacyData!, isAgent: userProfile!.isAgent!
        );
      },
    );
  }

}