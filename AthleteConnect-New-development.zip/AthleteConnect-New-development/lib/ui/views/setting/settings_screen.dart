

import 'package:athleteconnect/app/util.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/views/setting/setting_view_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../constants/colors.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key, required this.userProfile});

  final UserProfile userProfile;

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<SettingViewModel>.reactive(
        viewModelBuilder: () => SettingViewModel(),
        onViewModelReady: (model) {
          model.userProfile = userProfile;
          model.initItems();
        },
        builder: (context, model, child) => Scaffold(
            backgroundColor: AppColors.deepBlack,
            appBar: AppBar(
              automaticallyImplyLeading: false,
              backgroundColor: AppColors.deepBlack,
              title: Row(
                children: [
                  InkWell(
                    onTap: () => Navigator.of(context).pop(),
                    child: const Icon(Icons.arrow_back, color: AppColors.white,),
                  ),
                  const SizedBox(
                    width: 16,
                  ),
                  Text(
                    "Settings",
                    style: context.textTheme.titleLarge?.copyWith(
                        color:  AppColors.white,
                        fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ),
            body: SafeArea(child: Stack(
              children: [
                Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Security",
                        style: context.textTheme.titleMedium?.copyWith(
                            color:  AppColors.textGrey,
                            fontSize: 14, fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      InkWell(
                        onTap: () { model.showPreviewDialog(context); },
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "       Data Privacy",
                              style: context.textTheme.bodyMedium?.copyWith(
                                  color:  AppColors.white,
                                  fontSize: 14, fontWeight: FontWeight.w500),
                            ),
                            Text(
                              "         Decide which information you want to make visible to others",
                              style: context.textTheme.bodySmall?.copyWith(
                                  color:  AppColors.white,
                                  fontSize: 10, fontWeight: FontWeight.w200),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(
                        height: 25,
                      ),
                      Text(
                        "Account",
                        style: context.textTheme.titleMedium?.copyWith(
                            color:  AppColors.textGrey,
                            fontSize: 14, fontWeight: FontWeight.w500),
                      ),
                      const SizedBox(
                        width: 16,
                      ),
                      InkWell(
                        onTap: () {
                          model.showToastMessage("Not available yet");
                        },
                        child: Text(
                          "       Update Profile Information",
                          style: context.textTheme.bodyMedium?.copyWith(
                              color:  AppColors.white,
                              fontSize: 14, fontWeight: FontWeight.w500),
                        ),
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      InkWell(
                        onTap: () { model.logOutAction(context);},
                        child: Text(
                          "       Log Out",
                          style: context.textTheme.bodyMedium?.copyWith(
                              color:  AppColors.white,
                              fontSize: 14, fontWeight: FontWeight.w500),
                        ) ,
                      )

                      ,
                    ],
                  ),
                ),
                model.isSavingData || model.isInitialising ? Utils().loadingContainer(model.isSavingData ? "Saving" : "", AppColors.white, true) : Container()
              ]
            ))
        ));
  }
}