
import 'package:athleteconnect/constants/asset.dart';
import 'package:athleteconnect/constants/variables.dart';
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/ui/views/authpage/auth_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:stacked/stacked.dart';

import '../../../constants/colors.dart';
import '../../widgets/custom_button.dart';

class AuthView extends StatelessWidget{
  const AuthView({super.key});

  @override
  Widget build(BuildContext context) {
    return ViewModelBuilder<AuthViewModel>.reactive(
        viewModelBuilder: () => AuthViewModel(),
        onModelReady: (model) {
          model.setupAutomaticSlider();
        },
        builder: (context, model, child) => Scaffold(
          backgroundColor: AppColors.deepBlack,
          body: PageView.builder(
              controller: model.pageController,
              itemCount: model.introPages.length,
              onPageChanged: (index) {
                model.updateSelectedPageIndex(index);
              },
              itemBuilder: (context, index) {
                return Stack(
                  fit: StackFit.expand,
                  children: [
                    // Background image
                    Image.asset(
                      model.introPages[index].imageAsset!,// Path to your image in assets folder
                      fit: BoxFit.cover, // Ensures the image covers the entire screen
                    ),

                    // Your content
                    Container(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Expanded(
                              child: Column (

                                children: [
                                  const SizedBox(height: 145),
                                  SvgPicture.asset(AppAssets.whiteLogo, width: 60, height: 50,),
                                  const SizedBox(height: 25,),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        "Athlete",
                                        style: context.textTheme.titleLarge?.copyWith(
                                            color: AppColors.white,
                                            fontWeight: FontWeight.w500),
                                      ),
                                      Text(
                                        "Connect",
                                        style: context.textTheme.titleLarge?.copyWith(
                                            color: AppColors.buttonColor,
                                            fontWeight: FontWeight.w500),
                                      ),
                                    ],),
                                  const SizedBox(height: 75,),
                                  Expanded(child: Text(
                                    model.introPages [index].description!,
                                    style: context.textTheme.bodyLarge?.copyWith(
                                        color: AppColors.white,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w500),
                                    textAlign: TextAlign.center,
                                  ),)

                                ],
                              )
                          ),
                          Padding(
                              padding: const EdgeInsets.all(0.0),
                              child: Column(
                                children: [
                                  CustomButton(text:  "Create an account", onTap: () =>
                                      model.goToRegister()),
                                  const SizedBox(height: 9,),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        "Already have an account? ",
                                        style: context.textTheme.bodyMedium?.copyWith(
                                            color: AppColors.white,
                                            fontWeight: FontWeight.w300),
                                      ),
                                      InkWell(
                                        onTap: model.goToLogin,
                                        child: Text(
                                          "login",
                                          style: context.textTheme.bodyLarge?.copyWith(
                                              color: AppColors.buttonColor,
                                              fontWeight: FontWeight.w500),
                                        ),
                                      )
                                    ],)

                                ],
                              )

                          )
                        ],
                      ),
                    )

                  ],
                );
              }),
        ));
  }
}