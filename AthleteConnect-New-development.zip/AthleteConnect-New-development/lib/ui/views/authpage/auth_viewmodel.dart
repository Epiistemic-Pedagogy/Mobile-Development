

import 'dart:async';

import 'package:athleteconnect/constants/variables.dart';
import 'package:flutter/cupertino.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';

import '../../../app/locator.dart';
import '../../../constants/asset.dart';
import '../../../constants/routes.dart';
import '../../../models/app_into_slider_model.dart';

class AuthViewModel extends BaseViewModel {

   Timer? _timer;

  void goToLogin() {
    locator<GoRouter>().push(AppRoutes.loginScreen);
  }

  void goToRegister() {
    locator<GoRouter>().push(AppRoutes.registerScreen);
  }

  final pageController = PageController();

  int selectedPageIndex = 0;

  //check if isLastPage by subtracting the introPages by 1
  bool get isLastPage => selectedPageIndex == introPages.length - 1;

  //update the selectedPageIndex when onPage method of pageview.builder triggers
  void updateSelectedPageIndex(int index) {
    selectedPageIndex = index;
    notifyListeners();
  }

  //used pageController to animate to the last page by subtracting the pages by 1
  void skipAction() {
    pageController.animateToPage(introPages.length - 1,
        duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
  }

  //used pageController to animate to the next page by adding the selectedPageIndex by 1
  void nextAction() {
    pageController.animateToPage(selectedPageIndex + 1,
        duration: const Duration(milliseconds: 300), curve: Curves.easeInOut);
  }

  void setupAutomaticSlider(){
    _timer = Timer.periodic(Duration(seconds: 3), (Timer timer) {
      if (selectedPageIndex < introPages.length - 1) {
        selectedPageIndex++;
      } else {
        selectedPageIndex = 0; // Loop back to the first page
      }
      pageController.animateToPage(
        selectedPageIndex,
        duration: Duration(milliseconds: 500),
        curve: Curves.easeIn,
      );
    });
  }


  List<AppIntroductionScreenModel> introPages = [

    AppIntroductionScreenModel.fromJson(
      {
        "imageAsset": AppAssets.authBg,
        "description":
        Variables.authIntro
      },
    ),

    AppIntroductionScreenModel.fromJson(
      {
        "imageAsset": AppAssets.loginBg,
        "description":
        "AthleteConnect is the most secure place to find sport agents and Athletes. As an Athlete find out the available events happening around you where you can display and exhibit your skills"
      },
    ),

    AppIntroductionScreenModel.fromJson(
      {
        "imageAsset": AppAssets.registerBg,
        "description": "As an agent, get to know the best talents out there for recruitment or coaching"
      },
    ),

  ];
}