
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../app/locator.dart';
import '../../../constants/routes.dart';
import '../../../constants/variables.dart';
import '../../../models/user_profile.dart';
import '../../../services/prefmanager.dart';

class StartUpViewModel extends ReactiveViewModel {
  final _router = locator<GoRouter>();

  final PrefManager prefManager = PrefManager();
  void startUp(BuildContext context) async {
   // await Future.delayed(const Duration(seconds: 3));
    final val =  await prefManager.readObject(Variables.Users);
    final user  =  FirebaseAuth.instance.currentUser;
      if (user == null) {
        _router.go(AppRoutes.authScreen);
      } else {
        if (val != null ){
          _router.go(AppRoutes.homeScreen, extra: UserProfile.fromJson(val));
        }else {
          _router.go(AppRoutes.authScreen);
        }
      }


  }

  void _showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }
}