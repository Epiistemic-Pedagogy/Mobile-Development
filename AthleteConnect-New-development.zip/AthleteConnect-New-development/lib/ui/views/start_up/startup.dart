

import 'package:athleteconnect/ui/views/start_up/startup_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../constants/asset.dart';
import '../../../constants/colors.dart';

class StartUpView extends StatelessWidget {
  const StartUpView({super.key});

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<StartUpViewModel>.reactive(
        viewModelBuilder: () => StartUpViewModel(),
        onViewModelReady: (model) => model.startUp(context),
        builder: (context, model, child) => Scaffold(
          backgroundColor: AppColors.white,
          body
          : Center(
            child: SvgPicture.asset(AppAssets.appLogo, height: 120, width: 150,),
          ),
        ));
  }
}