

import 'dart:io';

import 'package:athleteconnect/models/PrivateData.dart';
import 'package:athleteconnect/models/agent_profile.dart';
import 'package:athleteconnect/models/athlete_profile.dart';
import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/services/endpoint_ref.dart';
import 'package:athleteconnect/services/prefmanager.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';
import 'package:path/path.dart' as path;

import '../../../app/locator.dart';
import '../../../constants/routes.dart';
import '../../../constants/variables.dart';
import '../dashboard/dashboard_view.dart';

class ProfileImageSetUpViewModel extends BaseViewModel {

  File? selectedImage;

  bool isForAgent = false;
  bool isCreatingProfile = false;
  FirebaseAuth? auth;
  final prefManager = PrefManager();
  final endpoints = EndpointRef();

  void requestPermission() async {
    PermissionStatus status = await Permission.storage.request();
    if (status.isGranted) {
      pickFile();
    } else {
      _showToastMessage("Permission Denied");
    }
  }

  void goToHomePage(UserProfile userProfile){
   // locator<GoRouter>().push(AppRoutes.homeScreen, extra: isForAgent);
    locator<GoRouter>().go(AppRoutes.homeScreen, extra: userProfile);
  }

    // Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (BuildContext context) => const DashboardView()), (Route<dynamic> route) => false);

  void checkIfUserHasImage(AthleteProfile? athleteProfile, AgentProfile? agentProfile, PlatformFile platformFile){
    if( selectedImage != null){
      uploadUserImage(athleteProfile, agentProfile, platformFile);
    }else{
      _showToastMessage("Upload a user Image to continue");
    }
  }

  void uploadUserImage(AthleteProfile? athleteProfile, AgentProfile? agentProfile, PlatformFile platformFile) async {
    if (auth == null){
      auth = FirebaseAuth.instance;
    }
    isCreatingProfile = true;
    notifyListeners();

    // final response = auth!.currentUser.
    try {
      // Get the file as File object
      File fileToUpload = File(selectedImage!.path);
      // Create a reference to Firebase Storage in the 'dp' folder
     // String fileName = path.basename(selectedImage!.path!);
      Reference storageRef = endpoints.dpRef().child(auth!.currentUser!.uid);

      // Upload the file
      UploadTask uploadTask = storageRef.putFile(fileToUpload);

      // Wait for the upload to complete
      TaskSnapshot snapshot = await uploadTask;

      // Get the download URL (optional)
      String downloadUrl = await snapshot.ref.getDownloadURL();
      if (athleteProfile != null){
        athleteProfile.dpUrl = downloadUrl;
      }else{
        agentProfile!.dpUrl = downloadUrl;
      }


      // Next upload the document
      File documentToUpload = File(platformFile.path!);
     // String documentName = platformFile.name;
      String docRef = "${auth!.currentUser!.uid}_doc";
      Reference storeRef = endpoints.otherMediaRef().child(docRef);

      UploadTask secondUploadTask = storeRef.putFile(documentToUpload);

      // Wait for the upload to complete
      TaskSnapshot secondSnapshot = await secondUploadTask;

      // Get the download URL (optional)
      String docDownloadUrl = await secondSnapshot.ref.getDownloadURL();
      if (athleteProfile != null){
        athleteProfile.mediaUrl = docDownloadUrl;
        athleteProfile.email = auth!.currentUser!.email;
        athleteProfile.id = auth!.currentUser!.uid;
        final userProfile = UserProfile(id: athleteProfile.id, firstname: athleteProfile.firstname, lastname: athleteProfile.lastname, bio: athleteProfile.bio, phone: athleteProfile.phone,email: athleteProfile.email,interest: athleteProfile.interest, clients:  null
            , mediaUrl: athleteProfile.mediaUrl, dpUrl: athleteProfile.dpUrl, notificationToken: null, education:  athleteProfile.education, goals:  athleteProfile.goals, achievements: athleteProfile.achievements, isAgent: false);

        // FInally move other items to the database
        try {
          await endpoints.userProfileRef(auth!.currentUser!.uid).set(userProfile.toJson());
          PrivacyData privacyData = PrivacyData(phone: true, bio: true, goals: true, media: true, achievements: true, openMessages: true, education: true, clients:  true, email: true);
          await endpoints.userPrivacySettingRef(auth!.currentUser!.uid).set(privacyData.toJson());
          final userSettings =  PrivacyData.fromJson(privacyData.toJson());
          prefManager.save(Variables.UserPrivacyPref, userSettings);
    _showToastMessage("Profile Successfully Created");
          await prefManager.save(Variables.Users, userProfile);
          goToHomePage(userProfile);
        }
        catch (e){
          _showToastMessage(e.toString());
          print('Error while saving Profile: $e');
          isCreatingProfile = false;
          notifyListeners();
        }

      }else{
        agentProfile!.mediaUrl = docDownloadUrl;
        agentProfile.id = auth!.currentUser!.uid;
        agentProfile.email = auth!.currentUser!.email;
        final userProfile = UserProfile(id: agentProfile.id, firstname: agentProfile.firstname, lastname: agentProfile.lastname, bio: agentProfile.bio, phone: agentProfile.phone,email: agentProfile.email,interest: agentProfile.interest, clients:  agentProfile.clients
        , mediaUrl: agentProfile.mediaUrl, dpUrl: agentProfile.dpUrl, notificationToken: agentProfile.notificationToken, education:  null, goals:  null, achievements: null, isAgent: true);

        // FInally move other items to the database
        try {
          await endpoints.userProfileRef(auth!.currentUser!.uid).set(userProfile.toJson());
          PrivacyData privacyData = PrivacyData(phone: true, bio: true, goals: true, media: true, achievements: true, openMessages: true, education: true, clients:  true, email: true);
          await endpoints.userPrivacySettingRef(auth!.currentUser!.uid).set(privacyData.toJson());
          final userSettings =  PrivacyData.fromJson(privacyData.toJson());
          prefManager.save(Variables.UserPrivacyPref, userSettings);
          _showToastMessage("Profile Successfully Created");
          await prefManager.save(Variables.Users, userProfile);
          goToHomePage(userProfile);
        }
        catch (e){
          _showToastMessage(e.toString());
          print('Error while saving Profile: $e');
          isCreatingProfile = false;
          notifyListeners();
        }
      }

    } catch (e) {
      print('Error while uploading the file: $e');
      isCreatingProfile = false;
      notifyListeners();
    }
  }

  void pickFile() async {
    // Using file picker to select image or PDF files
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.image,
    );

    if (result != null && result.files.isNotEmpty) {
      // Get the selected file
      selectedImage = File(result.files.single.path!);
      notifyListeners();
    } else {
      // If no file selected
      _showToastMessage("Cancelled");
    }
  }


  void _showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }
}