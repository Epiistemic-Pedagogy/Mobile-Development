
import 'package:athleteconnect/app/util.dart';
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/agent_profile.dart';
import 'package:athleteconnect/ui/views/imagesetup/profileimage_setup_viewmodel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../constants/asset.dart';
import '../../../constants/colors.dart';
import '../../../models/athlete_profile.dart';
import '../../widgets/custom_button.dart';

class ProfileImageSetUp extends StatelessWidget {
  const ProfileImageSetUp({super.key,
  required this.isForAgent,
  required this.file,
    required this.athleteProfile,
    required this.agentProfile
  });


  final bool isForAgent;
  final PlatformFile file;
  final AgentProfile? agentProfile;
  final AthleteProfile? athleteProfile;

  @override
  Widget build(BuildContext context) {
      ToastContext().init(context);
    return ViewModelBuilder<ProfileImageSetUpViewModel>.reactive(
        viewModelBuilder: () => ProfileImageSetUpViewModel(),
    onViewModelReady: (model) {
          model.isForAgent = isForAgent;
    },
    builder: (context, model, child) => Scaffold(
      backgroundColor: AppColors.fillColor,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: AppColors.fillColor,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            InkWell(
              onTap: () => Navigator.of(context).pop(),
              child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 5),
                  child: const Icon(Icons.arrow_back, color: AppColors.white, weight: 16,)
              ),
            ),
            Text(
              "Profile Image",
              style: context.textTheme.titleMedium?.copyWith(
                  color: AppColors.white, fontWeight: FontWeight.w600),
            ),
            const SizedBox(
              width: 10,
            )
          ],
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Stack(
            children: [
              Column(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const SizedBox(height: 16,),
                        model.selectedImage == null ?
                        const CircleAvatar(
                            backgroundImage:  AssetImage(AppAssets.photoAvatar,),
                            radius: 50.0
                        ) :
                        CircleAvatar(
                            backgroundImage: FileImage(model.selectedImage!, scale: 2.0),
                            radius: 50.0
                        ),
                        const SizedBox(height: 10,),
                        GestureDetector(
                            onTap: () { model.requestPermission();},
                            child: Text(
                              "Select Image",
                              style: context.textTheme.bodyMedium?.copyWith(
                                  color:  AppColors.buttonColor,
                                  decoration: TextDecoration.underline,
                                  fontSize: 14, fontWeight: FontWeight.w400),
                            )
                        ),
                      ],
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(5.0),
                    child: CustomButton(text:  "Finish", onTap: () {
                      model.checkIfUserHasImage(athleteProfile, agentProfile, file);
                    }),
                  )
                ],
              ),
              model.isCreatingProfile ? Utils().loadingContainer("Creating Account", AppColors.white, true)
              : Container (),
            ],
          )
        ),
      ),
    )
    );
  }
}