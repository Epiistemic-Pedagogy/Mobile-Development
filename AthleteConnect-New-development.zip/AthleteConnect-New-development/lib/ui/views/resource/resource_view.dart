

import 'package:athleteconnect/app/util.dart';
import 'package:athleteconnect/extensions/buildcontext/media_query.dart';
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/extra_data.dart';
import 'package:athleteconnect/ui/views/resource/resource_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';

import '../../../constants/colors.dart';

class ResourceScreen extends StatelessWidget {
  const ResourceScreen({super.key});

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<ResourceViewModel>.reactive(
        viewModelBuilder: () => ResourceViewModel(),
        onViewModelReady: (model) {
          model.isNew = true;
          model.loadAllResource();

        },
        builder: (context, model, child) => Scaffold(
          backgroundColor: AppColors.deepBlack,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: AppColors.deepBlack,
            title: Row(
              children: [
                InkWell(
                  onTap: () => Navigator.of(context).pop(),
                  child: const Icon(Icons.arrow_back, color: AppColors.white,),
                ),
                const SizedBox(
                  width: 16,
                ),
                Text(
                  "App Resource",
                  style: context.textTheme.titleLarge?.copyWith(
                      color:  AppColors.white,
                      fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ),
          body: SafeArea(
          child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  GestureDetector(onTap: model.loadAllResource,
                  child: Container(
                      padding: const EdgeInsets.all(6),
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      decoration: BoxDecoration(
                          color:  model.isGeneral ? AppColors.buttonColor :AppColors.textGrey,
                          border: Border.all(
                              color: model.isGeneral ? AppColors.buttonColor : AppColors.textGrey ),
                          borderRadius: BorderRadius.circular(7)),
                      child: Expanded(
                        child: Text(
                          "General",
                          style: context.textTheme.labelLarge?.copyWith(
                              color: model.isGeneral ? AppColors.white : AppColors.primary,
                              fontSize: context.widthPercent(0.03)),
                        ),
                      )
                  ),),
                  SizedBox(width: 10,),

                  GestureDetector(onTap: model.loadOtherResource,
                    child: Container(
                        padding: const EdgeInsets.all(6),
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                            color: model.isOther ? AppColors.buttonColor :  AppColors.textGrey,
                            border: Border.all(
                                color:  model.isOther ? AppColors.buttonColor : AppColors.textGrey ),
                            borderRadius: BorderRadius.circular(7)),
                        child: Expanded(
                          child: Text(
                            "News",
                            style: context.textTheme.labelLarge?.copyWith(
                                color: model.isOther ? AppColors.white : AppColors.primary,
                                fontSize: context.widthPercent(0.03)),
                          ),
                        )
                    ),),
                  const SizedBox(width: 10,),
                  GestureDetector(onTap: model.loadLegalResource,
                    child: Container(
                        padding: const EdgeInsets.all(6),
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        decoration: BoxDecoration(
                            color:  model.isLegal ? AppColors.buttonColor : AppColors.textGrey,
                            border: Border.all(
                                color:  model.isLegal ? AppColors.buttonColor : AppColors.textGrey ),
                            borderRadius: BorderRadius.circular(7)),
                        child: Expanded(
                          child: Text(
                            "Legal",
                            style: context.textTheme.labelLarge?.copyWith(
                                color: model.isLegal ? AppColors.white : AppColors.primary,
                                fontSize: context.widthPercent(0.03)),
                          ),
                        )
                    ),),

                ],
              ),
              const SizedBox(height: 16,),
              
              model.mainList.isEmpty ? Utils().loadingContainer("", AppColors.white, true) :
              Expanded(child: ListView.builder(
                  itemCount: model.mainList.length,
                  itemBuilder: (BuildContext context, int index) {
                    return NewsCards( resourceObject: model.mainList[index], viewModel: model,);
                  }),)
            ],
          ),
          )
        ),
        ));
  }
}

class NewsCards extends StatelessWidget {
  const NewsCards({
    super.key,
    required this.resourceObject,
    required this.viewModel

  });
  final ResourceObject resourceObject;
  final ResourceViewModel viewModel;


  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: 15,),
        GestureDetector(
          onTap:() { viewModel.openExternalBrowser(resourceObject.link!); },
          child: Container(
              height: 280,
              decoration: BoxDecoration(
                  color: AppColors.deepBlack,
                  border: Border.all(
                      color:  AppColors.deepBlack.withOpacity(1) ),
                  borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.all(6),
              margin: const EdgeInsets.symmetric(horizontal: 2),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(child: Image.network(resourceObject.image!, scale: 1, fit: BoxFit.cover, height: 200,),)
                    ],
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 10,),
                      Text(
                        resourceObject.title!,
                        maxLines: 2,
                        style: context.textTheme.bodyLarge?.copyWith(
                            color: AppColors.white, fontWeight: FontWeight.w900,
                            fontSize: 16),
                      ),
                      const SizedBox(height: 5,),
                    ],
                  ),

                ],
              )
          ),
        ),
      ],
    );
  }
}