
import 'package:athleteconnect/extensions/buildcontext/text_theme.dart';
import 'package:athleteconnect/models/extra_data.dart';
import 'package:athleteconnect/ui/views/resource/resource_viewmodel.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';
import '../../../constants/colors.dart';

class ResourceWebPage extends StatelessWidget {
  const ResourceWebPage({super.key,
    required this.resourceObject});

  final ResourceObject resourceObject;

  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<ResourceViewModel>.reactive(
        viewModelBuilder: () => ResourceViewModel(),
    onViewModelReady: (model) {
          model.resourceObject = resourceObject;
    },
    builder: (context, model, child) => Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        backgroundColor: AppColors.deepBlack,
        title: Row(
          children: [
            InkWell(
              onTap: () => Navigator.of(context).pop(),
              child: const Icon(Icons.arrow_back, color: AppColors.white,),
            ),
            const SizedBox(
              width: 16,
            ),
            Text(
              resourceObject.title!,
              style: context.textTheme.titleLarge?.copyWith(
                  color: AppColors.white,
                  fontSize: 16, fontWeight: FontWeight.w600),
            ),
          ],
        ),
      ),
      // body: WebViewWidget(controller: WebViewController()
      //   ..setJavaScriptMode(JavaScriptMode.unrestricted)
      //   ..setBackgroundColor(Colors.transparent)
      //   ..setNavigationDelegate(
      //     NavigationDelegate(
      //       onPageStarted: (url) {
      //         print('Page loading: $url');
      //       },
      //       onPageFinished: (url) {
      //         print('Page loaded: $url');
      //       },
      //       onNavigationRequest: (request) {
      //         if (request.url.startsWith('https://restricted.com')) {
      //           return NavigationDecision.prevent;
      //         }
      //         return NavigationDecision.navigate;
      //       },
      //     ),
      //   )
      //   ..loadRequest(Uri.parse(resourceObject.link!)), // Replace with your URL
      ),
    );
  }
}