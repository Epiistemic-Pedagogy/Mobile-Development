

import 'dart:convert';

import 'package:athleteconnect/services/endpoint_ref.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:go_router/go_router.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../app/locator.dart';
import '../../../constants/routes.dart';
import '../../../models/extra_data.dart';

class ResourceViewModel extends BaseViewModel {

  List<ResourceObject> legalList = [];
  List<ResourceObject> otherList = [];
  List<ResourceObject> mainList = [];
  bool isLegal = false;
  bool isOther = false;
  bool isGeneral = true;
  bool isNew = false;
  final endpointRef = EndpointRef();
  ResourceObject?  resourceObject;
//  var controller = WebViewController();


  void loadAllResource(){
    DatabaseReference ref = endpointRef.legalResource();
    ref.onValue.listen((event) async {
      if (event.snapshot.exists){
        legalList = [];
        for (DataSnapshot snapshot in event.snapshot.children){
          final String jsonData = jsonEncode(snapshot.value);
          Map<String, dynamic> responseData = jsonDecode(jsonData);
          final resourceObject = ResourceObject.fromJson(responseData);
          legalList.insert(0, resourceObject);
        }
      }
    });
    DatabaseReference otherref = endpointRef.generalResource();
    otherref.onValue.listen((event) async {
      if (event.snapshot.exists){
        otherList = [];
        for (DataSnapshot snapshot in event.snapshot.children){
          final String jsonData = jsonEncode(snapshot.value);
          Map<String, dynamic> responseData = jsonDecode(jsonData);
          final resourceObject = ResourceObject.fromJson(responseData);
          otherList.insert(0, resourceObject);
        }

        if (isNew){
          loadGeneral();
          isNew = false;
        }
      }
    });
  }

  void showToastMessage(String message) {
    Toast.show(message, duration: Toast.lengthShort, gravity: Toast.bottom);
  }

  void loadGeneral(){
    isGeneral = true;
    isLegal = false;
    isOther = false;
    mainList = [];
    mainList.addAll(legalList);
    mainList.addAll(otherList);
    notifyListeners();
  }

  void loadLegalResource(){
    isGeneral = false;
    isLegal = true;
    isOther = false;
    mainList = [];
    mainList.addAll(legalList);
    notifyListeners();
  }

  void loadOtherResource(){
    isGeneral = false;
    isLegal = false;
    isOther = true;
    mainList = [];
    mainList.addAll(otherList);
    notifyListeners();
  }

  void openBrowser(ResourceObject object){
    locator<GoRouter>().push(AppRoutes.appWebScreen, extra: object);
  }


  // void loadConrtroller(){
  //    controller = WebViewController()
  //     ..setJavaScriptMode(JavaScriptMode.unrestricted)
  //     ..setNavigationDelegate(
  //       NavigationDelegate(
  //         onProgress: (int progress) {
  //           // Update loading bar.
  //         },
  //         onPageStarted: (String url) {},
  //         onPageFinished: (String url) {},
  //
  //         onWebResourceError: (WebResourceError error) {},
  //         onNavigationRequest: (NavigationRequest request) {
  //           if (request.url.startsWith('https://www.youtube.com/')) {
  //             return NavigationDecision.prevent;
  //           }
  //           return NavigationDecision.navigate;
  //         },
  //       ),
  //     )
  //     ..loadRequest(Uri.parse(resourceObject!.link!));
  // }

  void openExternalBrowser(String url) async {
    final Uri uri = Uri.parse(url);

    if (await canLaunchUrl(uri)) {
      await launchUrl(
        uri,
        mode: LaunchMode.externalApplication, // Opens in the external browser
      );
    } else {
      throw 'Could not launch $url';
    }
  }
}