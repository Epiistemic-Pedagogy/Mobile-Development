

import 'dart:convert';
import 'dart:io';

import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/views/videocall/video_call_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:stacked/stacked.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';

import '../../../models/signalling.dart';

class VideoCallViewModel extends BaseViewModel {

  FirebaseAuth? auth;

  final localRenderer = RTCVideoRenderer();
  RTCVideoRenderer remoteRenderer = RTCVideoRenderer();
  RTCPeerConnection? _peerConnection;
  MediaStream? localStream;
  UserProfile? currentUser, recipient;

  Signaling? _signaling;
  List<UserProfile> peers = [];
  String? _selfId;
  bool inCalling = false;
  Session? _session;
  bool _waitAccept = false;
  BuildContext? context;
  Map? getOnState;
  bool? dialogResponse;
  late final VideoCallViewController controller;


  void initRenderers() async {
    await localRenderer.initialize();
    await remoteRenderer.initialize();
    peers.insert(0, recipient!);
    notifyListeners();
  }
  void connect() async {
    _signaling ??= Signaling('localhost', context!, this)
      ..connect();
    _signaling?.onSignalingStateChange = (SignalingState state) {
      switch (state) {
        case SignalingState.connectionClosed:
        case SignalingState.connectionError:
        case SignalingState.connectionOpen:
          break;
      }
    };
    notifyListeners();

    _signaling?.onCallStateChange = (Session session, CallState state) async {
      switch (state) {
        case CallState.callStateNew:
          _session = session;
          notifyListeners();
          break;
        case CallState.callStateRinging:
          bool? accept = await _showAcceptDialog();
          if (accept!) {
            _accept();
            inCalling = true;
            notifyListeners();
          } else {
            _reject();
          }
          break;
        case CallState.callStateBye:
          if (_waitAccept) {
            print('peer reject');
            _waitAccept = false;
            return false;
          }
          localRenderer.srcObject = null;
          remoteRenderer.srcObject = null;
          inCalling = false;
          _session = null;
          notifyListeners();
          break;
        case CallState.callStateInvite:
          _waitAccept = true;
          _showInviteDialog();
          break;
        case CallState.callStateConnected:
          if (_waitAccept) {
            _waitAccept = false;
            return false;
          }
          inCalling = true;
          notifyListeners();
          break;
      }
    };

    _signaling?.onPeersUpdate = ((event) {
      _selfId = event['self'];
      peers = event['peers'];
      notifyListeners();
    });

    _signaling?.onLocalStream = ((stream) {
      localRenderer.srcObject = stream;
      notifyListeners();
    });

    _signaling?.onAddRemoteStream = ((_, stream) {
      remoteRenderer.srcObject = stream;
      notifyListeners();
    });

    _signaling?.onRemoveRemoteStream = ((_, stream) {
      remoteRenderer.srcObject = null;
    });
  }


  bool? _showAcceptDialog() {
     showDialog<bool?>(
      context: context!,
      builder: (context) {
        return AlertDialog(
          title: Text("New Call"),
          content: Text("Accept?"),
          actions: <Widget>[
            MaterialButton(
              child: const Text(
                'Reject',
                style: TextStyle(color: Colors.red),
              ),
              onPressed: () {
                dialogResponse = false;
                return Navigator.of(context).pop(false);
              },
            ),
            MaterialButton(
              child: const Text(
                'Accept',
                style: TextStyle(color: Colors.green),
              ),
              onPressed: (){
                dialogResponse = true;
                return Navigator.of(context).pop(true);
              },
            ),
          ],
        );
      },
    );
     return dialogResponse;
  }

   bool? _showInviteDialog() {
     showDialog<bool?>(
      context: context!,
      builder: (context) {
        return AlertDialog(
          title: Text("Invited User"),
          content: Text("Waiting"),
          actions: <Widget>[
            TextButton(
              child: Text("cancel"),
              onPressed: () {
                Navigator.of(context).pop(false);
                _hangUp();
              },
            ),
          ],
        );
      },
    );
  }

  void invitePeer(BuildContext context, String peerId, bool useScreen) async {
    if (_signaling != null && peerId != _selfId) {
      _signaling?.invite(peerId, 'video', useScreen);
    }
  }

  void _accept() {
    if (_session != null) {
      _signaling?.accept(_session!.sid, 'video');
    }
  }

  void _reject() {
    if (_session != null) {
      _signaling?.reject(_session!.sid);
    }
  }

  void _hangUp() {
    if (_session != null) {
      _signaling?.bye(_session!.sid);
    }
  }


  void  createPeerConnections() async {
    controller = VideoCallViewController();

    try {
    localStream = await navigator.mediaDevices.getUserMedia({
      'video': true,
      'audio': true,
    });

    await controller.setStream(localStream!); // Assign the stream
   // localRenderer.srcObject = localStream;

    // Map<String, dynamic> configuration = {
    //   'iceServers': [
    //     {'urls': 'stun:stun.l.google.com:19302'},
    //   ]
    // };
    //
    // _peerConnection = await createPeerConnection(configuration);
    //
    // _peerConnection?.addStream(localStream!);
    //
    // _peerConnection?.onAddStream = (stream) {
    //   remoteRenderer.srcObject = stream;
    // };
    //
    // localStream?.getTracks().forEach((track) {
    //   _peerConnection?.addTrack(track, localStream!);
    // });

    // var offer = await _peerConnection!.createOffer();
    // await _peerConnection!.setLocalDescription(offer);
    // Send offer SDP to remote peer via signaling
    notifyListeners();


  } catch (e) {
  print('Error initializing call: $e');
  notifyListeners();
  }

    // Set up signaling (sending/receiving SDP and ICE candidates)

    // Create offer, handle answer and connection


    // Listen for answer SDP and ICE candidates from the signaling server
  }


  void disposeView(){
    localRenderer.dispose();
    remoteRenderer.dispose();
    _peerConnection?.close();
    _peerConnection?.dispose();
    controller.dispose();
    _signaling?.close();
  }

  String getVal (){
    var ss;
    return ss = "myname";
  }


  Future<Map> getTurnCredential(String host, int port) async {
    HttpClient client = HttpClient(context: SecurityContext());
    client.badCertificateCallback =
        (X509Certificate cert, String host, int port) {
      print('getTurnCredential: Allow self-signed certificate => $host:$port. ');
      return true;
    };
    var url = 'https://$host:$port/api/turn?service=turn&username=flutter-webrtc';
    var request = await client.getUrl(Uri.parse(url));
    var response = await request.close();
    var responseBody = await response.transform(Utf8Decoder()).join();
    print('getTurnCredential:response => $responseBody.');
    Map data = const JsonDecoder().convert(responseBody);
    getOnState = data;
    notifyListeners();
    return data;
  }




}