

import 'package:athleteconnect/models/user_profile.dart';
import 'package:athleteconnect/ui/views/videocall/video_call_viewmodel.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:stacked/stacked.dart';
import 'package:toast/toast.dart';


class VideoCallViewController {
  late final RTCVideoRenderer _renderer;
  bool _isInitialized = false;

  VideoCallViewController() {
    _renderer = RTCVideoRenderer();
    _initializeRenderer();
  }

  RTCVideoRenderer get renderer => _renderer;

  Future<void> _initializeRenderer() async {
    await _renderer.initialize(); // Initialize the renderer
    _isInitialized = true; // Set the flag to true after initialization
  }

  Future<void> setStream(MediaStream stream) async {
    if (!_isInitialized) {
      throw Exception("Renderer not initialized!");
    }
    _renderer.srcObject = stream; // Assign the stream
    _renderer.srcObject = stream; // Assign the stream
  }

  void dispose() {
    _renderer.dispose(); // Clean up resources
  }
}

class VideoCallScreen extends StatelessWidget {
  const VideoCallScreen({super.key, required this.currentUser, required this.recipient});

  final UserProfile currentUser, recipient;


  @override
  Widget build(BuildContext context) {
    ToastContext().init(context);
    return ViewModelBuilder<VideoCallViewModel>.reactive(
        viewModelBuilder: () => VideoCallViewModel(),
        onModelReady: (model) {
          model.currentUser = currentUser;
          model.recipient = recipient;
          model.auth = FirebaseAuth.instance;
          model.createPeerConnections();
         // model.connect();
          },
        builder: (context, model, child) =>
            Scaffold(
              body: model.localStream != null ?
              Center(
                child: RTCVideoView(
                  model.controller.renderer,
                  mirror: true,
                  objectFit: RTCVideoViewObjectFit.RTCVideoViewObjectFitCover,
                ),) : Container()
              // SafeArea(
              //   child: model.inCalling
              //       ? OrientationBuilder(
              //     builder: (context, orientation) {
              //       return Stack(
              //         children: <Widget>[
              //           Positioned(
              //             left: 0.0,
              //             right: 0.0,
              //             top: 0.0,
              //             bottom: 0.0,
              //             child: Container(
              //               margin: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 0.0),
              //               width: MediaQuery.of(context).size.width,
              //               height: MediaQuery.of(context).size.height,
              //               decoration:
              //               const BoxDecoration(color: Colors.black54),
              //               child: RTCVideoView(model.remoteRenderer),
              //             ),
              //           ),
              //           Positioned(
              //             left: 20.0,
              //             top: 20.0,
              //             child: Container(
              //               width: orientation == Orientation.portrait
              //                   ? 90.0
              //                   : 120.0,
              //               height: orientation == Orientation.portrait
              //                   ? 120.0
              //                   : 90.0,
              //               decoration:
              //               const BoxDecoration(color: Colors.black54),
              //               child: RTCVideoView(model.localRenderer, mirror: true),
              //             ),
              //           ),
              //         ],
              //       );
              //     },
              //   )
              //       : ListView.builder(
              //     shrinkWrap: true,
              //     padding: const EdgeInsets.all(0.0),
              //     itemCount: (model.peers.length),
              //     itemBuilder: (context, i) {
              //       var peer = model.peers[i];
              //       var self = (model.peers[i].id == model.currentUser!.id!);
              //       return ListBody(
              //         children: <Widget>[
              //           ListTile(
              //             title: Text(self
              //                 ? peer.firstname! +
              //                 ' [Your self]'
              //                 : peer.firstname! + ', ID: ${peer.id} '),
              //             onTap: null,
              //             trailing: SizedBox(
              //               width: 100.0,
              //               child: Row(
              //                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //                 children: <Widget>[
              //                   if (!self)
              //                     IconButton(
              //                       icon: Icon(
              //                           self ? Icons.close : Icons.videocam,
              //                           color: self ? Colors.grey : Colors.black),
              //                       onPressed: () =>
              //                           model.invitePeer(context, peer.id!, false),
              //                       tooltip: 'Video calling',
              //                     ),
              //                 ],
              //               ),
              //             ),
              //             subtitle: Text('[' + peer.lastname! + ']'),
              //           ),
              //           const Divider(),
              //         ],
              //       );
              //     },
              //   ),
              // ),
            ),
      onDispose: (model) {
        model.disposeView(); // Call your cleanup method here
      },
    );
  }
}